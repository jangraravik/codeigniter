<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index()
	{
		$this->load->view('welcome_message');
	}
	public function test()
	{
		echo "test";
	}	
	public function search_loadmore(){	
		//echo "search more";
		$offset = is_numeric($_POST['offset']) ? $_POST['offset'] : die();
		$postnumbers = is_numeric($_POST['number']) ? $_POST['number'] : die();
		$this->db->select('*');
		$this->db->from('tbl_content');
		$this->db->limit($postnumbers,$offset);
		$query = $this->db->get();	
		//print_r($query->result_array());
		$data = $query->result_array();
		foreach($data as $row){
			$content = substr(strip_tags($row['description']), 0, 500);
			echo '<h1><a href="'.$row['id'].'">'.$row['title'].'</a></h1><hr />';
			echo '<p>'.$content.'...</p><hr />';			
		}
	}
}
