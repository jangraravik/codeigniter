<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';

class Course extends REST_Controller{

    public function __construct() {
                parent::__construct();
                $this->load->model('courses_mdl'); 
    }
	
    public function create_post(){ 
        $data = array('user_id' => $this->input->get('user_id'),
					  'course' => $this->input->get('course'),
                      'fee' => $this->input->get('fee'),                     
                      'duration' => $this->input->get('duration')
				);
        $this->courses_mdl->create($data);
        $message = [ 
			'status' => TRUE,
            'message' => 'Course is Added'
        ];
        $this->set_response($message, REST_Controller::HTTP_CREATED); 
    }


    public function read_get(){
        $id = $this->input->get('id');
        if (empty($id)){
			$message = [
				'status' => FALSE,
				'message' => 'ID cannot be empty'
			];
            $this->response($message, REST_Controller::HTTP_NOT_FOUND); 
        } else {
			$data = $this->courses_mdl->read($id);
            $this->response($data, REST_Controller::HTTP_OK);   
		}
    }
	

    public function update_put(){
        $id = $this->input->get('id');
        if (empty($id)){
			$message = [
				'status' => FALSE,
				'message' => 'ID cannot be empty'
			];
            $this->response($message, REST_Controller::HTTP_NOT_FOUND); 
        } else {		
				$data = array('id' => $this->input->get('id'),
					  'course' => $this->input->get('course'),
					  'fee' => $this->input->get('fee'),                     
					  'duration' => $this->input->get('duration')
				);
			$this->courses_mdl->update($data);
			$message = [
				'status' => TRUE,
				'message' => 'Course is Updated'
			];
			$this->response($message, REST_Controller::HTTP_ACCEPTED); 
		}
	}
	
	
	
	
    public function delete_delete(){
        $id = $this->input->get('id');
        if(empty($id)){
			$message = [
				'status' => FALSE,
				'message' => 'ID cannot be empty'
			];
			$this->response($message, REST_Controller::HTTP_NOT_FOUND); 
        } else {
			$data = $this->courses_mdl->delete($id);
				$message = [
					'status' => TRUE,
					'message' => 'Record Deleted'
				];			
			$this->response($message, REST_Controller::HTTP_OK);
		}
    }
	
	
	
	
}