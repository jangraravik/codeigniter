<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Courses_mdl extends CI_Model{
	
    public function create($data){
        $this->db->insert('courses', $data);
        return TRUE;
    }
	
	
    public function read($id){
        $query = $this->db->select('*')->from('courses')->where('id',$id)->get();
        return $query->result_array();
    }

	
	public function update($data){
	   $this->db->set('course',$data['course']);
	   $this->db->set('fee',$data['fee']);
	   $this->db->set('duration',$data['duration']);
	   $this->db->where('id',$data['id']);
	   $this->db->update('courses');
	}
	
    public function delete($id){
			$this->db->where('id',$id)->delete('courses');
			return TRUE;
	}

}