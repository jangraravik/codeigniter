<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-06-04 02:25:59 --> Config Class Initialized
INFO - 2016-06-04 02:25:59 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:25:59 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:25:59 --> Utf8 Class Initialized
INFO - 2016-06-04 02:25:59 --> URI Class Initialized
INFO - 2016-06-04 02:25:59 --> Router Class Initialized
INFO - 2016-06-04 02:25:59 --> Output Class Initialized
INFO - 2016-06-04 02:25:59 --> Security Class Initialized
DEBUG - 2016-06-04 02:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:25:59 --> Input Class Initialized
INFO - 2016-06-04 02:25:59 --> Language Class Initialized
INFO - 2016-06-04 02:25:59 --> Loader Class Initialized
INFO - 2016-06-04 02:25:59 --> Helper loaded: url_helper
INFO - 2016-06-04 02:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:25:59 --> Controller Class Initialized
INFO - 2016-06-04 02:25:59 --> Config Class Initialized
INFO - 2016-06-04 02:25:59 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:25:59 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:25:59 --> Utf8 Class Initialized
INFO - 2016-06-04 02:25:59 --> URI Class Initialized
INFO - 2016-06-04 02:25:59 --> Router Class Initialized
INFO - 2016-06-04 02:25:59 --> Output Class Initialized
INFO - 2016-06-04 02:25:59 --> Security Class Initialized
DEBUG - 2016-06-04 02:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:25:59 --> Input Class Initialized
INFO - 2016-06-04 02:25:59 --> Language Class Initialized
ERROR - 2016-06-04 02:25:59 --> 404 Page Not Found: Site/service
INFO - 2016-06-04 02:26:02 --> Config Class Initialized
INFO - 2016-06-04 02:26:02 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:26:02 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:26:02 --> Utf8 Class Initialized
INFO - 2016-06-04 02:26:02 --> URI Class Initialized
INFO - 2016-06-04 02:26:02 --> Router Class Initialized
INFO - 2016-06-04 02:26:02 --> Output Class Initialized
INFO - 2016-06-04 02:26:02 --> Security Class Initialized
DEBUG - 2016-06-04 02:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:26:02 --> Input Class Initialized
INFO - 2016-06-04 02:26:02 --> Language Class Initialized
INFO - 2016-06-04 02:26:02 --> Loader Class Initialized
INFO - 2016-06-04 02:26:02 --> Helper loaded: url_helper
INFO - 2016-06-04 02:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:26:02 --> Controller Class Initialized
INFO - 2016-06-04 02:26:02 --> Helper loaded: language_helper
INFO - 2016-06-04 02:26:02 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:26:02 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 02:26:02 --> Final output sent to browser
DEBUG - 2016-06-04 02:26:02 --> Total execution time: 0.1070
INFO - 2016-06-04 02:26:04 --> Config Class Initialized
INFO - 2016-06-04 02:26:04 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:26:04 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:26:04 --> Utf8 Class Initialized
INFO - 2016-06-04 02:26:04 --> URI Class Initialized
INFO - 2016-06-04 02:26:04 --> Router Class Initialized
INFO - 2016-06-04 02:26:04 --> Output Class Initialized
INFO - 2016-06-04 02:26:04 --> Security Class Initialized
DEBUG - 2016-06-04 02:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:26:04 --> Input Class Initialized
INFO - 2016-06-04 02:26:04 --> Language Class Initialized
INFO - 2016-06-04 02:26:04 --> Loader Class Initialized
INFO - 2016-06-04 02:26:04 --> Helper loaded: url_helper
INFO - 2016-06-04 02:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:26:04 --> Controller Class Initialized
INFO - 2016-06-04 02:26:04 --> Config Class Initialized
INFO - 2016-06-04 02:26:04 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:26:04 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:26:04 --> Utf8 Class Initialized
INFO - 2016-06-04 02:26:04 --> URI Class Initialized
INFO - 2016-06-04 02:26:04 --> Router Class Initialized
INFO - 2016-06-04 02:26:04 --> Output Class Initialized
INFO - 2016-06-04 02:26:04 --> Security Class Initialized
DEBUG - 2016-06-04 02:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:26:04 --> Input Class Initialized
INFO - 2016-06-04 02:26:04 --> Language Class Initialized
INFO - 2016-06-04 02:26:04 --> Loader Class Initialized
INFO - 2016-06-04 02:26:04 --> Helper loaded: url_helper
INFO - 2016-06-04 02:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:26:04 --> Controller Class Initialized
INFO - 2016-06-04 02:26:04 --> Helper loaded: language_helper
INFO - 2016-06-04 02:26:04 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:26:04 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 02:26:04 --> Final output sent to browser
DEBUG - 2016-06-04 02:26:04 --> Total execution time: 0.1080
INFO - 2016-06-04 02:26:07 --> Config Class Initialized
INFO - 2016-06-04 02:26:07 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:26:07 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:26:07 --> Utf8 Class Initialized
INFO - 2016-06-04 02:26:07 --> URI Class Initialized
INFO - 2016-06-04 02:26:07 --> Router Class Initialized
INFO - 2016-06-04 02:26:07 --> Output Class Initialized
INFO - 2016-06-04 02:26:07 --> Security Class Initialized
DEBUG - 2016-06-04 02:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:26:07 --> Input Class Initialized
INFO - 2016-06-04 02:26:07 --> Language Class Initialized
INFO - 2016-06-04 02:26:07 --> Loader Class Initialized
INFO - 2016-06-04 02:26:07 --> Helper loaded: url_helper
INFO - 2016-06-04 02:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:26:07 --> Controller Class Initialized
INFO - 2016-06-04 02:26:07 --> Config Class Initialized
INFO - 2016-06-04 02:26:07 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:26:07 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:26:07 --> Utf8 Class Initialized
INFO - 2016-06-04 02:26:07 --> URI Class Initialized
INFO - 2016-06-04 02:26:07 --> Router Class Initialized
INFO - 2016-06-04 02:26:07 --> Output Class Initialized
INFO - 2016-06-04 02:26:07 --> Security Class Initialized
DEBUG - 2016-06-04 02:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:26:07 --> Input Class Initialized
INFO - 2016-06-04 02:26:07 --> Language Class Initialized
INFO - 2016-06-04 02:26:07 --> Loader Class Initialized
INFO - 2016-06-04 02:26:07 --> Helper loaded: url_helper
INFO - 2016-06-04 02:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:26:07 --> Controller Class Initialized
INFO - 2016-06-04 02:26:07 --> Helper loaded: language_helper
INFO - 2016-06-04 02:26:07 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:26:07 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 02:26:07 --> Final output sent to browser
DEBUG - 2016-06-04 02:26:07 --> Total execution time: 0.1050
INFO - 2016-06-04 02:26:09 --> Config Class Initialized
INFO - 2016-06-04 02:26:09 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:26:09 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:26:09 --> Utf8 Class Initialized
INFO - 2016-06-04 02:26:09 --> URI Class Initialized
INFO - 2016-06-04 02:26:09 --> Router Class Initialized
INFO - 2016-06-04 02:26:09 --> Output Class Initialized
INFO - 2016-06-04 02:26:09 --> Security Class Initialized
DEBUG - 2016-06-04 02:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:26:09 --> Input Class Initialized
INFO - 2016-06-04 02:26:09 --> Language Class Initialized
INFO - 2016-06-04 02:26:09 --> Loader Class Initialized
INFO - 2016-06-04 02:26:09 --> Helper loaded: url_helper
INFO - 2016-06-04 02:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:26:09 --> Controller Class Initialized
INFO - 2016-06-04 02:26:09 --> Config Class Initialized
INFO - 2016-06-04 02:26:09 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:26:09 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:26:09 --> Utf8 Class Initialized
INFO - 2016-06-04 02:26:09 --> URI Class Initialized
INFO - 2016-06-04 02:26:09 --> Router Class Initialized
INFO - 2016-06-04 02:26:09 --> Output Class Initialized
INFO - 2016-06-04 02:26:09 --> Security Class Initialized
DEBUG - 2016-06-04 02:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:26:09 --> Input Class Initialized
INFO - 2016-06-04 02:26:09 --> Language Class Initialized
INFO - 2016-06-04 02:26:09 --> Loader Class Initialized
INFO - 2016-06-04 02:26:09 --> Helper loaded: url_helper
INFO - 2016-06-04 02:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:26:09 --> Controller Class Initialized
INFO - 2016-06-04 02:26:09 --> Helper loaded: language_helper
INFO - 2016-06-04 02:26:09 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:26:09 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 02:26:09 --> Final output sent to browser
DEBUG - 2016-06-04 02:26:09 --> Total execution time: 0.1090
INFO - 2016-06-04 02:35:50 --> Config Class Initialized
INFO - 2016-06-04 02:35:50 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:35:50 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:35:50 --> Utf8 Class Initialized
INFO - 2016-06-04 02:35:50 --> URI Class Initialized
INFO - 2016-06-04 02:35:50 --> Router Class Initialized
INFO - 2016-06-04 02:35:50 --> Output Class Initialized
INFO - 2016-06-04 02:35:50 --> Security Class Initialized
DEBUG - 2016-06-04 02:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:35:50 --> Input Class Initialized
INFO - 2016-06-04 02:35:50 --> Language Class Initialized
INFO - 2016-06-04 02:35:50 --> Loader Class Initialized
INFO - 2016-06-04 02:35:50 --> Helper loaded: url_helper
INFO - 2016-06-04 02:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:35:50 --> Controller Class Initialized
INFO - 2016-06-04 02:35:50 --> Config Class Initialized
INFO - 2016-06-04 02:35:50 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:35:50 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:35:50 --> Utf8 Class Initialized
INFO - 2016-06-04 02:35:50 --> URI Class Initialized
INFO - 2016-06-04 02:35:50 --> Router Class Initialized
INFO - 2016-06-04 02:35:50 --> Output Class Initialized
INFO - 2016-06-04 02:35:50 --> Security Class Initialized
DEBUG - 2016-06-04 02:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:35:50 --> Input Class Initialized
INFO - 2016-06-04 02:35:50 --> Language Class Initialized
INFO - 2016-06-04 02:35:50 --> Loader Class Initialized
INFO - 2016-06-04 02:35:50 --> Helper loaded: url_helper
INFO - 2016-06-04 02:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:35:50 --> Controller Class Initialized
INFO - 2016-06-04 02:35:50 --> Helper loaded: language_helper
INFO - 2016-06-04 02:35:50 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:35:50 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 02:35:50 --> Final output sent to browser
DEBUG - 2016-06-04 02:35:50 --> Total execution time: 0.1170
INFO - 2016-06-04 02:35:52 --> Config Class Initialized
INFO - 2016-06-04 02:35:52 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:35:52 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:35:52 --> Utf8 Class Initialized
INFO - 2016-06-04 02:35:52 --> URI Class Initialized
INFO - 2016-06-04 02:35:52 --> Router Class Initialized
INFO - 2016-06-04 02:35:52 --> Output Class Initialized
INFO - 2016-06-04 02:35:52 --> Security Class Initialized
DEBUG - 2016-06-04 02:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:35:52 --> Input Class Initialized
INFO - 2016-06-04 02:35:52 --> Language Class Initialized
INFO - 2016-06-04 02:35:52 --> Loader Class Initialized
INFO - 2016-06-04 02:35:52 --> Helper loaded: url_helper
INFO - 2016-06-04 02:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:35:52 --> Controller Class Initialized
INFO - 2016-06-04 02:35:52 --> Config Class Initialized
INFO - 2016-06-04 02:35:52 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:35:52 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:35:52 --> Utf8 Class Initialized
INFO - 2016-06-04 02:35:52 --> URI Class Initialized
INFO - 2016-06-04 02:35:52 --> Router Class Initialized
INFO - 2016-06-04 02:35:52 --> Output Class Initialized
INFO - 2016-06-04 02:35:52 --> Security Class Initialized
DEBUG - 2016-06-04 02:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:35:52 --> Input Class Initialized
INFO - 2016-06-04 02:35:52 --> Language Class Initialized
INFO - 2016-06-04 02:35:52 --> Loader Class Initialized
INFO - 2016-06-04 02:35:52 --> Helper loaded: url_helper
INFO - 2016-06-04 02:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:35:52 --> Controller Class Initialized
INFO - 2016-06-04 02:35:52 --> Helper loaded: language_helper
INFO - 2016-06-04 02:35:52 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:35:52 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 02:35:52 --> Final output sent to browser
DEBUG - 2016-06-04 02:35:52 --> Total execution time: 0.1650
INFO - 2016-06-04 02:36:12 --> Config Class Initialized
INFO - 2016-06-04 02:36:12 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:36:12 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:36:12 --> Utf8 Class Initialized
INFO - 2016-06-04 02:36:12 --> URI Class Initialized
INFO - 2016-06-04 02:36:12 --> Router Class Initialized
INFO - 2016-06-04 02:36:12 --> Output Class Initialized
INFO - 2016-06-04 02:36:12 --> Security Class Initialized
DEBUG - 2016-06-04 02:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:36:12 --> Input Class Initialized
INFO - 2016-06-04 02:36:12 --> Language Class Initialized
INFO - 2016-06-04 02:36:12 --> Loader Class Initialized
INFO - 2016-06-04 02:36:12 --> Helper loaded: url_helper
INFO - 2016-06-04 02:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:36:12 --> Controller Class Initialized
INFO - 2016-06-04 02:36:12 --> Helper loaded: language_helper
INFO - 2016-06-04 02:36:12 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:36:12 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:36:12 --> Final output sent to browser
DEBUG - 2016-06-04 02:36:12 --> Total execution time: 0.1790
INFO - 2016-06-04 02:36:17 --> Config Class Initialized
INFO - 2016-06-04 02:36:17 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:36:17 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:36:17 --> Utf8 Class Initialized
INFO - 2016-06-04 02:36:17 --> URI Class Initialized
INFO - 2016-06-04 02:36:17 --> Router Class Initialized
INFO - 2016-06-04 02:36:17 --> Output Class Initialized
INFO - 2016-06-04 02:36:17 --> Security Class Initialized
DEBUG - 2016-06-04 02:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:36:17 --> Input Class Initialized
INFO - 2016-06-04 02:36:17 --> Language Class Initialized
INFO - 2016-06-04 02:36:17 --> Loader Class Initialized
INFO - 2016-06-04 02:36:17 --> Helper loaded: url_helper
INFO - 2016-06-04 02:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:36:17 --> Controller Class Initialized
INFO - 2016-06-04 02:36:17 --> Config Class Initialized
INFO - 2016-06-04 02:36:17 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:36:17 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:36:17 --> Utf8 Class Initialized
INFO - 2016-06-04 02:36:17 --> URI Class Initialized
INFO - 2016-06-04 02:36:17 --> Router Class Initialized
INFO - 2016-06-04 02:36:17 --> Output Class Initialized
INFO - 2016-06-04 02:36:17 --> Security Class Initialized
DEBUG - 2016-06-04 02:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:36:17 --> Input Class Initialized
INFO - 2016-06-04 02:36:17 --> Language Class Initialized
INFO - 2016-06-04 02:36:17 --> Loader Class Initialized
INFO - 2016-06-04 02:36:17 --> Helper loaded: url_helper
INFO - 2016-06-04 02:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:36:17 --> Controller Class Initialized
INFO - 2016-06-04 02:36:17 --> Helper loaded: language_helper
INFO - 2016-06-04 02:36:17 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:36:17 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:36:17 --> Final output sent to browser
DEBUG - 2016-06-04 02:36:17 --> Total execution time: 0.1230
INFO - 2016-06-04 02:36:23 --> Config Class Initialized
INFO - 2016-06-04 02:36:23 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:36:23 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:36:23 --> Utf8 Class Initialized
INFO - 2016-06-04 02:36:23 --> URI Class Initialized
INFO - 2016-06-04 02:36:23 --> Router Class Initialized
INFO - 2016-06-04 02:36:23 --> Output Class Initialized
INFO - 2016-06-04 02:36:23 --> Security Class Initialized
DEBUG - 2016-06-04 02:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:36:23 --> Input Class Initialized
INFO - 2016-06-04 02:36:23 --> Language Class Initialized
INFO - 2016-06-04 02:36:23 --> Loader Class Initialized
INFO - 2016-06-04 02:36:23 --> Helper loaded: url_helper
INFO - 2016-06-04 02:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:36:23 --> Controller Class Initialized
INFO - 2016-06-04 02:36:23 --> Helper loaded: language_helper
INFO - 2016-06-04 02:36:23 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:36:23 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\contact.php
INFO - 2016-06-04 02:36:23 --> Final output sent to browser
DEBUG - 2016-06-04 02:36:23 --> Total execution time: 0.1370
INFO - 2016-06-04 02:37:38 --> Config Class Initialized
INFO - 2016-06-04 02:37:38 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:37:38 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:37:38 --> Utf8 Class Initialized
INFO - 2016-06-04 02:37:38 --> URI Class Initialized
DEBUG - 2016-06-04 02:37:38 --> No URI present. Default controller set.
INFO - 2016-06-04 02:37:38 --> Router Class Initialized
INFO - 2016-06-04 02:37:38 --> Output Class Initialized
INFO - 2016-06-04 02:37:38 --> Security Class Initialized
DEBUG - 2016-06-04 02:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:37:38 --> Input Class Initialized
INFO - 2016-06-04 02:37:38 --> Language Class Initialized
INFO - 2016-06-04 02:37:38 --> Loader Class Initialized
INFO - 2016-06-04 02:37:38 --> Helper loaded: url_helper
INFO - 2016-06-04 02:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:37:38 --> Controller Class Initialized
INFO - 2016-06-04 02:37:38 --> Helper loaded: language_helper
INFO - 2016-06-04 02:37:38 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:37:38 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:37:38 --> Final output sent to browser
DEBUG - 2016-06-04 02:37:38 --> Total execution time: 0.1240
INFO - 2016-06-04 02:37:38 --> Config Class Initialized
INFO - 2016-06-04 02:37:38 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:37:38 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:37:38 --> Utf8 Class Initialized
INFO - 2016-06-04 02:37:38 --> URI Class Initialized
INFO - 2016-06-04 02:37:38 --> Router Class Initialized
INFO - 2016-06-04 02:37:38 --> Output Class Initialized
INFO - 2016-06-04 02:37:38 --> Security Class Initialized
DEBUG - 2016-06-04 02:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:37:38 --> Input Class Initialized
INFO - 2016-06-04 02:37:38 --> Language Class Initialized
ERROR - 2016-06-04 02:37:38 --> 404 Page Not Found: Faviconico/index
INFO - 2016-06-04 02:37:40 --> Config Class Initialized
INFO - 2016-06-04 02:37:40 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:37:40 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:37:40 --> Utf8 Class Initialized
INFO - 2016-06-04 02:37:40 --> URI Class Initialized
INFO - 2016-06-04 02:37:40 --> Router Class Initialized
INFO - 2016-06-04 02:37:40 --> Output Class Initialized
INFO - 2016-06-04 02:37:40 --> Security Class Initialized
DEBUG - 2016-06-04 02:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:37:40 --> Input Class Initialized
INFO - 2016-06-04 02:37:40 --> Language Class Initialized
INFO - 2016-06-04 02:37:40 --> Loader Class Initialized
INFO - 2016-06-04 02:37:40 --> Helper loaded: url_helper
INFO - 2016-06-04 02:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:37:40 --> Controller Class Initialized
INFO - 2016-06-04 02:37:40 --> Config Class Initialized
INFO - 2016-06-04 02:37:40 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:37:40 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:37:40 --> Utf8 Class Initialized
INFO - 2016-06-04 02:37:40 --> URI Class Initialized
DEBUG - 2016-06-04 02:37:40 --> No URI present. Default controller set.
INFO - 2016-06-04 02:37:40 --> Router Class Initialized
INFO - 2016-06-04 02:37:40 --> Output Class Initialized
INFO - 2016-06-04 02:37:40 --> Security Class Initialized
DEBUG - 2016-06-04 02:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:37:40 --> Input Class Initialized
INFO - 2016-06-04 02:37:40 --> Language Class Initialized
INFO - 2016-06-04 02:37:40 --> Loader Class Initialized
INFO - 2016-06-04 02:37:40 --> Helper loaded: url_helper
INFO - 2016-06-04 02:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:37:40 --> Controller Class Initialized
INFO - 2016-06-04 02:37:40 --> Helper loaded: language_helper
INFO - 2016-06-04 02:37:40 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:37:40 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:37:40 --> Final output sent to browser
DEBUG - 2016-06-04 02:37:40 --> Total execution time: 0.1160
INFO - 2016-06-04 02:37:46 --> Config Class Initialized
INFO - 2016-06-04 02:37:46 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:37:46 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:37:46 --> Utf8 Class Initialized
INFO - 2016-06-04 02:37:46 --> URI Class Initialized
INFO - 2016-06-04 02:37:46 --> Router Class Initialized
INFO - 2016-06-04 02:37:46 --> Output Class Initialized
INFO - 2016-06-04 02:37:46 --> Security Class Initialized
DEBUG - 2016-06-04 02:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:37:46 --> Input Class Initialized
INFO - 2016-06-04 02:37:46 --> Language Class Initialized
ERROR - 2016-06-04 02:37:46 --> 404 Page Not Found: Contact/index
INFO - 2016-06-04 02:37:52 --> Config Class Initialized
INFO - 2016-06-04 02:37:52 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:37:52 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:37:52 --> Utf8 Class Initialized
INFO - 2016-06-04 02:37:52 --> URI Class Initialized
INFO - 2016-06-04 02:37:52 --> Router Class Initialized
INFO - 2016-06-04 02:37:52 --> Output Class Initialized
INFO - 2016-06-04 02:37:52 --> Security Class Initialized
DEBUG - 2016-06-04 02:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:37:52 --> Input Class Initialized
INFO - 2016-06-04 02:37:52 --> Language Class Initialized
INFO - 2016-06-04 02:37:52 --> Loader Class Initialized
INFO - 2016-06-04 02:37:52 --> Helper loaded: url_helper
INFO - 2016-06-04 02:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:37:52 --> Controller Class Initialized
INFO - 2016-06-04 02:37:52 --> Helper loaded: language_helper
INFO - 2016-06-04 02:37:52 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:37:52 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\contact.php
INFO - 2016-06-04 02:37:52 --> Final output sent to browser
DEBUG - 2016-06-04 02:37:52 --> Total execution time: 0.1260
INFO - 2016-06-04 02:38:00 --> Config Class Initialized
INFO - 2016-06-04 02:38:00 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:38:00 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:38:00 --> Utf8 Class Initialized
INFO - 2016-06-04 02:38:00 --> URI Class Initialized
INFO - 2016-06-04 02:38:00 --> Router Class Initialized
INFO - 2016-06-04 02:38:00 --> Output Class Initialized
INFO - 2016-06-04 02:38:00 --> Security Class Initialized
DEBUG - 2016-06-04 02:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:38:00 --> Input Class Initialized
INFO - 2016-06-04 02:38:00 --> Language Class Initialized
ERROR - 2016-06-04 02:38:00 --> 404 Page Not Found: Site/service
INFO - 2016-06-04 02:38:04 --> Config Class Initialized
INFO - 2016-06-04 02:38:04 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:38:04 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:38:04 --> Utf8 Class Initialized
INFO - 2016-06-04 02:38:04 --> URI Class Initialized
INFO - 2016-06-04 02:38:04 --> Router Class Initialized
INFO - 2016-06-04 02:38:04 --> Output Class Initialized
INFO - 2016-06-04 02:38:04 --> Security Class Initialized
DEBUG - 2016-06-04 02:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:38:04 --> Input Class Initialized
INFO - 2016-06-04 02:38:04 --> Language Class Initialized
INFO - 2016-06-04 02:38:04 --> Loader Class Initialized
INFO - 2016-06-04 02:38:04 --> Helper loaded: url_helper
INFO - 2016-06-04 02:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:38:04 --> Controller Class Initialized
INFO - 2016-06-04 02:38:04 --> Helper loaded: language_helper
INFO - 2016-06-04 02:38:04 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:38:04 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 02:38:04 --> Final output sent to browser
DEBUG - 2016-06-04 02:38:04 --> Total execution time: 0.1380
INFO - 2016-06-04 02:38:08 --> Config Class Initialized
INFO - 2016-06-04 02:38:08 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:38:08 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:38:08 --> Utf8 Class Initialized
INFO - 2016-06-04 02:38:08 --> URI Class Initialized
INFO - 2016-06-04 02:38:08 --> Router Class Initialized
INFO - 2016-06-04 02:38:08 --> Output Class Initialized
INFO - 2016-06-04 02:38:08 --> Security Class Initialized
DEBUG - 2016-06-04 02:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:38:08 --> Input Class Initialized
INFO - 2016-06-04 02:38:08 --> Language Class Initialized
INFO - 2016-06-04 02:38:08 --> Loader Class Initialized
INFO - 2016-06-04 02:38:08 --> Helper loaded: url_helper
INFO - 2016-06-04 02:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:38:08 --> Controller Class Initialized
INFO - 2016-06-04 02:38:08 --> Config Class Initialized
INFO - 2016-06-04 02:38:08 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:38:08 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:38:08 --> Utf8 Class Initialized
INFO - 2016-06-04 02:38:08 --> URI Class Initialized
INFO - 2016-06-04 02:38:08 --> Router Class Initialized
INFO - 2016-06-04 02:38:08 --> Output Class Initialized
INFO - 2016-06-04 02:38:08 --> Security Class Initialized
DEBUG - 2016-06-04 02:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:38:08 --> Input Class Initialized
INFO - 2016-06-04 02:38:08 --> Language Class Initialized
INFO - 2016-06-04 02:38:08 --> Loader Class Initialized
INFO - 2016-06-04 02:38:08 --> Helper loaded: url_helper
INFO - 2016-06-04 02:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:38:08 --> Controller Class Initialized
INFO - 2016-06-04 02:38:08 --> Helper loaded: language_helper
INFO - 2016-06-04 02:38:08 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:38:08 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 02:38:08 --> Final output sent to browser
DEBUG - 2016-06-04 02:38:08 --> Total execution time: 0.1230
INFO - 2016-06-04 02:38:12 --> Config Class Initialized
INFO - 2016-06-04 02:38:12 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:38:12 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:38:12 --> Utf8 Class Initialized
INFO - 2016-06-04 02:38:12 --> URI Class Initialized
INFO - 2016-06-04 02:38:12 --> Router Class Initialized
INFO - 2016-06-04 02:38:12 --> Output Class Initialized
INFO - 2016-06-04 02:38:12 --> Security Class Initialized
DEBUG - 2016-06-04 02:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:38:12 --> Input Class Initialized
INFO - 2016-06-04 02:38:12 --> Language Class Initialized
INFO - 2016-06-04 02:38:13 --> Loader Class Initialized
INFO - 2016-06-04 02:38:13 --> Helper loaded: url_helper
INFO - 2016-06-04 02:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:38:13 --> Controller Class Initialized
INFO - 2016-06-04 02:38:13 --> Helper loaded: language_helper
INFO - 2016-06-04 02:38:13 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:38:13 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:38:13 --> Final output sent to browser
DEBUG - 2016-06-04 02:38:13 --> Total execution time: 0.1340
INFO - 2016-06-04 02:38:15 --> Config Class Initialized
INFO - 2016-06-04 02:38:15 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:38:15 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:38:15 --> Utf8 Class Initialized
INFO - 2016-06-04 02:38:15 --> URI Class Initialized
INFO - 2016-06-04 02:38:15 --> Router Class Initialized
INFO - 2016-06-04 02:38:15 --> Output Class Initialized
INFO - 2016-06-04 02:38:15 --> Security Class Initialized
DEBUG - 2016-06-04 02:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:38:15 --> Input Class Initialized
INFO - 2016-06-04 02:38:15 --> Language Class Initialized
INFO - 2016-06-04 02:38:15 --> Loader Class Initialized
INFO - 2016-06-04 02:38:15 --> Helper loaded: url_helper
INFO - 2016-06-04 02:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:38:15 --> Controller Class Initialized
INFO - 2016-06-04 02:38:15 --> Config Class Initialized
INFO - 2016-06-04 02:38:15 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:38:16 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:38:16 --> Utf8 Class Initialized
INFO - 2016-06-04 02:38:16 --> URI Class Initialized
INFO - 2016-06-04 02:38:16 --> Router Class Initialized
INFO - 2016-06-04 02:38:16 --> Output Class Initialized
INFO - 2016-06-04 02:38:16 --> Security Class Initialized
DEBUG - 2016-06-04 02:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:38:16 --> Input Class Initialized
INFO - 2016-06-04 02:38:16 --> Language Class Initialized
INFO - 2016-06-04 02:38:16 --> Loader Class Initialized
INFO - 2016-06-04 02:38:16 --> Helper loaded: url_helper
INFO - 2016-06-04 02:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:38:16 --> Controller Class Initialized
INFO - 2016-06-04 02:38:16 --> Helper loaded: language_helper
INFO - 2016-06-04 02:38:16 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:38:16 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:38:16 --> Final output sent to browser
DEBUG - 2016-06-04 02:38:16 --> Total execution time: 0.1220
INFO - 2016-06-04 02:38:22 --> Config Class Initialized
INFO - 2016-06-04 02:38:22 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:38:22 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:38:22 --> Utf8 Class Initialized
INFO - 2016-06-04 02:38:22 --> URI Class Initialized
INFO - 2016-06-04 02:38:22 --> Router Class Initialized
INFO - 2016-06-04 02:38:22 --> Output Class Initialized
INFO - 2016-06-04 02:38:22 --> Security Class Initialized
DEBUG - 2016-06-04 02:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:38:22 --> Input Class Initialized
INFO - 2016-06-04 02:38:22 --> Language Class Initialized
INFO - 2016-06-04 02:38:22 --> Loader Class Initialized
INFO - 2016-06-04 02:38:22 --> Helper loaded: url_helper
INFO - 2016-06-04 02:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:38:22 --> Controller Class Initialized
INFO - 2016-06-04 02:38:22 --> Helper loaded: language_helper
INFO - 2016-06-04 02:38:22 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:38:22 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 02:38:22 --> Final output sent to browser
DEBUG - 2016-06-04 02:38:22 --> Total execution time: 0.1410
INFO - 2016-06-04 02:38:26 --> Config Class Initialized
INFO - 2016-06-04 02:38:26 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:38:26 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:38:26 --> Utf8 Class Initialized
INFO - 2016-06-04 02:38:26 --> URI Class Initialized
INFO - 2016-06-04 02:38:26 --> Router Class Initialized
INFO - 2016-06-04 02:38:26 --> Output Class Initialized
INFO - 2016-06-04 02:38:26 --> Security Class Initialized
DEBUG - 2016-06-04 02:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:38:26 --> Input Class Initialized
INFO - 2016-06-04 02:38:26 --> Language Class Initialized
INFO - 2016-06-04 02:38:26 --> Loader Class Initialized
INFO - 2016-06-04 02:38:26 --> Helper loaded: url_helper
INFO - 2016-06-04 02:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:38:26 --> Controller Class Initialized
INFO - 2016-06-04 02:38:26 --> Helper loaded: language_helper
INFO - 2016-06-04 02:38:26 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:38:26 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 02:38:26 --> Final output sent to browser
DEBUG - 2016-06-04 02:38:26 --> Total execution time: 0.1330
INFO - 2016-06-04 02:38:32 --> Config Class Initialized
INFO - 2016-06-04 02:38:32 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:38:32 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:38:32 --> Utf8 Class Initialized
INFO - 2016-06-04 02:38:32 --> URI Class Initialized
INFO - 2016-06-04 02:38:32 --> Router Class Initialized
INFO - 2016-06-04 02:38:32 --> Output Class Initialized
INFO - 2016-06-04 02:38:32 --> Security Class Initialized
DEBUG - 2016-06-04 02:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:38:32 --> Input Class Initialized
INFO - 2016-06-04 02:38:32 --> Language Class Initialized
INFO - 2016-06-04 02:38:32 --> Loader Class Initialized
INFO - 2016-06-04 02:38:32 --> Helper loaded: url_helper
INFO - 2016-06-04 02:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:38:32 --> Controller Class Initialized
INFO - 2016-06-04 02:38:32 --> Config Class Initialized
INFO - 2016-06-04 02:38:32 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:38:32 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:38:32 --> Utf8 Class Initialized
INFO - 2016-06-04 02:38:32 --> URI Class Initialized
INFO - 2016-06-04 02:38:32 --> Router Class Initialized
INFO - 2016-06-04 02:38:32 --> Output Class Initialized
INFO - 2016-06-04 02:38:32 --> Security Class Initialized
DEBUG - 2016-06-04 02:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:38:32 --> Input Class Initialized
INFO - 2016-06-04 02:38:32 --> Language Class Initialized
INFO - 2016-06-04 02:38:32 --> Loader Class Initialized
INFO - 2016-06-04 02:38:32 --> Helper loaded: url_helper
INFO - 2016-06-04 02:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:38:32 --> Controller Class Initialized
INFO - 2016-06-04 02:38:32 --> Helper loaded: language_helper
INFO - 2016-06-04 02:38:32 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:38:32 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 02:38:32 --> Final output sent to browser
DEBUG - 2016-06-04 02:38:32 --> Total execution time: 0.1190
INFO - 2016-06-04 02:38:36 --> Config Class Initialized
INFO - 2016-06-04 02:38:36 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:38:36 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:38:36 --> Utf8 Class Initialized
INFO - 2016-06-04 02:38:36 --> URI Class Initialized
INFO - 2016-06-04 02:38:36 --> Router Class Initialized
INFO - 2016-06-04 02:38:36 --> Output Class Initialized
INFO - 2016-06-04 02:38:36 --> Security Class Initialized
DEBUG - 2016-06-04 02:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:38:36 --> Input Class Initialized
INFO - 2016-06-04 02:38:36 --> Language Class Initialized
INFO - 2016-06-04 02:38:36 --> Loader Class Initialized
INFO - 2016-06-04 02:38:36 --> Helper loaded: url_helper
INFO - 2016-06-04 02:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:38:36 --> Controller Class Initialized
INFO - 2016-06-04 02:38:36 --> Config Class Initialized
INFO - 2016-06-04 02:38:36 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:38:36 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:38:36 --> Utf8 Class Initialized
INFO - 2016-06-04 02:38:36 --> URI Class Initialized
INFO - 2016-06-04 02:38:36 --> Router Class Initialized
INFO - 2016-06-04 02:38:36 --> Output Class Initialized
INFO - 2016-06-04 02:38:36 --> Security Class Initialized
DEBUG - 2016-06-04 02:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:38:36 --> Input Class Initialized
INFO - 2016-06-04 02:38:36 --> Language Class Initialized
INFO - 2016-06-04 02:38:36 --> Loader Class Initialized
INFO - 2016-06-04 02:38:36 --> Helper loaded: url_helper
INFO - 2016-06-04 02:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:38:36 --> Controller Class Initialized
INFO - 2016-06-04 02:38:36 --> Helper loaded: language_helper
INFO - 2016-06-04 02:38:36 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:38:36 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 02:38:36 --> Final output sent to browser
DEBUG - 2016-06-04 02:38:36 --> Total execution time: 0.1170
INFO - 2016-06-04 02:40:23 --> Config Class Initialized
INFO - 2016-06-04 02:40:23 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:40:23 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:40:23 --> Utf8 Class Initialized
INFO - 2016-06-04 02:40:23 --> URI Class Initialized
INFO - 2016-06-04 02:40:23 --> Router Class Initialized
INFO - 2016-06-04 02:40:23 --> Output Class Initialized
INFO - 2016-06-04 02:40:23 --> Security Class Initialized
DEBUG - 2016-06-04 02:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:40:23 --> Input Class Initialized
INFO - 2016-06-04 02:40:23 --> Language Class Initialized
INFO - 2016-06-04 02:40:23 --> Loader Class Initialized
INFO - 2016-06-04 02:40:23 --> Helper loaded: url_helper
INFO - 2016-06-04 02:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:40:23 --> Controller Class Initialized
INFO - 2016-06-04 02:40:23 --> Helper loaded: language_helper
INFO - 2016-06-04 02:40:23 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:40:23 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 02:40:23 --> Final output sent to browser
DEBUG - 2016-06-04 02:40:23 --> Total execution time: 0.1300
INFO - 2016-06-04 02:40:28 --> Config Class Initialized
INFO - 2016-06-04 02:40:28 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:40:28 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:40:28 --> Utf8 Class Initialized
INFO - 2016-06-04 02:40:28 --> URI Class Initialized
INFO - 2016-06-04 02:40:28 --> Router Class Initialized
INFO - 2016-06-04 02:40:28 --> Output Class Initialized
INFO - 2016-06-04 02:40:28 --> Security Class Initialized
DEBUG - 2016-06-04 02:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:40:28 --> Input Class Initialized
INFO - 2016-06-04 02:40:28 --> Language Class Initialized
INFO - 2016-06-04 02:40:28 --> Loader Class Initialized
INFO - 2016-06-04 02:40:28 --> Helper loaded: url_helper
INFO - 2016-06-04 02:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:40:28 --> Controller Class Initialized
INFO - 2016-06-04 02:40:28 --> Helper loaded: language_helper
INFO - 2016-06-04 02:40:29 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:40:29 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 02:40:29 --> Final output sent to browser
DEBUG - 2016-06-04 02:40:29 --> Total execution time: 0.1240
INFO - 2016-06-04 02:40:31 --> Config Class Initialized
INFO - 2016-06-04 02:40:31 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:40:31 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:40:31 --> Utf8 Class Initialized
INFO - 2016-06-04 02:40:31 --> URI Class Initialized
INFO - 2016-06-04 02:40:31 --> Router Class Initialized
INFO - 2016-06-04 02:40:31 --> Output Class Initialized
INFO - 2016-06-04 02:40:31 --> Security Class Initialized
DEBUG - 2016-06-04 02:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:40:31 --> Input Class Initialized
INFO - 2016-06-04 02:40:31 --> Language Class Initialized
INFO - 2016-06-04 02:40:31 --> Loader Class Initialized
INFO - 2016-06-04 02:40:31 --> Helper loaded: url_helper
INFO - 2016-06-04 02:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:40:31 --> Controller Class Initialized
INFO - 2016-06-04 02:40:31 --> Config Class Initialized
INFO - 2016-06-04 02:40:31 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:40:31 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:40:31 --> Utf8 Class Initialized
INFO - 2016-06-04 02:40:31 --> URI Class Initialized
INFO - 2016-06-04 02:40:31 --> Router Class Initialized
INFO - 2016-06-04 02:40:31 --> Output Class Initialized
INFO - 2016-06-04 02:40:31 --> Security Class Initialized
DEBUG - 2016-06-04 02:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:40:31 --> Input Class Initialized
INFO - 2016-06-04 02:40:31 --> Language Class Initialized
INFO - 2016-06-04 02:40:31 --> Loader Class Initialized
INFO - 2016-06-04 02:40:31 --> Helper loaded: url_helper
INFO - 2016-06-04 02:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:40:31 --> Controller Class Initialized
INFO - 2016-06-04 02:40:31 --> Helper loaded: language_helper
INFO - 2016-06-04 02:40:31 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:40:31 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 02:40:31 --> Final output sent to browser
DEBUG - 2016-06-04 02:40:31 --> Total execution time: 0.1210
INFO - 2016-06-04 02:40:38 --> Config Class Initialized
INFO - 2016-06-04 02:40:38 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:40:38 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:40:38 --> Utf8 Class Initialized
INFO - 2016-06-04 02:40:38 --> URI Class Initialized
INFO - 2016-06-04 02:40:38 --> Router Class Initialized
INFO - 2016-06-04 02:40:38 --> Output Class Initialized
INFO - 2016-06-04 02:40:38 --> Security Class Initialized
DEBUG - 2016-06-04 02:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:40:38 --> Input Class Initialized
INFO - 2016-06-04 02:40:38 --> Language Class Initialized
INFO - 2016-06-04 02:40:38 --> Loader Class Initialized
INFO - 2016-06-04 02:40:38 --> Helper loaded: url_helper
INFO - 2016-06-04 02:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:40:38 --> Controller Class Initialized
INFO - 2016-06-04 02:40:38 --> Helper loaded: language_helper
INFO - 2016-06-04 02:40:38 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:40:38 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\contact.php
INFO - 2016-06-04 02:40:38 --> Final output sent to browser
DEBUG - 2016-06-04 02:40:38 --> Total execution time: 0.1280
INFO - 2016-06-04 02:43:47 --> Config Class Initialized
INFO - 2016-06-04 02:43:47 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:43:47 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:43:47 --> Utf8 Class Initialized
INFO - 2016-06-04 02:43:47 --> URI Class Initialized
INFO - 2016-06-04 02:43:47 --> Router Class Initialized
INFO - 2016-06-04 02:43:47 --> Output Class Initialized
INFO - 2016-06-04 02:43:47 --> Security Class Initialized
DEBUG - 2016-06-04 02:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:43:47 --> Input Class Initialized
INFO - 2016-06-04 02:43:47 --> Language Class Initialized
INFO - 2016-06-04 02:43:47 --> Loader Class Initialized
INFO - 2016-06-04 02:43:47 --> Helper loaded: url_helper
INFO - 2016-06-04 02:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:43:47 --> Controller Class Initialized
INFO - 2016-06-04 02:43:47 --> Helper loaded: language_helper
INFO - 2016-06-04 02:43:47 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:43:47 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\contact.php
INFO - 2016-06-04 02:43:47 --> Final output sent to browser
DEBUG - 2016-06-04 02:43:47 --> Total execution time: 0.1370
INFO - 2016-06-04 02:43:50 --> Config Class Initialized
INFO - 2016-06-04 02:43:50 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:43:50 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:43:50 --> Utf8 Class Initialized
INFO - 2016-06-04 02:43:50 --> URI Class Initialized
INFO - 2016-06-04 02:43:50 --> Router Class Initialized
INFO - 2016-06-04 02:43:50 --> Output Class Initialized
INFO - 2016-06-04 02:43:50 --> Security Class Initialized
DEBUG - 2016-06-04 02:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:43:50 --> Input Class Initialized
INFO - 2016-06-04 02:43:50 --> Language Class Initialized
INFO - 2016-06-04 02:43:50 --> Loader Class Initialized
INFO - 2016-06-04 02:43:50 --> Helper loaded: url_helper
INFO - 2016-06-04 02:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:43:50 --> Controller Class Initialized
INFO - 2016-06-04 02:43:50 --> Helper loaded: language_helper
INFO - 2016-06-04 02:43:50 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:43:50 --> Config Class Initialized
INFO - 2016-06-04 02:43:50 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:43:50 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:43:50 --> Utf8 Class Initialized
INFO - 2016-06-04 02:43:50 --> URI Class Initialized
INFO - 2016-06-04 02:43:50 --> Router Class Initialized
INFO - 2016-06-04 02:43:50 --> Output Class Initialized
INFO - 2016-06-04 02:43:50 --> Security Class Initialized
DEBUG - 2016-06-04 02:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:43:50 --> Input Class Initialized
INFO - 2016-06-04 02:43:50 --> Language Class Initialized
INFO - 2016-06-04 02:43:50 --> Loader Class Initialized
INFO - 2016-06-04 02:43:50 --> Helper loaded: url_helper
INFO - 2016-06-04 02:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:43:50 --> Controller Class Initialized
INFO - 2016-06-04 02:43:50 --> Helper loaded: language_helper
INFO - 2016-06-04 02:43:50 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:43:50 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\contact.php
INFO - 2016-06-04 02:43:50 --> Final output sent to browser
DEBUG - 2016-06-04 02:43:50 --> Total execution time: 0.1200
INFO - 2016-06-04 02:43:51 --> Config Class Initialized
INFO - 2016-06-04 02:43:51 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:43:51 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:43:51 --> Utf8 Class Initialized
INFO - 2016-06-04 02:43:51 --> URI Class Initialized
INFO - 2016-06-04 02:43:51 --> Router Class Initialized
INFO - 2016-06-04 02:43:51 --> Output Class Initialized
INFO - 2016-06-04 02:43:51 --> Security Class Initialized
DEBUG - 2016-06-04 02:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:43:51 --> Input Class Initialized
INFO - 2016-06-04 02:43:51 --> Language Class Initialized
INFO - 2016-06-04 02:43:51 --> Loader Class Initialized
INFO - 2016-06-04 02:43:51 --> Helper loaded: url_helper
INFO - 2016-06-04 02:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:43:51 --> Controller Class Initialized
INFO - 2016-06-04 02:43:51 --> Helper loaded: language_helper
INFO - 2016-06-04 02:43:51 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:43:51 --> Config Class Initialized
INFO - 2016-06-04 02:43:51 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:43:52 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:43:52 --> Utf8 Class Initialized
INFO - 2016-06-04 02:43:52 --> URI Class Initialized
INFO - 2016-06-04 02:43:52 --> Router Class Initialized
INFO - 2016-06-04 02:43:52 --> Output Class Initialized
INFO - 2016-06-04 02:43:52 --> Security Class Initialized
DEBUG - 2016-06-04 02:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:43:52 --> Input Class Initialized
INFO - 2016-06-04 02:43:52 --> Language Class Initialized
INFO - 2016-06-04 02:43:52 --> Loader Class Initialized
INFO - 2016-06-04 02:43:52 --> Helper loaded: url_helper
INFO - 2016-06-04 02:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:43:52 --> Controller Class Initialized
INFO - 2016-06-04 02:43:52 --> Helper loaded: language_helper
INFO - 2016-06-04 02:43:52 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:43:52 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\contact.php
INFO - 2016-06-04 02:43:52 --> Final output sent to browser
DEBUG - 2016-06-04 02:43:52 --> Total execution time: 0.1370
INFO - 2016-06-04 02:45:51 --> Config Class Initialized
INFO - 2016-06-04 02:45:51 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:45:51 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:45:51 --> Utf8 Class Initialized
INFO - 2016-06-04 02:45:51 --> URI Class Initialized
INFO - 2016-06-04 02:45:51 --> Router Class Initialized
INFO - 2016-06-04 02:45:51 --> Output Class Initialized
INFO - 2016-06-04 02:45:51 --> Security Class Initialized
DEBUG - 2016-06-04 02:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:45:51 --> Input Class Initialized
INFO - 2016-06-04 02:45:51 --> Language Class Initialized
ERROR - 2016-06-04 02:45:51 --> 404 Page Not Found: LangSwitcher/switchLang
INFO - 2016-06-04 02:45:57 --> Config Class Initialized
INFO - 2016-06-04 02:45:57 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:45:57 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:45:57 --> Utf8 Class Initialized
INFO - 2016-06-04 02:45:57 --> URI Class Initialized
INFO - 2016-06-04 02:45:57 --> Router Class Initialized
INFO - 2016-06-04 02:45:57 --> Output Class Initialized
INFO - 2016-06-04 02:45:57 --> Security Class Initialized
DEBUG - 2016-06-04 02:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:45:57 --> Input Class Initialized
INFO - 2016-06-04 02:45:57 --> Language Class Initialized
ERROR - 2016-06-04 02:45:57 --> 404 Page Not Found: LangSwitcher/switchLang
INFO - 2016-06-04 02:46:01 --> Config Class Initialized
INFO - 2016-06-04 02:46:01 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:46:01 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:46:01 --> Utf8 Class Initialized
INFO - 2016-06-04 02:46:01 --> URI Class Initialized
DEBUG - 2016-06-04 02:46:01 --> No URI present. Default controller set.
INFO - 2016-06-04 02:46:01 --> Router Class Initialized
INFO - 2016-06-04 02:46:01 --> Output Class Initialized
INFO - 2016-06-04 02:46:01 --> Security Class Initialized
DEBUG - 2016-06-04 02:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:46:01 --> Input Class Initialized
INFO - 2016-06-04 02:46:01 --> Language Class Initialized
INFO - 2016-06-04 02:46:01 --> Loader Class Initialized
INFO - 2016-06-04 02:46:01 --> Helper loaded: url_helper
INFO - 2016-06-04 02:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:46:01 --> Controller Class Initialized
INFO - 2016-06-04 02:46:01 --> Helper loaded: language_helper
INFO - 2016-06-04 02:46:01 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:46:01 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:46:01 --> Final output sent to browser
DEBUG - 2016-06-04 02:46:01 --> Total execution time: 0.1360
INFO - 2016-06-04 02:46:03 --> Config Class Initialized
INFO - 2016-06-04 02:46:03 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:46:03 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:46:03 --> Utf8 Class Initialized
INFO - 2016-06-04 02:46:03 --> URI Class Initialized
INFO - 2016-06-04 02:46:03 --> Router Class Initialized
INFO - 2016-06-04 02:46:03 --> Output Class Initialized
INFO - 2016-06-04 02:46:03 --> Security Class Initialized
DEBUG - 2016-06-04 02:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:46:03 --> Input Class Initialized
INFO - 2016-06-04 02:46:03 --> Language Class Initialized
INFO - 2016-06-04 02:46:03 --> Loader Class Initialized
INFO - 2016-06-04 02:46:03 --> Helper loaded: url_helper
INFO - 2016-06-04 02:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:46:03 --> Controller Class Initialized
INFO - 2016-06-04 02:46:03 --> Helper loaded: language_helper
INFO - 2016-06-04 02:46:03 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:46:03 --> Config Class Initialized
INFO - 2016-06-04 02:46:03 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:46:03 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:46:03 --> Utf8 Class Initialized
INFO - 2016-06-04 02:46:03 --> URI Class Initialized
DEBUG - 2016-06-04 02:46:03 --> No URI present. Default controller set.
INFO - 2016-06-04 02:46:03 --> Router Class Initialized
INFO - 2016-06-04 02:46:03 --> Output Class Initialized
INFO - 2016-06-04 02:46:03 --> Security Class Initialized
DEBUG - 2016-06-04 02:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:46:03 --> Input Class Initialized
INFO - 2016-06-04 02:46:03 --> Language Class Initialized
INFO - 2016-06-04 02:46:03 --> Loader Class Initialized
INFO - 2016-06-04 02:46:03 --> Helper loaded: url_helper
INFO - 2016-06-04 02:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:46:03 --> Controller Class Initialized
INFO - 2016-06-04 02:46:03 --> Helper loaded: language_helper
INFO - 2016-06-04 02:46:03 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:46:03 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:46:03 --> Final output sent to browser
DEBUG - 2016-06-04 02:46:03 --> Total execution time: 0.1310
INFO - 2016-06-04 02:46:05 --> Config Class Initialized
INFO - 2016-06-04 02:46:05 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:46:05 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:46:05 --> Utf8 Class Initialized
INFO - 2016-06-04 02:46:05 --> URI Class Initialized
INFO - 2016-06-04 02:46:05 --> Router Class Initialized
INFO - 2016-06-04 02:46:05 --> Output Class Initialized
INFO - 2016-06-04 02:46:05 --> Security Class Initialized
DEBUG - 2016-06-04 02:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:46:05 --> Input Class Initialized
INFO - 2016-06-04 02:46:05 --> Language Class Initialized
INFO - 2016-06-04 02:46:05 --> Loader Class Initialized
INFO - 2016-06-04 02:46:05 --> Helper loaded: url_helper
INFO - 2016-06-04 02:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:46:05 --> Controller Class Initialized
INFO - 2016-06-04 02:46:05 --> Helper loaded: language_helper
INFO - 2016-06-04 02:46:05 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:46:05 --> Config Class Initialized
INFO - 2016-06-04 02:46:05 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:46:05 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:46:05 --> Utf8 Class Initialized
INFO - 2016-06-04 02:46:05 --> URI Class Initialized
DEBUG - 2016-06-04 02:46:05 --> No URI present. Default controller set.
INFO - 2016-06-04 02:46:05 --> Router Class Initialized
INFO - 2016-06-04 02:46:05 --> Output Class Initialized
INFO - 2016-06-04 02:46:05 --> Security Class Initialized
DEBUG - 2016-06-04 02:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:46:05 --> Input Class Initialized
INFO - 2016-06-04 02:46:05 --> Language Class Initialized
INFO - 2016-06-04 02:46:05 --> Loader Class Initialized
INFO - 2016-06-04 02:46:05 --> Helper loaded: url_helper
INFO - 2016-06-04 02:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:46:05 --> Controller Class Initialized
INFO - 2016-06-04 02:46:05 --> Helper loaded: language_helper
INFO - 2016-06-04 02:46:05 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:46:05 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:46:05 --> Final output sent to browser
DEBUG - 2016-06-04 02:46:05 --> Total execution time: 0.1280
INFO - 2016-06-04 02:46:10 --> Config Class Initialized
INFO - 2016-06-04 02:46:10 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:46:10 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:46:10 --> Utf8 Class Initialized
INFO - 2016-06-04 02:46:10 --> URI Class Initialized
INFO - 2016-06-04 02:46:10 --> Router Class Initialized
INFO - 2016-06-04 02:46:10 --> Output Class Initialized
INFO - 2016-06-04 02:46:10 --> Security Class Initialized
DEBUG - 2016-06-04 02:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:46:10 --> Input Class Initialized
INFO - 2016-06-04 02:46:10 --> Language Class Initialized
INFO - 2016-06-04 02:46:10 --> Loader Class Initialized
INFO - 2016-06-04 02:46:10 --> Helper loaded: url_helper
INFO - 2016-06-04 02:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:46:10 --> Controller Class Initialized
INFO - 2016-06-04 02:46:10 --> Helper loaded: language_helper
INFO - 2016-06-04 02:46:10 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:46:10 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 02:46:10 --> Final output sent to browser
DEBUG - 2016-06-04 02:46:10 --> Total execution time: 0.1340
INFO - 2016-06-04 02:46:13 --> Config Class Initialized
INFO - 2016-06-04 02:46:13 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:46:13 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:46:13 --> Utf8 Class Initialized
INFO - 2016-06-04 02:46:13 --> URI Class Initialized
INFO - 2016-06-04 02:46:13 --> Router Class Initialized
INFO - 2016-06-04 02:46:13 --> Output Class Initialized
INFO - 2016-06-04 02:46:13 --> Security Class Initialized
DEBUG - 2016-06-04 02:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:46:13 --> Input Class Initialized
INFO - 2016-06-04 02:46:13 --> Language Class Initialized
INFO - 2016-06-04 02:46:13 --> Loader Class Initialized
INFO - 2016-06-04 02:46:13 --> Helper loaded: url_helper
INFO - 2016-06-04 02:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:46:13 --> Controller Class Initialized
INFO - 2016-06-04 02:46:13 --> Helper loaded: language_helper
INFO - 2016-06-04 02:46:13 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:46:13 --> Config Class Initialized
INFO - 2016-06-04 02:46:13 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:46:13 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:46:13 --> Utf8 Class Initialized
INFO - 2016-06-04 02:46:13 --> URI Class Initialized
INFO - 2016-06-04 02:46:13 --> Router Class Initialized
INFO - 2016-06-04 02:46:13 --> Output Class Initialized
INFO - 2016-06-04 02:46:13 --> Security Class Initialized
DEBUG - 2016-06-04 02:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:46:13 --> Input Class Initialized
INFO - 2016-06-04 02:46:13 --> Language Class Initialized
INFO - 2016-06-04 02:46:13 --> Loader Class Initialized
INFO - 2016-06-04 02:46:13 --> Helper loaded: url_helper
INFO - 2016-06-04 02:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:46:13 --> Controller Class Initialized
INFO - 2016-06-04 02:46:13 --> Helper loaded: language_helper
INFO - 2016-06-04 02:46:13 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:46:13 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 02:46:13 --> Final output sent to browser
DEBUG - 2016-06-04 02:46:13 --> Total execution time: 0.1270
INFO - 2016-06-04 02:46:15 --> Config Class Initialized
INFO - 2016-06-04 02:46:15 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:46:15 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:46:15 --> Utf8 Class Initialized
INFO - 2016-06-04 02:46:15 --> URI Class Initialized
INFO - 2016-06-04 02:46:15 --> Router Class Initialized
INFO - 2016-06-04 02:46:15 --> Output Class Initialized
INFO - 2016-06-04 02:46:15 --> Security Class Initialized
DEBUG - 2016-06-04 02:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:46:15 --> Input Class Initialized
INFO - 2016-06-04 02:46:15 --> Language Class Initialized
INFO - 2016-06-04 02:46:15 --> Loader Class Initialized
INFO - 2016-06-04 02:46:15 --> Helper loaded: url_helper
INFO - 2016-06-04 02:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:46:15 --> Controller Class Initialized
INFO - 2016-06-04 02:46:15 --> Helper loaded: language_helper
INFO - 2016-06-04 02:46:15 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:46:15 --> Config Class Initialized
INFO - 2016-06-04 02:46:15 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:46:15 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:46:15 --> Utf8 Class Initialized
INFO - 2016-06-04 02:46:15 --> URI Class Initialized
INFO - 2016-06-04 02:46:15 --> Router Class Initialized
INFO - 2016-06-04 02:46:15 --> Output Class Initialized
INFO - 2016-06-04 02:46:15 --> Security Class Initialized
DEBUG - 2016-06-04 02:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:46:15 --> Input Class Initialized
INFO - 2016-06-04 02:46:15 --> Language Class Initialized
INFO - 2016-06-04 02:46:15 --> Loader Class Initialized
INFO - 2016-06-04 02:46:15 --> Helper loaded: url_helper
INFO - 2016-06-04 02:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:46:15 --> Controller Class Initialized
INFO - 2016-06-04 02:46:15 --> Helper loaded: language_helper
INFO - 2016-06-04 02:46:15 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:46:15 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 02:46:15 --> Final output sent to browser
DEBUG - 2016-06-04 02:46:15 --> Total execution time: 0.1340
INFO - 2016-06-04 02:47:28 --> Config Class Initialized
INFO - 2016-06-04 02:47:28 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:47:29 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:47:29 --> Utf8 Class Initialized
INFO - 2016-06-04 02:47:29 --> URI Class Initialized
INFO - 2016-06-04 02:47:29 --> Router Class Initialized
INFO - 2016-06-04 02:47:29 --> Output Class Initialized
INFO - 2016-06-04 02:47:29 --> Security Class Initialized
DEBUG - 2016-06-04 02:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:47:29 --> Input Class Initialized
INFO - 2016-06-04 02:47:29 --> Language Class Initialized
INFO - 2016-06-04 02:47:29 --> Loader Class Initialized
INFO - 2016-06-04 02:47:29 --> Helper loaded: url_helper
INFO - 2016-06-04 02:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:47:29 --> Controller Class Initialized
INFO - 2016-06-04 02:47:29 --> Helper loaded: language_helper
INFO - 2016-06-04 02:47:29 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:47:29 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 02:47:29 --> Final output sent to browser
DEBUG - 2016-06-04 02:47:29 --> Total execution time: 0.1380
INFO - 2016-06-04 02:47:33 --> Config Class Initialized
INFO - 2016-06-04 02:47:33 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:47:33 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:47:33 --> Utf8 Class Initialized
INFO - 2016-06-04 02:47:33 --> URI Class Initialized
INFO - 2016-06-04 02:47:33 --> Router Class Initialized
INFO - 2016-06-04 02:47:33 --> Output Class Initialized
INFO - 2016-06-04 02:47:33 --> Security Class Initialized
DEBUG - 2016-06-04 02:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:47:33 --> Input Class Initialized
INFO - 2016-06-04 02:47:33 --> Language Class Initialized
INFO - 2016-06-04 02:47:33 --> Loader Class Initialized
INFO - 2016-06-04 02:47:33 --> Helper loaded: url_helper
INFO - 2016-06-04 02:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:47:33 --> Controller Class Initialized
INFO - 2016-06-04 02:47:33 --> Helper loaded: language_helper
INFO - 2016-06-04 02:47:33 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:47:33 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 02:47:33 --> Final output sent to browser
DEBUG - 2016-06-04 02:47:33 --> Total execution time: 0.1490
INFO - 2016-06-04 02:47:35 --> Config Class Initialized
INFO - 2016-06-04 02:47:35 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:47:35 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:47:35 --> Utf8 Class Initialized
INFO - 2016-06-04 02:47:35 --> URI Class Initialized
DEBUG - 2016-06-04 02:47:35 --> No URI present. Default controller set.
INFO - 2016-06-04 02:47:35 --> Router Class Initialized
INFO - 2016-06-04 02:47:35 --> Output Class Initialized
INFO - 2016-06-04 02:47:35 --> Security Class Initialized
DEBUG - 2016-06-04 02:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:47:35 --> Input Class Initialized
INFO - 2016-06-04 02:47:35 --> Language Class Initialized
INFO - 2016-06-04 02:47:35 --> Loader Class Initialized
INFO - 2016-06-04 02:47:35 --> Helper loaded: url_helper
INFO - 2016-06-04 02:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:47:35 --> Controller Class Initialized
INFO - 2016-06-04 02:47:35 --> Helper loaded: language_helper
INFO - 2016-06-04 02:47:35 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:47:35 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:47:35 --> Final output sent to browser
DEBUG - 2016-06-04 02:47:35 --> Total execution time: 0.1360
INFO - 2016-06-04 02:47:36 --> Config Class Initialized
INFO - 2016-06-04 02:47:36 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:47:36 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:47:36 --> Utf8 Class Initialized
INFO - 2016-06-04 02:47:36 --> URI Class Initialized
DEBUG - 2016-06-04 02:47:36 --> No URI present. Default controller set.
INFO - 2016-06-04 02:47:36 --> Router Class Initialized
INFO - 2016-06-04 02:47:36 --> Output Class Initialized
INFO - 2016-06-04 02:47:36 --> Security Class Initialized
DEBUG - 2016-06-04 02:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:47:36 --> Input Class Initialized
INFO - 2016-06-04 02:47:36 --> Language Class Initialized
INFO - 2016-06-04 02:47:36 --> Loader Class Initialized
INFO - 2016-06-04 02:47:36 --> Helper loaded: url_helper
INFO - 2016-06-04 02:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:47:36 --> Controller Class Initialized
INFO - 2016-06-04 02:47:36 --> Helper loaded: language_helper
INFO - 2016-06-04 02:47:36 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:47:36 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:47:36 --> Final output sent to browser
DEBUG - 2016-06-04 02:47:36 --> Total execution time: 0.1580
INFO - 2016-06-04 02:48:07 --> Config Class Initialized
INFO - 2016-06-04 02:48:07 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:48:07 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:48:07 --> Utf8 Class Initialized
INFO - 2016-06-04 02:48:07 --> URI Class Initialized
DEBUG - 2016-06-04 02:48:07 --> No URI present. Default controller set.
INFO - 2016-06-04 02:48:07 --> Router Class Initialized
INFO - 2016-06-04 02:48:07 --> Output Class Initialized
INFO - 2016-06-04 02:48:07 --> Security Class Initialized
DEBUG - 2016-06-04 02:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:48:07 --> Input Class Initialized
INFO - 2016-06-04 02:48:07 --> Language Class Initialized
INFO - 2016-06-04 02:48:07 --> Loader Class Initialized
INFO - 2016-06-04 02:48:07 --> Helper loaded: url_helper
INFO - 2016-06-04 02:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:48:07 --> Controller Class Initialized
INFO - 2016-06-04 02:48:07 --> Helper loaded: language_helper
INFO - 2016-06-04 02:48:07 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:48:07 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:48:07 --> Final output sent to browser
DEBUG - 2016-06-04 02:48:07 --> Total execution time: 0.1450
INFO - 2016-06-04 02:48:11 --> Config Class Initialized
INFO - 2016-06-04 02:48:11 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:48:11 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:48:11 --> Utf8 Class Initialized
INFO - 2016-06-04 02:48:11 --> URI Class Initialized
DEBUG - 2016-06-04 02:48:11 --> No URI present. Default controller set.
INFO - 2016-06-04 02:48:11 --> Router Class Initialized
INFO - 2016-06-04 02:48:11 --> Output Class Initialized
INFO - 2016-06-04 02:48:11 --> Security Class Initialized
DEBUG - 2016-06-04 02:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:48:11 --> Input Class Initialized
INFO - 2016-06-04 02:48:11 --> Language Class Initialized
INFO - 2016-06-04 02:48:11 --> Loader Class Initialized
INFO - 2016-06-04 02:48:11 --> Helper loaded: url_helper
INFO - 2016-06-04 02:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:48:11 --> Controller Class Initialized
INFO - 2016-06-04 02:48:11 --> Helper loaded: language_helper
INFO - 2016-06-04 02:48:11 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:48:11 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:48:11 --> Final output sent to browser
DEBUG - 2016-06-04 02:48:11 --> Total execution time: 0.1470
INFO - 2016-06-04 02:54:17 --> Config Class Initialized
INFO - 2016-06-04 02:54:17 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:54:17 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:54:17 --> Utf8 Class Initialized
INFO - 2016-06-04 02:54:17 --> URI Class Initialized
DEBUG - 2016-06-04 02:54:17 --> No URI present. Default controller set.
INFO - 2016-06-04 02:54:17 --> Router Class Initialized
INFO - 2016-06-04 02:54:17 --> Output Class Initialized
INFO - 2016-06-04 02:54:17 --> Security Class Initialized
DEBUG - 2016-06-04 02:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:54:17 --> Input Class Initialized
INFO - 2016-06-04 02:54:17 --> Language Class Initialized
INFO - 2016-06-04 02:54:17 --> Loader Class Initialized
INFO - 2016-06-04 02:54:17 --> Helper loaded: url_helper
INFO - 2016-06-04 02:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:54:17 --> Controller Class Initialized
INFO - 2016-06-04 02:54:17 --> Helper loaded: language_helper
INFO - 2016-06-04 02:54:17 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:54:17 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:54:17 --> Final output sent to browser
DEBUG - 2016-06-04 02:54:17 --> Total execution time: 0.1820
INFO - 2016-06-04 02:54:17 --> Config Class Initialized
INFO - 2016-06-04 02:54:17 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:54:17 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:54:17 --> Utf8 Class Initialized
INFO - 2016-06-04 02:54:17 --> URI Class Initialized
INFO - 2016-06-04 02:54:17 --> Router Class Initialized
INFO - 2016-06-04 02:54:17 --> Output Class Initialized
INFO - 2016-06-04 02:54:17 --> Security Class Initialized
DEBUG - 2016-06-04 02:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:54:17 --> Input Class Initialized
INFO - 2016-06-04 02:54:17 --> Language Class Initialized
ERROR - 2016-06-04 02:54:17 --> 404 Page Not Found: Flag-engpng/index
INFO - 2016-06-04 02:54:19 --> Config Class Initialized
INFO - 2016-06-04 02:54:19 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:54:19 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:54:19 --> Utf8 Class Initialized
INFO - 2016-06-04 02:54:19 --> URI Class Initialized
INFO - 2016-06-04 02:54:19 --> Router Class Initialized
INFO - 2016-06-04 02:54:19 --> Output Class Initialized
INFO - 2016-06-04 02:54:19 --> Security Class Initialized
DEBUG - 2016-06-04 02:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:54:19 --> Input Class Initialized
INFO - 2016-06-04 02:54:19 --> Language Class Initialized
INFO - 2016-06-04 02:54:19 --> Loader Class Initialized
INFO - 2016-06-04 02:54:19 --> Helper loaded: url_helper
INFO - 2016-06-04 02:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:54:19 --> Controller Class Initialized
INFO - 2016-06-04 02:54:19 --> Helper loaded: language_helper
INFO - 2016-06-04 02:54:19 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:54:19 --> Config Class Initialized
INFO - 2016-06-04 02:54:19 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:54:19 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:54:19 --> Utf8 Class Initialized
INFO - 2016-06-04 02:54:19 --> URI Class Initialized
DEBUG - 2016-06-04 02:54:20 --> No URI present. Default controller set.
INFO - 2016-06-04 02:54:20 --> Router Class Initialized
INFO - 2016-06-04 02:54:20 --> Output Class Initialized
INFO - 2016-06-04 02:54:20 --> Security Class Initialized
DEBUG - 2016-06-04 02:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:54:20 --> Input Class Initialized
INFO - 2016-06-04 02:54:20 --> Language Class Initialized
INFO - 2016-06-04 02:54:20 --> Loader Class Initialized
INFO - 2016-06-04 02:54:20 --> Helper loaded: url_helper
INFO - 2016-06-04 02:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:54:20 --> Controller Class Initialized
INFO - 2016-06-04 02:54:20 --> Helper loaded: language_helper
INFO - 2016-06-04 02:54:20 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:54:20 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:54:20 --> Final output sent to browser
DEBUG - 2016-06-04 02:54:20 --> Total execution time: 0.1680
INFO - 2016-06-04 02:54:20 --> Config Class Initialized
INFO - 2016-06-04 02:54:20 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:54:20 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:54:20 --> Utf8 Class Initialized
INFO - 2016-06-04 02:54:20 --> URI Class Initialized
INFO - 2016-06-04 02:54:20 --> Router Class Initialized
INFO - 2016-06-04 02:54:20 --> Output Class Initialized
INFO - 2016-06-04 02:54:20 --> Security Class Initialized
DEBUG - 2016-06-04 02:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:54:20 --> Input Class Initialized
INFO - 2016-06-04 02:54:20 --> Language Class Initialized
ERROR - 2016-06-04 02:54:20 --> 404 Page Not Found: Flag-engpng/index
INFO - 2016-06-04 02:54:21 --> Config Class Initialized
INFO - 2016-06-04 02:54:21 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:54:21 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:54:21 --> Utf8 Class Initialized
INFO - 2016-06-04 02:54:21 --> URI Class Initialized
DEBUG - 2016-06-04 02:54:21 --> No URI present. Default controller set.
INFO - 2016-06-04 02:54:21 --> Router Class Initialized
INFO - 2016-06-04 02:54:21 --> Output Class Initialized
INFO - 2016-06-04 02:54:21 --> Security Class Initialized
DEBUG - 2016-06-04 02:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:54:21 --> Input Class Initialized
INFO - 2016-06-04 02:54:21 --> Language Class Initialized
INFO - 2016-06-04 02:54:21 --> Loader Class Initialized
INFO - 2016-06-04 02:54:21 --> Helper loaded: url_helper
INFO - 2016-06-04 02:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:54:21 --> Controller Class Initialized
INFO - 2016-06-04 02:54:21 --> Helper loaded: language_helper
INFO - 2016-06-04 02:54:21 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:54:21 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:54:21 --> Final output sent to browser
DEBUG - 2016-06-04 02:54:21 --> Total execution time: 0.2070
INFO - 2016-06-04 02:54:21 --> Config Class Initialized
INFO - 2016-06-04 02:54:21 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:54:21 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:54:21 --> Utf8 Class Initialized
INFO - 2016-06-04 02:54:21 --> URI Class Initialized
INFO - 2016-06-04 02:54:21 --> Router Class Initialized
INFO - 2016-06-04 02:54:21 --> Output Class Initialized
INFO - 2016-06-04 02:54:21 --> Security Class Initialized
DEBUG - 2016-06-04 02:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:54:21 --> Input Class Initialized
INFO - 2016-06-04 02:54:21 --> Language Class Initialized
ERROR - 2016-06-04 02:54:21 --> 404 Page Not Found: Flag-engpng/index
INFO - 2016-06-04 02:54:22 --> Config Class Initialized
INFO - 2016-06-04 02:54:22 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:54:22 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:54:22 --> Utf8 Class Initialized
INFO - 2016-06-04 02:54:22 --> URI Class Initialized
DEBUG - 2016-06-04 02:54:22 --> No URI present. Default controller set.
INFO - 2016-06-04 02:54:22 --> Router Class Initialized
INFO - 2016-06-04 02:54:22 --> Output Class Initialized
INFO - 2016-06-04 02:54:22 --> Security Class Initialized
DEBUG - 2016-06-04 02:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:54:22 --> Input Class Initialized
INFO - 2016-06-04 02:54:22 --> Language Class Initialized
INFO - 2016-06-04 02:54:22 --> Loader Class Initialized
INFO - 2016-06-04 02:54:22 --> Helper loaded: url_helper
INFO - 2016-06-04 02:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:54:22 --> Controller Class Initialized
INFO - 2016-06-04 02:54:23 --> Helper loaded: language_helper
INFO - 2016-06-04 02:54:23 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:54:23 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:54:23 --> Final output sent to browser
DEBUG - 2016-06-04 02:54:23 --> Total execution time: 0.2140
INFO - 2016-06-04 02:54:23 --> Config Class Initialized
INFO - 2016-06-04 02:54:23 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:54:23 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:54:23 --> Utf8 Class Initialized
INFO - 2016-06-04 02:54:23 --> URI Class Initialized
INFO - 2016-06-04 02:54:23 --> Router Class Initialized
INFO - 2016-06-04 02:54:23 --> Output Class Initialized
INFO - 2016-06-04 02:54:23 --> Security Class Initialized
DEBUG - 2016-06-04 02:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:54:23 --> Input Class Initialized
INFO - 2016-06-04 02:54:23 --> Language Class Initialized
ERROR - 2016-06-04 02:54:23 --> 404 Page Not Found: Flag-engpng/index
INFO - 2016-06-04 02:54:23 --> Config Class Initialized
INFO - 2016-06-04 02:54:23 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:54:23 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:54:23 --> Utf8 Class Initialized
INFO - 2016-06-04 02:54:23 --> Config Class Initialized
INFO - 2016-06-04 02:54:23 --> Hooks Class Initialized
INFO - 2016-06-04 02:54:23 --> URI Class Initialized
DEBUG - 2016-06-04 02:54:23 --> No URI present. Default controller set.
DEBUG - 2016-06-04 02:54:23 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:54:23 --> Config Class Initialized
INFO - 2016-06-04 02:54:23 --> Router Class Initialized
INFO - 2016-06-04 02:54:23 --> Hooks Class Initialized
INFO - 2016-06-04 02:54:23 --> Utf8 Class Initialized
INFO - 2016-06-04 02:54:23 --> URI Class Initialized
INFO - 2016-06-04 02:54:23 --> Output Class Initialized
DEBUG - 2016-06-04 02:54:23 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:54:23 --> Utf8 Class Initialized
DEBUG - 2016-06-04 02:54:23 --> No URI present. Default controller set.
INFO - 2016-06-04 02:54:23 --> Security Class Initialized
INFO - 2016-06-04 02:54:23 --> Config Class Initialized
INFO - 2016-06-04 02:54:23 --> Router Class Initialized
INFO - 2016-06-04 02:54:23 --> Hooks Class Initialized
INFO - 2016-06-04 02:54:23 --> URI Class Initialized
DEBUG - 2016-06-04 02:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:54:23 --> Input Class Initialized
DEBUG - 2016-06-04 02:54:23 --> No URI present. Default controller set.
INFO - 2016-06-04 02:54:23 --> Output Class Initialized
DEBUG - 2016-06-04 02:54:23 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:54:23 --> Utf8 Class Initialized
INFO - 2016-06-04 02:54:23 --> Router Class Initialized
INFO - 2016-06-04 02:54:23 --> Language Class Initialized
INFO - 2016-06-04 02:54:23 --> Security Class Initialized
INFO - 2016-06-04 02:54:23 --> Config Class Initialized
INFO - 2016-06-04 02:54:23 --> Hooks Class Initialized
INFO - 2016-06-04 02:54:23 --> URI Class Initialized
DEBUG - 2016-06-04 02:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:54:23 --> Output Class Initialized
INFO - 2016-06-04 02:54:23 --> Loader Class Initialized
INFO - 2016-06-04 02:54:23 --> Input Class Initialized
INFO - 2016-06-04 02:54:23 --> Security Class Initialized
DEBUG - 2016-06-04 02:54:23 --> No URI present. Default controller set.
INFO - 2016-06-04 02:54:23 --> Helper loaded: url_helper
DEBUG - 2016-06-04 02:54:23 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:54:23 --> Language Class Initialized
INFO - 2016-06-04 02:54:23 --> Utf8 Class Initialized
INFO - 2016-06-04 02:54:23 --> Router Class Initialized
DEBUG - 2016-06-04 02:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:54:23 --> Config Class Initialized
INFO - 2016-06-04 02:54:23 --> Hooks Class Initialized
INFO - 2016-06-04 02:54:23 --> Input Class Initialized
INFO - 2016-06-04 02:54:23 --> URI Class Initialized
INFO - 2016-06-04 02:54:23 --> Loader Class Initialized
INFO - 2016-06-04 02:54:23 --> Output Class Initialized
INFO - 2016-06-04 02:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:54:23 --> Controller Class Initialized
INFO - 2016-06-04 02:54:23 --> Language Class Initialized
INFO - 2016-06-04 02:54:23 --> Helper loaded: url_helper
DEBUG - 2016-06-04 02:54:23 --> No URI present. Default controller set.
INFO - 2016-06-04 02:54:23 --> Security Class Initialized
DEBUG - 2016-06-04 02:54:23 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:54:23 --> Router Class Initialized
INFO - 2016-06-04 02:54:23 --> Helper loaded: language_helper
DEBUG - 2016-06-04 02:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:54:23 --> Utf8 Class Initialized
INFO - 2016-06-04 02:54:23 --> Loader Class Initialized
INFO - 2016-06-04 02:54:23 --> Config Class Initialized
INFO - 2016-06-04 02:54:23 --> Hooks Class Initialized
INFO - 2016-06-04 02:54:23 --> Input Class Initialized
INFO - 2016-06-04 02:54:23 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:54:23 --> URI Class Initialized
INFO - 2016-06-04 02:54:23 --> Helper loaded: url_helper
INFO - 2016-06-04 02:54:23 --> Output Class Initialized
DEBUG - 2016-06-04 02:54:23 --> UTF-8 Support Enabled
DEBUG - 2016-06-04 02:54:23 --> No URI present. Default controller set.
INFO - 2016-06-04 02:54:23 --> Language Class Initialized
INFO - 2016-06-04 02:54:23 --> Security Class Initialized
INFO - 2016-06-04 02:54:23 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:54:23 --> Router Class Initialized
INFO - 2016-06-04 02:54:23 --> Utf8 Class Initialized
INFO - 2016-06-04 02:54:23 --> Config Class Initialized
DEBUG - 2016-06-04 02:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:54:23 --> Loader Class Initialized
INFO - 2016-06-04 02:54:23 --> Final output sent to browser
DEBUG - 2016-06-04 02:54:23 --> Total execution time: 0.2490
INFO - 2016-06-04 02:54:23 --> Input Class Initialized
INFO - 2016-06-04 02:54:23 --> Hooks Class Initialized
INFO - 2016-06-04 02:54:23 --> URI Class Initialized
INFO - 2016-06-04 02:54:23 --> Output Class Initialized
INFO - 2016-06-04 02:54:23 --> Helper loaded: url_helper
INFO - 2016-06-04 02:54:23 --> Security Class Initialized
INFO - 2016-06-04 02:54:23 --> Config Class Initialized
DEBUG - 2016-06-04 02:54:23 --> No URI present. Default controller set.
INFO - 2016-06-04 02:54:23 --> Language Class Initialized
INFO - 2016-06-04 02:54:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2016-06-04 02:54:23 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:54:23 --> Router Class Initialized
INFO - 2016-06-04 02:54:23 --> Utf8 Class Initialized
INFO - 2016-06-04 02:54:23 --> Controller Class Initialized
INFO - 2016-06-04 02:54:23 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:54:23 --> Loader Class Initialized
INFO - 2016-06-04 02:54:23 --> Input Class Initialized
INFO - 2016-06-04 02:54:23 --> Output Class Initialized
INFO - 2016-06-04 02:54:23 --> URI Class Initialized
INFO - 2016-06-04 02:54:23 --> Helper loaded: language_helper
INFO - 2016-06-04 02:54:23 --> Helper loaded: url_helper
INFO - 2016-06-04 02:54:23 --> Language Class Initialized
DEBUG - 2016-06-04 02:54:23 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:54:23 --> Security Class Initialized
INFO - 2016-06-04 02:54:23 --> Config Class Initialized
INFO - 2016-06-04 02:54:23 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:54:23 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:54:23 --> No URI present. Default controller set.
INFO - 2016-06-04 02:54:23 --> Utf8 Class Initialized
INFO - 2016-06-04 02:54:23 --> Loader Class Initialized
DEBUG - 2016-06-04 02:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:54:23 --> Router Class Initialized
INFO - 2016-06-04 02:54:23 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:54:23 --> Input Class Initialized
INFO - 2016-06-04 02:54:23 --> URI Class Initialized
DEBUG - 2016-06-04 02:54:23 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:54:23 --> Helper loaded: url_helper
INFO - 2016-06-04 02:54:23 --> Final output sent to browser
INFO - 2016-06-04 02:54:23 --> Language Class Initialized
DEBUG - 2016-06-04 02:54:23 --> No URI present. Default controller set.
INFO - 2016-06-04 02:54:23 --> Utf8 Class Initialized
INFO - 2016-06-04 02:54:23 --> Output Class Initialized
INFO - 2016-06-04 02:54:23 --> Config Class Initialized
INFO - 2016-06-04 02:54:23 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:54:23 --> Total execution time: 0.3000
INFO - 2016-06-04 02:54:23 --> Router Class Initialized
INFO - 2016-06-04 02:54:23 --> Loader Class Initialized
INFO - 2016-06-04 02:54:23 --> Security Class Initialized
INFO - 2016-06-04 02:54:23 --> URI Class Initialized
INFO - 2016-06-04 02:54:23 --> Config Class Initialized
INFO - 2016-06-04 02:54:23 --> Hooks Class Initialized
INFO - 2016-06-04 02:54:23 --> Helper loaded: url_helper
INFO - 2016-06-04 02:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:54:23 --> Output Class Initialized
DEBUG - 2016-06-04 02:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-04 02:54:23 --> No URI present. Default controller set.
DEBUG - 2016-06-04 02:54:23 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:54:23 --> Utf8 Class Initialized
INFO - 2016-06-04 02:54:23 --> Controller Class Initialized
INFO - 2016-06-04 02:54:23 --> Security Class Initialized
DEBUG - 2016-06-04 02:54:23 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:54:23 --> Config Class Initialized
INFO - 2016-06-04 02:54:23 --> Input Class Initialized
INFO - 2016-06-04 02:54:23 --> Router Class Initialized
INFO - 2016-06-04 02:54:23 --> Utf8 Class Initialized
INFO - 2016-06-04 02:54:23 --> Helper loaded: language_helper
INFO - 2016-06-04 02:54:23 --> URI Class Initialized
DEBUG - 2016-06-04 02:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:54:23 --> URI Class Initialized
INFO - 2016-06-04 02:54:23 --> Language Class Initialized
INFO - 2016-06-04 02:54:23 --> Input Class Initialized
INFO - 2016-06-04 02:54:23 --> Hooks Class Initialized
INFO - 2016-06-04 02:54:23 --> Output Class Initialized
INFO - 2016-06-04 02:54:23 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:54:23 --> Language Class Initialized
DEBUG - 2016-06-04 02:54:23 --> No URI present. Default controller set.
INFO - 2016-06-04 02:54:23 --> Loader Class Initialized
DEBUG - 2016-06-04 02:54:23 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:54:23 --> Config Class Initialized
INFO - 2016-06-04 02:54:23 --> Security Class Initialized
DEBUG - 2016-06-04 02:54:23 --> No URI present. Default controller set.
INFO - 2016-06-04 02:54:23 --> Hooks Class Initialized
INFO - 2016-06-04 02:54:23 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:54:23 --> Router Class Initialized
INFO - 2016-06-04 02:54:23 --> Helper loaded: url_helper
INFO - 2016-06-04 02:54:23 --> Utf8 Class Initialized
INFO - 2016-06-04 02:54:23 --> Router Class Initialized
DEBUG - 2016-06-04 02:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:54:23 --> Loader Class Initialized
INFO - 2016-06-04 02:54:23 --> URI Class Initialized
INFO - 2016-06-04 02:54:23 --> Final output sent to browser
INFO - 2016-06-04 02:54:23 --> Helper loaded: url_helper
INFO - 2016-06-04 02:54:23 --> Output Class Initialized
INFO - 2016-06-04 02:54:23 --> Input Class Initialized
INFO - 2016-06-04 02:54:23 --> Output Class Initialized
DEBUG - 2016-06-04 02:54:23 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:54:23 --> Utf8 Class Initialized
DEBUG - 2016-06-04 02:54:23 --> No URI present. Default controller set.
DEBUG - 2016-06-04 02:54:23 --> Total execution time: 0.3880
INFO - 2016-06-04 02:54:23 --> Language Class Initialized
INFO - 2016-06-04 02:54:23 --> Security Class Initialized
INFO - 2016-06-04 02:54:23 --> Security Class Initialized
INFO - 2016-06-04 02:54:23 --> Router Class Initialized
INFO - 2016-06-04 02:54:23 --> URI Class Initialized
DEBUG - 2016-06-04 02:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:54:23 --> Loader Class Initialized
DEBUG - 2016-06-04 02:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:54:23 --> Controller Class Initialized
INFO - 2016-06-04 02:54:23 --> Input Class Initialized
DEBUG - 2016-06-04 02:54:23 --> No URI present. Default controller set.
INFO - 2016-06-04 02:54:23 --> Input Class Initialized
INFO - 2016-06-04 02:54:23 --> Helper loaded: url_helper
INFO - 2016-06-04 02:54:23 --> Output Class Initialized
INFO - 2016-06-04 02:54:23 --> Language Class Initialized
INFO - 2016-06-04 02:54:23 --> Helper loaded: language_helper
INFO - 2016-06-04 02:54:23 --> Router Class Initialized
INFO - 2016-06-04 02:54:23 --> Language Class Initialized
INFO - 2016-06-04 02:54:23 --> Security Class Initialized
INFO - 2016-06-04 02:54:23 --> Language file loaded: language/hindi/message_lang.php
DEBUG - 2016-06-04 02:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:54:23 --> Output Class Initialized
INFO - 2016-06-04 02:54:23 --> Loader Class Initialized
INFO - 2016-06-04 02:54:23 --> Loader Class Initialized
INFO - 2016-06-04 02:54:23 --> Input Class Initialized
INFO - 2016-06-04 02:54:23 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:54:23 --> Security Class Initialized
INFO - 2016-06-04 02:54:23 --> Helper loaded: url_helper
INFO - 2016-06-04 02:54:23 --> Helper loaded: url_helper
INFO - 2016-06-04 02:54:23 --> Final output sent to browser
INFO - 2016-06-04 02:54:23 --> Language Class Initialized
DEBUG - 2016-06-04 02:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-06-04 02:54:23 --> Total execution time: 0.4180
INFO - 2016-06-04 02:54:23 --> Input Class Initialized
INFO - 2016-06-04 02:54:23 --> Loader Class Initialized
INFO - 2016-06-04 02:54:23 --> Language Class Initialized
INFO - 2016-06-04 02:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:54:23 --> Helper loaded: url_helper
INFO - 2016-06-04 02:54:23 --> Controller Class Initialized
INFO - 2016-06-04 02:54:23 --> Loader Class Initialized
INFO - 2016-06-04 02:54:23 --> Helper loaded: language_helper
INFO - 2016-06-04 02:54:23 --> Helper loaded: url_helper
INFO - 2016-06-04 02:54:23 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:54:23 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:54:23 --> Final output sent to browser
DEBUG - 2016-06-04 02:54:23 --> Total execution time: 0.4440
INFO - 2016-06-04 02:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:54:23 --> Controller Class Initialized
INFO - 2016-06-04 02:54:23 --> Helper loaded: language_helper
INFO - 2016-06-04 02:54:23 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:54:23 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:54:23 --> Final output sent to browser
DEBUG - 2016-06-04 02:54:23 --> Total execution time: 0.4850
INFO - 2016-06-04 02:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:54:23 --> Controller Class Initialized
INFO - 2016-06-04 02:54:24 --> Helper loaded: language_helper
INFO - 2016-06-04 02:54:24 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:54:24 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:54:24 --> Final output sent to browser
DEBUG - 2016-06-04 02:54:24 --> Total execution time: 0.4980
INFO - 2016-06-04 02:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:54:24 --> Controller Class Initialized
INFO - 2016-06-04 02:54:24 --> Helper loaded: language_helper
INFO - 2016-06-04 02:54:24 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:54:24 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:54:24 --> Final output sent to browser
DEBUG - 2016-06-04 02:54:24 --> Total execution time: 0.5230
INFO - 2016-06-04 02:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:54:24 --> Controller Class Initialized
INFO - 2016-06-04 02:54:24 --> Helper loaded: language_helper
INFO - 2016-06-04 02:54:24 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:54:24 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:54:24 --> Final output sent to browser
DEBUG - 2016-06-04 02:54:24 --> Total execution time: 0.5650
INFO - 2016-06-04 02:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:54:24 --> Controller Class Initialized
INFO - 2016-06-04 02:54:24 --> Helper loaded: language_helper
INFO - 2016-06-04 02:54:24 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:54:24 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:54:24 --> Final output sent to browser
DEBUG - 2016-06-04 02:54:24 --> Total execution time: 0.5890
INFO - 2016-06-04 02:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:54:24 --> Controller Class Initialized
INFO - 2016-06-04 02:54:24 --> Helper loaded: language_helper
INFO - 2016-06-04 02:54:24 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:54:24 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:54:24 --> Final output sent to browser
DEBUG - 2016-06-04 02:54:24 --> Total execution time: 0.5970
INFO - 2016-06-04 02:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:54:24 --> Controller Class Initialized
INFO - 2016-06-04 02:54:24 --> Helper loaded: language_helper
INFO - 2016-06-04 02:54:24 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:54:24 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:54:24 --> Final output sent to browser
DEBUG - 2016-06-04 02:54:24 --> Total execution time: 0.6710
INFO - 2016-06-04 02:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:54:24 --> Controller Class Initialized
INFO - 2016-06-04 02:54:24 --> Helper loaded: language_helper
INFO - 2016-06-04 02:54:24 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:54:24 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:54:24 --> Final output sent to browser
DEBUG - 2016-06-04 02:54:24 --> Total execution time: 0.6610
INFO - 2016-06-04 02:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:54:24 --> Controller Class Initialized
INFO - 2016-06-04 02:54:24 --> Helper loaded: language_helper
INFO - 2016-06-04 02:54:24 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:54:24 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:54:24 --> Final output sent to browser
DEBUG - 2016-06-04 02:54:24 --> Total execution time: 0.6800
INFO - 2016-06-04 02:54:24 --> Config Class Initialized
INFO - 2016-06-04 02:54:24 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:54:24 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:54:24 --> Utf8 Class Initialized
INFO - 2016-06-04 02:54:24 --> URI Class Initialized
INFO - 2016-06-04 02:54:24 --> Router Class Initialized
INFO - 2016-06-04 02:54:24 --> Output Class Initialized
INFO - 2016-06-04 02:54:24 --> Security Class Initialized
DEBUG - 2016-06-04 02:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:54:24 --> Input Class Initialized
INFO - 2016-06-04 02:54:24 --> Language Class Initialized
ERROR - 2016-06-04 02:54:24 --> 404 Page Not Found: Flag-engpng/index
INFO - 2016-06-04 02:54:26 --> Config Class Initialized
INFO - 2016-06-04 02:54:26 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:54:26 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:54:26 --> Utf8 Class Initialized
INFO - 2016-06-04 02:54:26 --> URI Class Initialized
INFO - 2016-06-04 02:54:26 --> Router Class Initialized
INFO - 2016-06-04 02:54:26 --> Output Class Initialized
INFO - 2016-06-04 02:54:26 --> Security Class Initialized
DEBUG - 2016-06-04 02:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:54:26 --> Input Class Initialized
INFO - 2016-06-04 02:54:26 --> Language Class Initialized
INFO - 2016-06-04 02:54:26 --> Loader Class Initialized
INFO - 2016-06-04 02:54:26 --> Helper loaded: url_helper
INFO - 2016-06-04 02:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:54:26 --> Controller Class Initialized
INFO - 2016-06-04 02:54:26 --> Helper loaded: language_helper
INFO - 2016-06-04 02:54:26 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:54:26 --> Config Class Initialized
INFO - 2016-06-04 02:54:26 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:54:26 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:54:26 --> Utf8 Class Initialized
INFO - 2016-06-04 02:54:26 --> URI Class Initialized
DEBUG - 2016-06-04 02:54:26 --> No URI present. Default controller set.
INFO - 2016-06-04 02:54:26 --> Router Class Initialized
INFO - 2016-06-04 02:54:26 --> Output Class Initialized
INFO - 2016-06-04 02:54:26 --> Security Class Initialized
DEBUG - 2016-06-04 02:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:54:26 --> Input Class Initialized
INFO - 2016-06-04 02:54:26 --> Language Class Initialized
INFO - 2016-06-04 02:54:26 --> Loader Class Initialized
INFO - 2016-06-04 02:54:26 --> Helper loaded: url_helper
INFO - 2016-06-04 02:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:54:26 --> Controller Class Initialized
INFO - 2016-06-04 02:54:26 --> Helper loaded: language_helper
INFO - 2016-06-04 02:54:26 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:54:26 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:54:26 --> Final output sent to browser
DEBUG - 2016-06-04 02:54:27 --> Total execution time: 0.1800
INFO - 2016-06-04 02:54:27 --> Config Class Initialized
INFO - 2016-06-04 02:54:27 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:54:27 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:54:27 --> Utf8 Class Initialized
INFO - 2016-06-04 02:54:27 --> URI Class Initialized
INFO - 2016-06-04 02:54:27 --> Router Class Initialized
INFO - 2016-06-04 02:54:27 --> Output Class Initialized
INFO - 2016-06-04 02:54:27 --> Security Class Initialized
DEBUG - 2016-06-04 02:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:54:27 --> Input Class Initialized
INFO - 2016-06-04 02:54:27 --> Language Class Initialized
ERROR - 2016-06-04 02:54:27 --> 404 Page Not Found: Flag-engpng/index
INFO - 2016-06-04 02:55:11 --> Config Class Initialized
INFO - 2016-06-04 02:55:11 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:55:11 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:55:11 --> Utf8 Class Initialized
INFO - 2016-06-04 02:55:11 --> URI Class Initialized
DEBUG - 2016-06-04 02:55:11 --> No URI present. Default controller set.
INFO - 2016-06-04 02:55:11 --> Router Class Initialized
INFO - 2016-06-04 02:55:11 --> Output Class Initialized
INFO - 2016-06-04 02:55:11 --> Security Class Initialized
DEBUG - 2016-06-04 02:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:55:11 --> Input Class Initialized
INFO - 2016-06-04 02:55:11 --> Language Class Initialized
INFO - 2016-06-04 02:55:11 --> Loader Class Initialized
INFO - 2016-06-04 02:55:11 --> Helper loaded: url_helper
INFO - 2016-06-04 02:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:55:11 --> Controller Class Initialized
INFO - 2016-06-04 02:55:11 --> Helper loaded: language_helper
INFO - 2016-06-04 02:55:11 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:55:11 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:55:11 --> Final output sent to browser
DEBUG - 2016-06-04 02:55:11 --> Total execution time: 0.1850
INFO - 2016-06-04 02:56:16 --> Config Class Initialized
INFO - 2016-06-04 02:56:16 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:56:16 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:56:16 --> Utf8 Class Initialized
INFO - 2016-06-04 02:56:16 --> URI Class Initialized
DEBUG - 2016-06-04 02:56:16 --> No URI present. Default controller set.
INFO - 2016-06-04 02:56:16 --> Router Class Initialized
INFO - 2016-06-04 02:56:16 --> Output Class Initialized
INFO - 2016-06-04 02:56:16 --> Security Class Initialized
DEBUG - 2016-06-04 02:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:56:16 --> Input Class Initialized
INFO - 2016-06-04 02:56:16 --> Language Class Initialized
INFO - 2016-06-04 02:56:16 --> Loader Class Initialized
INFO - 2016-06-04 02:56:16 --> Helper loaded: url_helper
INFO - 2016-06-04 02:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:56:16 --> Controller Class Initialized
INFO - 2016-06-04 02:56:16 --> Helper loaded: language_helper
INFO - 2016-06-04 02:56:16 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:56:16 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:56:16 --> Final output sent to browser
DEBUG - 2016-06-04 02:56:16 --> Total execution time: 0.1730
INFO - 2016-06-04 02:56:32 --> Config Class Initialized
INFO - 2016-06-04 02:56:32 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:56:32 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:56:32 --> Utf8 Class Initialized
INFO - 2016-06-04 02:56:32 --> URI Class Initialized
DEBUG - 2016-06-04 02:56:32 --> No URI present. Default controller set.
INFO - 2016-06-04 02:56:32 --> Router Class Initialized
INFO - 2016-06-04 02:56:32 --> Output Class Initialized
INFO - 2016-06-04 02:56:33 --> Security Class Initialized
DEBUG - 2016-06-04 02:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:56:33 --> Input Class Initialized
INFO - 2016-06-04 02:56:33 --> Language Class Initialized
INFO - 2016-06-04 02:56:33 --> Loader Class Initialized
INFO - 2016-06-04 02:56:33 --> Helper loaded: url_helper
INFO - 2016-06-04 02:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:56:33 --> Controller Class Initialized
INFO - 2016-06-04 02:56:33 --> Helper loaded: language_helper
INFO - 2016-06-04 02:56:33 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:56:33 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:56:33 --> Final output sent to browser
DEBUG - 2016-06-04 02:56:33 --> Total execution time: 0.2010
INFO - 2016-06-04 02:56:49 --> Config Class Initialized
INFO - 2016-06-04 02:56:49 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:56:49 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:56:49 --> Utf8 Class Initialized
INFO - 2016-06-04 02:56:49 --> URI Class Initialized
DEBUG - 2016-06-04 02:56:49 --> No URI present. Default controller set.
INFO - 2016-06-04 02:56:49 --> Router Class Initialized
INFO - 2016-06-04 02:56:49 --> Output Class Initialized
INFO - 2016-06-04 02:56:49 --> Security Class Initialized
DEBUG - 2016-06-04 02:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:56:49 --> Input Class Initialized
INFO - 2016-06-04 02:56:49 --> Language Class Initialized
INFO - 2016-06-04 02:56:49 --> Loader Class Initialized
INFO - 2016-06-04 02:56:49 --> Helper loaded: url_helper
INFO - 2016-06-04 02:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:56:49 --> Controller Class Initialized
INFO - 2016-06-04 02:56:49 --> Helper loaded: language_helper
INFO - 2016-06-04 02:56:49 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:56:49 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:56:49 --> Final output sent to browser
DEBUG - 2016-06-04 02:56:49 --> Total execution time: 0.1970
INFO - 2016-06-04 02:56:51 --> Config Class Initialized
INFO - 2016-06-04 02:56:51 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:56:51 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:56:51 --> Utf8 Class Initialized
INFO - 2016-06-04 02:56:51 --> URI Class Initialized
INFO - 2016-06-04 02:56:51 --> Router Class Initialized
INFO - 2016-06-04 02:56:51 --> Output Class Initialized
INFO - 2016-06-04 02:56:51 --> Security Class Initialized
DEBUG - 2016-06-04 02:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:56:51 --> Input Class Initialized
INFO - 2016-06-04 02:56:51 --> Language Class Initialized
INFO - 2016-06-04 02:56:51 --> Loader Class Initialized
INFO - 2016-06-04 02:56:51 --> Helper loaded: url_helper
INFO - 2016-06-04 02:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:56:51 --> Controller Class Initialized
INFO - 2016-06-04 02:56:52 --> Helper loaded: language_helper
INFO - 2016-06-04 02:56:52 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:56:52 --> Config Class Initialized
INFO - 2016-06-04 02:56:52 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:56:52 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:56:52 --> Utf8 Class Initialized
INFO - 2016-06-04 02:56:52 --> URI Class Initialized
DEBUG - 2016-06-04 02:56:52 --> No URI present. Default controller set.
INFO - 2016-06-04 02:56:52 --> Router Class Initialized
INFO - 2016-06-04 02:56:52 --> Output Class Initialized
INFO - 2016-06-04 02:56:52 --> Security Class Initialized
DEBUG - 2016-06-04 02:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:56:52 --> Input Class Initialized
INFO - 2016-06-04 02:56:52 --> Language Class Initialized
INFO - 2016-06-04 02:56:52 --> Loader Class Initialized
INFO - 2016-06-04 02:56:52 --> Helper loaded: url_helper
INFO - 2016-06-04 02:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:56:52 --> Controller Class Initialized
INFO - 2016-06-04 02:56:52 --> Helper loaded: language_helper
INFO - 2016-06-04 02:56:52 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:56:52 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:56:52 --> Final output sent to browser
DEBUG - 2016-06-04 02:56:52 --> Total execution time: 0.1590
INFO - 2016-06-04 02:56:53 --> Config Class Initialized
INFO - 2016-06-04 02:56:53 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:56:53 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:56:53 --> Utf8 Class Initialized
INFO - 2016-06-04 02:56:53 --> URI Class Initialized
INFO - 2016-06-04 02:56:53 --> Router Class Initialized
INFO - 2016-06-04 02:56:53 --> Output Class Initialized
INFO - 2016-06-04 02:56:53 --> Security Class Initialized
DEBUG - 2016-06-04 02:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:56:53 --> Input Class Initialized
INFO - 2016-06-04 02:56:53 --> Language Class Initialized
INFO - 2016-06-04 02:56:53 --> Loader Class Initialized
INFO - 2016-06-04 02:56:53 --> Helper loaded: url_helper
INFO - 2016-06-04 02:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:56:53 --> Controller Class Initialized
INFO - 2016-06-04 02:56:53 --> Helper loaded: language_helper
INFO - 2016-06-04 02:56:53 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:56:53 --> Config Class Initialized
INFO - 2016-06-04 02:56:53 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:56:53 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:56:53 --> Utf8 Class Initialized
INFO - 2016-06-04 02:56:53 --> URI Class Initialized
DEBUG - 2016-06-04 02:56:53 --> No URI present. Default controller set.
INFO - 2016-06-04 02:56:53 --> Router Class Initialized
INFO - 2016-06-04 02:56:53 --> Output Class Initialized
INFO - 2016-06-04 02:56:53 --> Security Class Initialized
DEBUG - 2016-06-04 02:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:56:53 --> Input Class Initialized
INFO - 2016-06-04 02:56:53 --> Language Class Initialized
INFO - 2016-06-04 02:56:53 --> Loader Class Initialized
INFO - 2016-06-04 02:56:53 --> Helper loaded: url_helper
INFO - 2016-06-04 02:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:56:53 --> Controller Class Initialized
INFO - 2016-06-04 02:56:53 --> Helper loaded: language_helper
INFO - 2016-06-04 02:56:53 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:56:54 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:56:54 --> Final output sent to browser
DEBUG - 2016-06-04 02:56:54 --> Total execution time: 0.1520
INFO - 2016-06-04 02:57:02 --> Config Class Initialized
INFO - 2016-06-04 02:57:02 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:57:02 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:57:02 --> Utf8 Class Initialized
INFO - 2016-06-04 02:57:02 --> URI Class Initialized
DEBUG - 2016-06-04 02:57:02 --> No URI present. Default controller set.
INFO - 2016-06-04 02:57:02 --> Router Class Initialized
INFO - 2016-06-04 02:57:02 --> Output Class Initialized
INFO - 2016-06-04 02:57:02 --> Security Class Initialized
DEBUG - 2016-06-04 02:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:57:02 --> Input Class Initialized
INFO - 2016-06-04 02:57:02 --> Language Class Initialized
INFO - 2016-06-04 02:57:02 --> Loader Class Initialized
INFO - 2016-06-04 02:57:02 --> Helper loaded: url_helper
INFO - 2016-06-04 02:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:57:02 --> Controller Class Initialized
INFO - 2016-06-04 02:57:02 --> Helper loaded: language_helper
INFO - 2016-06-04 02:57:02 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:57:02 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:57:02 --> Final output sent to browser
DEBUG - 2016-06-04 02:57:02 --> Total execution time: 0.1640
INFO - 2016-06-04 02:57:47 --> Config Class Initialized
INFO - 2016-06-04 02:57:47 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:57:47 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:57:47 --> Utf8 Class Initialized
INFO - 2016-06-04 02:57:47 --> URI Class Initialized
INFO - 2016-06-04 02:57:47 --> Router Class Initialized
INFO - 2016-06-04 02:57:47 --> Output Class Initialized
INFO - 2016-06-04 02:57:47 --> Security Class Initialized
DEBUG - 2016-06-04 02:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:57:47 --> Input Class Initialized
INFO - 2016-06-04 02:57:47 --> Language Class Initialized
INFO - 2016-06-04 02:57:47 --> Loader Class Initialized
INFO - 2016-06-04 02:57:47 --> Helper loaded: url_helper
INFO - 2016-06-04 02:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:57:48 --> Controller Class Initialized
INFO - 2016-06-04 02:57:48 --> Helper loaded: language_helper
INFO - 2016-06-04 02:57:48 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:57:48 --> Config Class Initialized
INFO - 2016-06-04 02:57:48 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:57:48 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:57:48 --> Utf8 Class Initialized
INFO - 2016-06-04 02:57:48 --> URI Class Initialized
DEBUG - 2016-06-04 02:57:48 --> No URI present. Default controller set.
INFO - 2016-06-04 02:57:48 --> Router Class Initialized
INFO - 2016-06-04 02:57:48 --> Output Class Initialized
INFO - 2016-06-04 02:57:48 --> Security Class Initialized
DEBUG - 2016-06-04 02:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:57:48 --> Input Class Initialized
INFO - 2016-06-04 02:57:48 --> Language Class Initialized
INFO - 2016-06-04 02:57:48 --> Loader Class Initialized
INFO - 2016-06-04 02:57:48 --> Helper loaded: url_helper
INFO - 2016-06-04 02:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:57:48 --> Controller Class Initialized
INFO - 2016-06-04 02:57:48 --> Helper loaded: language_helper
INFO - 2016-06-04 02:57:48 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:57:48 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:57:48 --> Final output sent to browser
DEBUG - 2016-06-04 02:57:48 --> Total execution time: 0.1580
INFO - 2016-06-04 02:57:50 --> Config Class Initialized
INFO - 2016-06-04 02:57:50 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:57:50 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:57:50 --> Utf8 Class Initialized
INFO - 2016-06-04 02:57:50 --> URI Class Initialized
INFO - 2016-06-04 02:57:50 --> Router Class Initialized
INFO - 2016-06-04 02:57:50 --> Output Class Initialized
INFO - 2016-06-04 02:57:50 --> Security Class Initialized
DEBUG - 2016-06-04 02:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:57:50 --> Input Class Initialized
INFO - 2016-06-04 02:57:50 --> Language Class Initialized
INFO - 2016-06-04 02:57:50 --> Loader Class Initialized
INFO - 2016-06-04 02:57:50 --> Helper loaded: url_helper
INFO - 2016-06-04 02:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:57:50 --> Controller Class Initialized
INFO - 2016-06-04 02:57:50 --> Helper loaded: language_helper
INFO - 2016-06-04 02:57:50 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:57:50 --> Config Class Initialized
INFO - 2016-06-04 02:57:50 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:57:50 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:57:50 --> Utf8 Class Initialized
INFO - 2016-06-04 02:57:50 --> URI Class Initialized
DEBUG - 2016-06-04 02:57:50 --> No URI present. Default controller set.
INFO - 2016-06-04 02:57:50 --> Router Class Initialized
INFO - 2016-06-04 02:57:50 --> Output Class Initialized
INFO - 2016-06-04 02:57:50 --> Security Class Initialized
DEBUG - 2016-06-04 02:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:57:50 --> Input Class Initialized
INFO - 2016-06-04 02:57:50 --> Language Class Initialized
INFO - 2016-06-04 02:57:50 --> Loader Class Initialized
INFO - 2016-06-04 02:57:50 --> Helper loaded: url_helper
INFO - 2016-06-04 02:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:57:50 --> Controller Class Initialized
INFO - 2016-06-04 02:57:50 --> Helper loaded: language_helper
INFO - 2016-06-04 02:57:50 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:57:50 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:57:50 --> Final output sent to browser
DEBUG - 2016-06-04 02:57:50 --> Total execution time: 0.1600
INFO - 2016-06-04 02:58:55 --> Config Class Initialized
INFO - 2016-06-04 02:58:55 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:58:55 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:58:55 --> Utf8 Class Initialized
INFO - 2016-06-04 02:58:55 --> URI Class Initialized
DEBUG - 2016-06-04 02:58:55 --> No URI present. Default controller set.
INFO - 2016-06-04 02:58:55 --> Router Class Initialized
INFO - 2016-06-04 02:58:55 --> Output Class Initialized
INFO - 2016-06-04 02:58:55 --> Security Class Initialized
DEBUG - 2016-06-04 02:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:58:55 --> Input Class Initialized
INFO - 2016-06-04 02:58:55 --> Language Class Initialized
INFO - 2016-06-04 02:58:55 --> Loader Class Initialized
INFO - 2016-06-04 02:58:55 --> Helper loaded: url_helper
INFO - 2016-06-04 02:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:58:55 --> Controller Class Initialized
INFO - 2016-06-04 02:58:55 --> Helper loaded: language_helper
INFO - 2016-06-04 02:58:55 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:58:55 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:58:55 --> Final output sent to browser
DEBUG - 2016-06-04 02:58:55 --> Total execution time: 0.1670
INFO - 2016-06-04 02:58:57 --> Config Class Initialized
INFO - 2016-06-04 02:58:57 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:58:57 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:58:57 --> Utf8 Class Initialized
INFO - 2016-06-04 02:58:57 --> URI Class Initialized
INFO - 2016-06-04 02:58:57 --> Router Class Initialized
INFO - 2016-06-04 02:58:57 --> Output Class Initialized
INFO - 2016-06-04 02:58:57 --> Security Class Initialized
DEBUG - 2016-06-04 02:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:58:57 --> Input Class Initialized
INFO - 2016-06-04 02:58:57 --> Language Class Initialized
INFO - 2016-06-04 02:58:57 --> Loader Class Initialized
INFO - 2016-06-04 02:58:57 --> Helper loaded: url_helper
INFO - 2016-06-04 02:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:58:57 --> Controller Class Initialized
INFO - 2016-06-04 02:58:57 --> Helper loaded: language_helper
INFO - 2016-06-04 02:58:57 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:58:57 --> Config Class Initialized
INFO - 2016-06-04 02:58:57 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:58:57 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:58:57 --> Utf8 Class Initialized
INFO - 2016-06-04 02:58:57 --> URI Class Initialized
DEBUG - 2016-06-04 02:58:57 --> No URI present. Default controller set.
INFO - 2016-06-04 02:58:57 --> Router Class Initialized
INFO - 2016-06-04 02:58:57 --> Output Class Initialized
INFO - 2016-06-04 02:58:57 --> Security Class Initialized
DEBUG - 2016-06-04 02:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:58:57 --> Input Class Initialized
INFO - 2016-06-04 02:58:57 --> Language Class Initialized
INFO - 2016-06-04 02:58:57 --> Loader Class Initialized
INFO - 2016-06-04 02:58:57 --> Helper loaded: url_helper
INFO - 2016-06-04 02:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:58:57 --> Controller Class Initialized
INFO - 2016-06-04 02:58:57 --> Helper loaded: language_helper
INFO - 2016-06-04 02:58:57 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:58:57 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:58:57 --> Final output sent to browser
DEBUG - 2016-06-04 02:58:57 --> Total execution time: 0.1810
INFO - 2016-06-04 02:58:59 --> Config Class Initialized
INFO - 2016-06-04 02:58:59 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:58:59 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:58:59 --> Utf8 Class Initialized
INFO - 2016-06-04 02:58:59 --> URI Class Initialized
INFO - 2016-06-04 02:58:59 --> Router Class Initialized
INFO - 2016-06-04 02:58:59 --> Output Class Initialized
INFO - 2016-06-04 02:58:59 --> Security Class Initialized
DEBUG - 2016-06-04 02:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:58:59 --> Input Class Initialized
INFO - 2016-06-04 02:58:59 --> Language Class Initialized
INFO - 2016-06-04 02:58:59 --> Loader Class Initialized
INFO - 2016-06-04 02:58:59 --> Helper loaded: url_helper
INFO - 2016-06-04 02:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:58:59 --> Controller Class Initialized
INFO - 2016-06-04 02:58:59 --> Helper loaded: language_helper
INFO - 2016-06-04 02:58:59 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:58:59 --> Config Class Initialized
INFO - 2016-06-04 02:58:59 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:58:59 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:58:59 --> Utf8 Class Initialized
INFO - 2016-06-04 02:58:59 --> URI Class Initialized
DEBUG - 2016-06-04 02:58:59 --> No URI present. Default controller set.
INFO - 2016-06-04 02:58:59 --> Router Class Initialized
INFO - 2016-06-04 02:58:59 --> Output Class Initialized
INFO - 2016-06-04 02:58:59 --> Security Class Initialized
DEBUG - 2016-06-04 02:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:58:59 --> Input Class Initialized
INFO - 2016-06-04 02:58:59 --> Language Class Initialized
INFO - 2016-06-04 02:58:59 --> Loader Class Initialized
INFO - 2016-06-04 02:58:59 --> Helper loaded: url_helper
INFO - 2016-06-04 02:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:58:59 --> Controller Class Initialized
INFO - 2016-06-04 02:58:59 --> Helper loaded: language_helper
INFO - 2016-06-04 02:58:59 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:58:59 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:58:59 --> Final output sent to browser
DEBUG - 2016-06-04 02:58:59 --> Total execution time: 0.1620
INFO - 2016-06-04 02:59:31 --> Config Class Initialized
INFO - 2016-06-04 02:59:31 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:59:31 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:59:31 --> Utf8 Class Initialized
INFO - 2016-06-04 02:59:31 --> URI Class Initialized
DEBUG - 2016-06-04 02:59:31 --> No URI present. Default controller set.
INFO - 2016-06-04 02:59:31 --> Router Class Initialized
INFO - 2016-06-04 02:59:31 --> Output Class Initialized
INFO - 2016-06-04 02:59:31 --> Security Class Initialized
DEBUG - 2016-06-04 02:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:59:31 --> Input Class Initialized
INFO - 2016-06-04 02:59:31 --> Language Class Initialized
INFO - 2016-06-04 02:59:31 --> Loader Class Initialized
INFO - 2016-06-04 02:59:31 --> Helper loaded: url_helper
INFO - 2016-06-04 02:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:59:31 --> Controller Class Initialized
INFO - 2016-06-04 02:59:31 --> Helper loaded: language_helper
INFO - 2016-06-04 02:59:31 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:59:31 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:59:31 --> Final output sent to browser
DEBUG - 2016-06-04 02:59:31 --> Total execution time: 0.1910
INFO - 2016-06-04 02:59:33 --> Config Class Initialized
INFO - 2016-06-04 02:59:33 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:59:33 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:59:33 --> Utf8 Class Initialized
INFO - 2016-06-04 02:59:33 --> URI Class Initialized
INFO - 2016-06-04 02:59:33 --> Router Class Initialized
INFO - 2016-06-04 02:59:33 --> Output Class Initialized
INFO - 2016-06-04 02:59:33 --> Security Class Initialized
DEBUG - 2016-06-04 02:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:59:33 --> Input Class Initialized
INFO - 2016-06-04 02:59:33 --> Language Class Initialized
INFO - 2016-06-04 02:59:33 --> Loader Class Initialized
INFO - 2016-06-04 02:59:33 --> Helper loaded: url_helper
INFO - 2016-06-04 02:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:59:33 --> Controller Class Initialized
INFO - 2016-06-04 02:59:33 --> Helper loaded: language_helper
INFO - 2016-06-04 02:59:33 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:59:33 --> Config Class Initialized
INFO - 2016-06-04 02:59:33 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:59:33 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:59:33 --> Utf8 Class Initialized
INFO - 2016-06-04 02:59:33 --> URI Class Initialized
DEBUG - 2016-06-04 02:59:33 --> No URI present. Default controller set.
INFO - 2016-06-04 02:59:33 --> Router Class Initialized
INFO - 2016-06-04 02:59:33 --> Output Class Initialized
INFO - 2016-06-04 02:59:33 --> Security Class Initialized
DEBUG - 2016-06-04 02:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:59:33 --> Input Class Initialized
INFO - 2016-06-04 02:59:33 --> Language Class Initialized
INFO - 2016-06-04 02:59:33 --> Loader Class Initialized
INFO - 2016-06-04 02:59:33 --> Helper loaded: url_helper
INFO - 2016-06-04 02:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:59:33 --> Controller Class Initialized
INFO - 2016-06-04 02:59:33 --> Helper loaded: language_helper
INFO - 2016-06-04 02:59:33 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:59:33 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:59:33 --> Final output sent to browser
DEBUG - 2016-06-04 02:59:33 --> Total execution time: 0.1720
INFO - 2016-06-04 02:59:36 --> Config Class Initialized
INFO - 2016-06-04 02:59:36 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:59:36 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:59:36 --> Utf8 Class Initialized
INFO - 2016-06-04 02:59:36 --> URI Class Initialized
INFO - 2016-06-04 02:59:36 --> Router Class Initialized
INFO - 2016-06-04 02:59:36 --> Output Class Initialized
INFO - 2016-06-04 02:59:36 --> Security Class Initialized
DEBUG - 2016-06-04 02:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:59:36 --> Input Class Initialized
INFO - 2016-06-04 02:59:36 --> Language Class Initialized
INFO - 2016-06-04 02:59:36 --> Loader Class Initialized
INFO - 2016-06-04 02:59:36 --> Helper loaded: url_helper
INFO - 2016-06-04 02:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:59:36 --> Controller Class Initialized
INFO - 2016-06-04 02:59:36 --> Helper loaded: language_helper
INFO - 2016-06-04 02:59:36 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:59:36 --> Config Class Initialized
INFO - 2016-06-04 02:59:36 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:59:36 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:59:36 --> Utf8 Class Initialized
INFO - 2016-06-04 02:59:36 --> URI Class Initialized
DEBUG - 2016-06-04 02:59:36 --> No URI present. Default controller set.
INFO - 2016-06-04 02:59:36 --> Router Class Initialized
INFO - 2016-06-04 02:59:36 --> Output Class Initialized
INFO - 2016-06-04 02:59:36 --> Security Class Initialized
DEBUG - 2016-06-04 02:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:59:36 --> Input Class Initialized
INFO - 2016-06-04 02:59:36 --> Language Class Initialized
INFO - 2016-06-04 02:59:36 --> Loader Class Initialized
INFO - 2016-06-04 02:59:36 --> Helper loaded: url_helper
INFO - 2016-06-04 02:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:59:36 --> Controller Class Initialized
INFO - 2016-06-04 02:59:36 --> Helper loaded: language_helper
INFO - 2016-06-04 02:59:36 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:59:36 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:59:36 --> Final output sent to browser
DEBUG - 2016-06-04 02:59:36 --> Total execution time: 0.1600
INFO - 2016-06-04 02:59:38 --> Config Class Initialized
INFO - 2016-06-04 02:59:38 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:59:38 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:59:38 --> Utf8 Class Initialized
INFO - 2016-06-04 02:59:38 --> URI Class Initialized
INFO - 2016-06-04 02:59:38 --> Router Class Initialized
INFO - 2016-06-04 02:59:38 --> Output Class Initialized
INFO - 2016-06-04 02:59:38 --> Security Class Initialized
DEBUG - 2016-06-04 02:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:59:38 --> Input Class Initialized
INFO - 2016-06-04 02:59:38 --> Language Class Initialized
INFO - 2016-06-04 02:59:38 --> Loader Class Initialized
INFO - 2016-06-04 02:59:38 --> Helper loaded: url_helper
INFO - 2016-06-04 02:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:59:38 --> Controller Class Initialized
INFO - 2016-06-04 02:59:38 --> Helper loaded: language_helper
INFO - 2016-06-04 02:59:38 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:59:38 --> Config Class Initialized
INFO - 2016-06-04 02:59:38 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:59:38 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:59:38 --> Utf8 Class Initialized
INFO - 2016-06-04 02:59:38 --> URI Class Initialized
DEBUG - 2016-06-04 02:59:38 --> No URI present. Default controller set.
INFO - 2016-06-04 02:59:38 --> Router Class Initialized
INFO - 2016-06-04 02:59:38 --> Output Class Initialized
INFO - 2016-06-04 02:59:38 --> Security Class Initialized
DEBUG - 2016-06-04 02:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:59:38 --> Input Class Initialized
INFO - 2016-06-04 02:59:38 --> Language Class Initialized
INFO - 2016-06-04 02:59:38 --> Loader Class Initialized
INFO - 2016-06-04 02:59:38 --> Helper loaded: url_helper
INFO - 2016-06-04 02:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:59:38 --> Controller Class Initialized
INFO - 2016-06-04 02:59:38 --> Helper loaded: language_helper
INFO - 2016-06-04 02:59:38 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:59:38 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:59:38 --> Final output sent to browser
DEBUG - 2016-06-04 02:59:38 --> Total execution time: 0.1620
INFO - 2016-06-04 02:59:40 --> Config Class Initialized
INFO - 2016-06-04 02:59:40 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:59:40 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:59:40 --> Utf8 Class Initialized
INFO - 2016-06-04 02:59:40 --> URI Class Initialized
INFO - 2016-06-04 02:59:40 --> Router Class Initialized
INFO - 2016-06-04 02:59:40 --> Output Class Initialized
INFO - 2016-06-04 02:59:40 --> Security Class Initialized
DEBUG - 2016-06-04 02:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:59:40 --> Input Class Initialized
INFO - 2016-06-04 02:59:40 --> Language Class Initialized
INFO - 2016-06-04 02:59:40 --> Loader Class Initialized
INFO - 2016-06-04 02:59:40 --> Helper loaded: url_helper
INFO - 2016-06-04 02:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:59:40 --> Controller Class Initialized
INFO - 2016-06-04 02:59:40 --> Helper loaded: language_helper
INFO - 2016-06-04 02:59:40 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 02:59:40 --> Config Class Initialized
INFO - 2016-06-04 02:59:40 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:59:40 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:59:40 --> Utf8 Class Initialized
INFO - 2016-06-04 02:59:40 --> URI Class Initialized
DEBUG - 2016-06-04 02:59:40 --> No URI present. Default controller set.
INFO - 2016-06-04 02:59:40 --> Router Class Initialized
INFO - 2016-06-04 02:59:40 --> Output Class Initialized
INFO - 2016-06-04 02:59:40 --> Security Class Initialized
DEBUG - 2016-06-04 02:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:59:40 --> Input Class Initialized
INFO - 2016-06-04 02:59:40 --> Language Class Initialized
INFO - 2016-06-04 02:59:40 --> Loader Class Initialized
INFO - 2016-06-04 02:59:40 --> Helper loaded: url_helper
INFO - 2016-06-04 02:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:59:40 --> Controller Class Initialized
INFO - 2016-06-04 02:59:40 --> Helper loaded: language_helper
INFO - 2016-06-04 02:59:40 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:59:40 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:59:40 --> Final output sent to browser
DEBUG - 2016-06-04 02:59:40 --> Total execution time: 0.1620
INFO - 2016-06-04 02:59:54 --> Config Class Initialized
INFO - 2016-06-04 02:59:54 --> Hooks Class Initialized
DEBUG - 2016-06-04 02:59:54 --> UTF-8 Support Enabled
INFO - 2016-06-04 02:59:54 --> Utf8 Class Initialized
INFO - 2016-06-04 02:59:54 --> URI Class Initialized
DEBUG - 2016-06-04 02:59:54 --> No URI present. Default controller set.
INFO - 2016-06-04 02:59:54 --> Router Class Initialized
INFO - 2016-06-04 02:59:54 --> Output Class Initialized
INFO - 2016-06-04 02:59:54 --> Security Class Initialized
DEBUG - 2016-06-04 02:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 02:59:54 --> Input Class Initialized
INFO - 2016-06-04 02:59:54 --> Language Class Initialized
INFO - 2016-06-04 02:59:54 --> Loader Class Initialized
INFO - 2016-06-04 02:59:54 --> Helper loaded: url_helper
INFO - 2016-06-04 02:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 02:59:54 --> Controller Class Initialized
INFO - 2016-06-04 02:59:54 --> Helper loaded: language_helper
INFO - 2016-06-04 02:59:54 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 02:59:54 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 02:59:54 --> Final output sent to browser
DEBUG - 2016-06-04 02:59:54 --> Total execution time: 0.1730
INFO - 2016-06-04 03:00:02 --> Config Class Initialized
INFO - 2016-06-04 03:00:02 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:00:02 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:00:02 --> Utf8 Class Initialized
INFO - 2016-06-04 03:00:02 --> URI Class Initialized
DEBUG - 2016-06-04 03:00:02 --> No URI present. Default controller set.
INFO - 2016-06-04 03:00:02 --> Router Class Initialized
INFO - 2016-06-04 03:00:02 --> Output Class Initialized
INFO - 2016-06-04 03:00:02 --> Security Class Initialized
DEBUG - 2016-06-04 03:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:00:02 --> Input Class Initialized
INFO - 2016-06-04 03:00:02 --> Language Class Initialized
INFO - 2016-06-04 03:00:02 --> Loader Class Initialized
INFO - 2016-06-04 03:00:02 --> Helper loaded: url_helper
INFO - 2016-06-04 03:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:00:02 --> Controller Class Initialized
INFO - 2016-06-04 03:00:02 --> Helper loaded: language_helper
INFO - 2016-06-04 03:00:02 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:00:02 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:00:02 --> Final output sent to browser
DEBUG - 2016-06-04 03:00:02 --> Total execution time: 0.1740
INFO - 2016-06-04 03:00:49 --> Config Class Initialized
INFO - 2016-06-04 03:00:49 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:00:49 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:00:49 --> Utf8 Class Initialized
INFO - 2016-06-04 03:00:49 --> URI Class Initialized
DEBUG - 2016-06-04 03:00:49 --> No URI present. Default controller set.
INFO - 2016-06-04 03:00:49 --> Router Class Initialized
INFO - 2016-06-04 03:00:49 --> Output Class Initialized
INFO - 2016-06-04 03:00:49 --> Security Class Initialized
DEBUG - 2016-06-04 03:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:00:49 --> Input Class Initialized
INFO - 2016-06-04 03:00:49 --> Language Class Initialized
INFO - 2016-06-04 03:00:49 --> Loader Class Initialized
INFO - 2016-06-04 03:00:49 --> Helper loaded: url_helper
INFO - 2016-06-04 03:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:00:49 --> Controller Class Initialized
INFO - 2016-06-04 03:00:49 --> Helper loaded: language_helper
INFO - 2016-06-04 03:00:49 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:00:49 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:00:49 --> Final output sent to browser
DEBUG - 2016-06-04 03:00:49 --> Total execution time: 0.1680
INFO - 2016-06-04 03:00:51 --> Config Class Initialized
INFO - 2016-06-04 03:00:51 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:00:51 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:00:51 --> Utf8 Class Initialized
INFO - 2016-06-04 03:00:51 --> URI Class Initialized
INFO - 2016-06-04 03:00:51 --> Router Class Initialized
INFO - 2016-06-04 03:00:51 --> Output Class Initialized
INFO - 2016-06-04 03:00:51 --> Security Class Initialized
DEBUG - 2016-06-04 03:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:00:51 --> Input Class Initialized
INFO - 2016-06-04 03:00:51 --> Language Class Initialized
INFO - 2016-06-04 03:00:51 --> Loader Class Initialized
INFO - 2016-06-04 03:00:51 --> Helper loaded: url_helper
INFO - 2016-06-04 03:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:00:51 --> Controller Class Initialized
INFO - 2016-06-04 03:00:51 --> Helper loaded: language_helper
INFO - 2016-06-04 03:00:51 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:00:51 --> Config Class Initialized
INFO - 2016-06-04 03:00:51 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:00:51 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:00:51 --> Utf8 Class Initialized
INFO - 2016-06-04 03:00:51 --> URI Class Initialized
DEBUG - 2016-06-04 03:00:51 --> No URI present. Default controller set.
INFO - 2016-06-04 03:00:51 --> Router Class Initialized
INFO - 2016-06-04 03:00:51 --> Output Class Initialized
INFO - 2016-06-04 03:00:52 --> Security Class Initialized
DEBUG - 2016-06-04 03:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:00:52 --> Input Class Initialized
INFO - 2016-06-04 03:00:52 --> Language Class Initialized
INFO - 2016-06-04 03:00:52 --> Loader Class Initialized
INFO - 2016-06-04 03:00:52 --> Helper loaded: url_helper
INFO - 2016-06-04 03:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:00:52 --> Controller Class Initialized
INFO - 2016-06-04 03:00:52 --> Helper loaded: language_helper
INFO - 2016-06-04 03:00:52 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:00:52 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:00:52 --> Final output sent to browser
DEBUG - 2016-06-04 03:00:52 --> Total execution time: 0.1630
INFO - 2016-06-04 03:00:54 --> Config Class Initialized
INFO - 2016-06-04 03:00:54 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:00:54 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:00:54 --> Utf8 Class Initialized
INFO - 2016-06-04 03:00:54 --> URI Class Initialized
INFO - 2016-06-04 03:00:54 --> Router Class Initialized
INFO - 2016-06-04 03:00:54 --> Output Class Initialized
INFO - 2016-06-04 03:00:54 --> Security Class Initialized
DEBUG - 2016-06-04 03:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:00:54 --> Input Class Initialized
INFO - 2016-06-04 03:00:54 --> Language Class Initialized
INFO - 2016-06-04 03:00:54 --> Loader Class Initialized
INFO - 2016-06-04 03:00:54 --> Helper loaded: url_helper
INFO - 2016-06-04 03:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:00:54 --> Controller Class Initialized
INFO - 2016-06-04 03:00:54 --> Helper loaded: language_helper
INFO - 2016-06-04 03:00:54 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:00:54 --> Config Class Initialized
INFO - 2016-06-04 03:00:54 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:00:54 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:00:54 --> Utf8 Class Initialized
INFO - 2016-06-04 03:00:54 --> URI Class Initialized
DEBUG - 2016-06-04 03:00:54 --> No URI present. Default controller set.
INFO - 2016-06-04 03:00:54 --> Router Class Initialized
INFO - 2016-06-04 03:00:54 --> Output Class Initialized
INFO - 2016-06-04 03:00:54 --> Security Class Initialized
DEBUG - 2016-06-04 03:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:00:54 --> Input Class Initialized
INFO - 2016-06-04 03:00:54 --> Language Class Initialized
INFO - 2016-06-04 03:00:54 --> Loader Class Initialized
INFO - 2016-06-04 03:00:55 --> Helper loaded: url_helper
INFO - 2016-06-04 03:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:00:55 --> Controller Class Initialized
INFO - 2016-06-04 03:00:55 --> Helper loaded: language_helper
INFO - 2016-06-04 03:00:55 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:00:55 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:00:55 --> Final output sent to browser
DEBUG - 2016-06-04 03:00:55 --> Total execution time: 0.1730
INFO - 2016-06-04 03:00:56 --> Config Class Initialized
INFO - 2016-06-04 03:00:56 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:00:56 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:00:56 --> Utf8 Class Initialized
INFO - 2016-06-04 03:00:56 --> URI Class Initialized
INFO - 2016-06-04 03:00:56 --> Router Class Initialized
INFO - 2016-06-04 03:00:56 --> Output Class Initialized
INFO - 2016-06-04 03:00:56 --> Security Class Initialized
DEBUG - 2016-06-04 03:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:00:56 --> Input Class Initialized
INFO - 2016-06-04 03:00:56 --> Language Class Initialized
INFO - 2016-06-04 03:00:56 --> Loader Class Initialized
INFO - 2016-06-04 03:00:56 --> Helper loaded: url_helper
INFO - 2016-06-04 03:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:00:56 --> Controller Class Initialized
INFO - 2016-06-04 03:00:56 --> Helper loaded: language_helper
INFO - 2016-06-04 03:00:56 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:00:56 --> Config Class Initialized
INFO - 2016-06-04 03:00:56 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:00:56 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:00:56 --> Utf8 Class Initialized
INFO - 2016-06-04 03:00:56 --> URI Class Initialized
DEBUG - 2016-06-04 03:00:56 --> No URI present. Default controller set.
INFO - 2016-06-04 03:00:56 --> Router Class Initialized
INFO - 2016-06-04 03:00:56 --> Output Class Initialized
INFO - 2016-06-04 03:00:56 --> Security Class Initialized
DEBUG - 2016-06-04 03:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:00:57 --> Input Class Initialized
INFO - 2016-06-04 03:00:57 --> Language Class Initialized
INFO - 2016-06-04 03:00:57 --> Loader Class Initialized
INFO - 2016-06-04 03:00:57 --> Helper loaded: url_helper
INFO - 2016-06-04 03:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:00:57 --> Controller Class Initialized
INFO - 2016-06-04 03:00:57 --> Helper loaded: language_helper
INFO - 2016-06-04 03:00:57 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:00:57 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:00:57 --> Final output sent to browser
DEBUG - 2016-06-04 03:00:57 --> Total execution time: 0.1830
INFO - 2016-06-04 03:00:58 --> Config Class Initialized
INFO - 2016-06-04 03:00:58 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:00:58 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:00:58 --> Utf8 Class Initialized
INFO - 2016-06-04 03:00:58 --> URI Class Initialized
INFO - 2016-06-04 03:00:58 --> Router Class Initialized
INFO - 2016-06-04 03:00:58 --> Output Class Initialized
INFO - 2016-06-04 03:00:58 --> Security Class Initialized
DEBUG - 2016-06-04 03:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:00:58 --> Input Class Initialized
INFO - 2016-06-04 03:00:58 --> Language Class Initialized
INFO - 2016-06-04 03:00:58 --> Loader Class Initialized
INFO - 2016-06-04 03:00:58 --> Helper loaded: url_helper
INFO - 2016-06-04 03:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:00:58 --> Controller Class Initialized
INFO - 2016-06-04 03:00:58 --> Helper loaded: language_helper
INFO - 2016-06-04 03:00:58 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:00:58 --> Config Class Initialized
INFO - 2016-06-04 03:00:58 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:00:58 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:00:58 --> Utf8 Class Initialized
INFO - 2016-06-04 03:00:58 --> URI Class Initialized
DEBUG - 2016-06-04 03:00:58 --> No URI present. Default controller set.
INFO - 2016-06-04 03:00:58 --> Router Class Initialized
INFO - 2016-06-04 03:00:58 --> Output Class Initialized
INFO - 2016-06-04 03:00:58 --> Security Class Initialized
DEBUG - 2016-06-04 03:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:00:58 --> Input Class Initialized
INFO - 2016-06-04 03:00:58 --> Language Class Initialized
INFO - 2016-06-04 03:00:58 --> Loader Class Initialized
INFO - 2016-06-04 03:00:58 --> Helper loaded: url_helper
INFO - 2016-06-04 03:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:00:58 --> Controller Class Initialized
INFO - 2016-06-04 03:00:58 --> Helper loaded: language_helper
INFO - 2016-06-04 03:00:58 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:00:58 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:00:58 --> Final output sent to browser
DEBUG - 2016-06-04 03:00:58 --> Total execution time: 0.2040
INFO - 2016-06-04 03:01:00 --> Config Class Initialized
INFO - 2016-06-04 03:01:00 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:01:00 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:01:00 --> Utf8 Class Initialized
INFO - 2016-06-04 03:01:00 --> URI Class Initialized
INFO - 2016-06-04 03:01:00 --> Router Class Initialized
INFO - 2016-06-04 03:01:00 --> Output Class Initialized
INFO - 2016-06-04 03:01:00 --> Security Class Initialized
DEBUG - 2016-06-04 03:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:01:00 --> Input Class Initialized
INFO - 2016-06-04 03:01:00 --> Language Class Initialized
INFO - 2016-06-04 03:01:00 --> Loader Class Initialized
INFO - 2016-06-04 03:01:00 --> Helper loaded: url_helper
INFO - 2016-06-04 03:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:01:00 --> Controller Class Initialized
INFO - 2016-06-04 03:01:00 --> Helper loaded: language_helper
INFO - 2016-06-04 03:01:00 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:01:00 --> Config Class Initialized
INFO - 2016-06-04 03:01:00 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:01:00 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:01:00 --> Utf8 Class Initialized
INFO - 2016-06-04 03:01:00 --> URI Class Initialized
DEBUG - 2016-06-04 03:01:00 --> No URI present. Default controller set.
INFO - 2016-06-04 03:01:00 --> Router Class Initialized
INFO - 2016-06-04 03:01:00 --> Output Class Initialized
INFO - 2016-06-04 03:01:00 --> Security Class Initialized
DEBUG - 2016-06-04 03:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:01:00 --> Input Class Initialized
INFO - 2016-06-04 03:01:00 --> Language Class Initialized
INFO - 2016-06-04 03:01:00 --> Loader Class Initialized
INFO - 2016-06-04 03:01:00 --> Helper loaded: url_helper
INFO - 2016-06-04 03:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:01:00 --> Controller Class Initialized
INFO - 2016-06-04 03:01:00 --> Helper loaded: language_helper
INFO - 2016-06-04 03:01:00 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:01:00 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:01:00 --> Final output sent to browser
DEBUG - 2016-06-04 03:01:00 --> Total execution time: 0.2100
INFO - 2016-06-04 03:01:04 --> Config Class Initialized
INFO - 2016-06-04 03:01:04 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:01:04 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:01:04 --> Utf8 Class Initialized
INFO - 2016-06-04 03:01:04 --> URI Class Initialized
INFO - 2016-06-04 03:01:04 --> Router Class Initialized
INFO - 2016-06-04 03:01:04 --> Output Class Initialized
INFO - 2016-06-04 03:01:04 --> Security Class Initialized
DEBUG - 2016-06-04 03:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:01:04 --> Input Class Initialized
INFO - 2016-06-04 03:01:04 --> Language Class Initialized
INFO - 2016-06-04 03:01:04 --> Loader Class Initialized
INFO - 2016-06-04 03:01:04 --> Helper loaded: url_helper
INFO - 2016-06-04 03:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:01:04 --> Controller Class Initialized
INFO - 2016-06-04 03:01:04 --> Helper loaded: language_helper
INFO - 2016-06-04 03:01:04 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:01:04 --> Config Class Initialized
INFO - 2016-06-04 03:01:04 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:01:04 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:01:04 --> Utf8 Class Initialized
INFO - 2016-06-04 03:01:04 --> URI Class Initialized
DEBUG - 2016-06-04 03:01:04 --> No URI present. Default controller set.
INFO - 2016-06-04 03:01:04 --> Router Class Initialized
INFO - 2016-06-04 03:01:04 --> Output Class Initialized
INFO - 2016-06-04 03:01:04 --> Security Class Initialized
DEBUG - 2016-06-04 03:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:01:04 --> Input Class Initialized
INFO - 2016-06-04 03:01:04 --> Language Class Initialized
INFO - 2016-06-04 03:01:04 --> Loader Class Initialized
INFO - 2016-06-04 03:01:04 --> Helper loaded: url_helper
INFO - 2016-06-04 03:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:01:04 --> Controller Class Initialized
INFO - 2016-06-04 03:01:04 --> Helper loaded: language_helper
INFO - 2016-06-04 03:01:04 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:01:04 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:01:04 --> Final output sent to browser
DEBUG - 2016-06-04 03:01:04 --> Total execution time: 0.2100
INFO - 2016-06-04 03:02:05 --> Config Class Initialized
INFO - 2016-06-04 03:02:05 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:02:05 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:02:05 --> Utf8 Class Initialized
INFO - 2016-06-04 03:02:05 --> URI Class Initialized
DEBUG - 2016-06-04 03:02:05 --> No URI present. Default controller set.
INFO - 2016-06-04 03:02:05 --> Router Class Initialized
INFO - 2016-06-04 03:02:06 --> Output Class Initialized
INFO - 2016-06-04 03:02:06 --> Security Class Initialized
DEBUG - 2016-06-04 03:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:02:06 --> Input Class Initialized
INFO - 2016-06-04 03:02:06 --> Language Class Initialized
INFO - 2016-06-04 03:02:06 --> Loader Class Initialized
INFO - 2016-06-04 03:02:06 --> Helper loaded: url_helper
INFO - 2016-06-04 03:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:02:06 --> Controller Class Initialized
INFO - 2016-06-04 03:02:06 --> Helper loaded: language_helper
INFO - 2016-06-04 03:02:06 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:02:06 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:02:06 --> Final output sent to browser
DEBUG - 2016-06-04 03:02:06 --> Total execution time: 0.1790
INFO - 2016-06-04 03:02:08 --> Config Class Initialized
INFO - 2016-06-04 03:02:08 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:02:08 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:02:08 --> Utf8 Class Initialized
INFO - 2016-06-04 03:02:08 --> URI Class Initialized
INFO - 2016-06-04 03:02:08 --> Router Class Initialized
INFO - 2016-06-04 03:02:08 --> Output Class Initialized
INFO - 2016-06-04 03:02:08 --> Security Class Initialized
DEBUG - 2016-06-04 03:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:02:08 --> Input Class Initialized
INFO - 2016-06-04 03:02:08 --> Language Class Initialized
INFO - 2016-06-04 03:02:08 --> Loader Class Initialized
INFO - 2016-06-04 03:02:08 --> Helper loaded: url_helper
INFO - 2016-06-04 03:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:02:08 --> Controller Class Initialized
INFO - 2016-06-04 03:02:08 --> Helper loaded: language_helper
INFO - 2016-06-04 03:02:08 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:02:08 --> Config Class Initialized
INFO - 2016-06-04 03:02:08 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:02:08 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:02:08 --> Utf8 Class Initialized
INFO - 2016-06-04 03:02:08 --> URI Class Initialized
DEBUG - 2016-06-04 03:02:08 --> No URI present. Default controller set.
INFO - 2016-06-04 03:02:08 --> Router Class Initialized
INFO - 2016-06-04 03:02:08 --> Output Class Initialized
INFO - 2016-06-04 03:02:08 --> Security Class Initialized
DEBUG - 2016-06-04 03:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:02:08 --> Input Class Initialized
INFO - 2016-06-04 03:02:08 --> Language Class Initialized
INFO - 2016-06-04 03:02:08 --> Loader Class Initialized
INFO - 2016-06-04 03:02:08 --> Helper loaded: url_helper
INFO - 2016-06-04 03:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:02:08 --> Controller Class Initialized
INFO - 2016-06-04 03:02:08 --> Helper loaded: language_helper
INFO - 2016-06-04 03:02:08 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:02:08 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:02:08 --> Final output sent to browser
DEBUG - 2016-06-04 03:02:08 --> Total execution time: 0.1670
INFO - 2016-06-04 03:02:09 --> Config Class Initialized
INFO - 2016-06-04 03:02:09 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:02:09 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:02:09 --> Utf8 Class Initialized
INFO - 2016-06-04 03:02:09 --> URI Class Initialized
INFO - 2016-06-04 03:02:09 --> Router Class Initialized
INFO - 2016-06-04 03:02:09 --> Output Class Initialized
INFO - 2016-06-04 03:02:09 --> Security Class Initialized
DEBUG - 2016-06-04 03:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:02:10 --> Input Class Initialized
INFO - 2016-06-04 03:02:10 --> Language Class Initialized
INFO - 2016-06-04 03:02:10 --> Loader Class Initialized
INFO - 2016-06-04 03:02:10 --> Helper loaded: url_helper
INFO - 2016-06-04 03:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:02:10 --> Controller Class Initialized
INFO - 2016-06-04 03:02:10 --> Helper loaded: language_helper
INFO - 2016-06-04 03:02:10 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:02:10 --> Config Class Initialized
INFO - 2016-06-04 03:02:10 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:02:10 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:02:10 --> Utf8 Class Initialized
INFO - 2016-06-04 03:02:10 --> URI Class Initialized
DEBUG - 2016-06-04 03:02:10 --> No URI present. Default controller set.
INFO - 2016-06-04 03:02:10 --> Router Class Initialized
INFO - 2016-06-04 03:02:10 --> Output Class Initialized
INFO - 2016-06-04 03:02:10 --> Security Class Initialized
DEBUG - 2016-06-04 03:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:02:10 --> Input Class Initialized
INFO - 2016-06-04 03:02:10 --> Language Class Initialized
INFO - 2016-06-04 03:02:10 --> Loader Class Initialized
INFO - 2016-06-04 03:02:10 --> Helper loaded: url_helper
INFO - 2016-06-04 03:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:02:10 --> Controller Class Initialized
INFO - 2016-06-04 03:02:10 --> Helper loaded: language_helper
INFO - 2016-06-04 03:02:10 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:02:10 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:02:10 --> Final output sent to browser
DEBUG - 2016-06-04 03:02:10 --> Total execution time: 0.1710
INFO - 2016-06-04 03:02:11 --> Config Class Initialized
INFO - 2016-06-04 03:02:11 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:02:11 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:02:11 --> Utf8 Class Initialized
INFO - 2016-06-04 03:02:11 --> URI Class Initialized
INFO - 2016-06-04 03:02:11 --> Router Class Initialized
INFO - 2016-06-04 03:02:11 --> Output Class Initialized
INFO - 2016-06-04 03:02:11 --> Security Class Initialized
DEBUG - 2016-06-04 03:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:02:11 --> Input Class Initialized
INFO - 2016-06-04 03:02:11 --> Language Class Initialized
INFO - 2016-06-04 03:02:11 --> Loader Class Initialized
INFO - 2016-06-04 03:02:11 --> Helper loaded: url_helper
INFO - 2016-06-04 03:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:02:11 --> Controller Class Initialized
INFO - 2016-06-04 03:02:11 --> Helper loaded: language_helper
INFO - 2016-06-04 03:02:11 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:02:11 --> Config Class Initialized
INFO - 2016-06-04 03:02:11 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:02:11 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:02:11 --> Utf8 Class Initialized
INFO - 2016-06-04 03:02:11 --> URI Class Initialized
DEBUG - 2016-06-04 03:02:11 --> No URI present. Default controller set.
INFO - 2016-06-04 03:02:11 --> Router Class Initialized
INFO - 2016-06-04 03:02:11 --> Output Class Initialized
INFO - 2016-06-04 03:02:11 --> Security Class Initialized
DEBUG - 2016-06-04 03:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:02:11 --> Input Class Initialized
INFO - 2016-06-04 03:02:11 --> Language Class Initialized
INFO - 2016-06-04 03:02:11 --> Loader Class Initialized
INFO - 2016-06-04 03:02:11 --> Helper loaded: url_helper
INFO - 2016-06-04 03:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:02:11 --> Controller Class Initialized
INFO - 2016-06-04 03:02:11 --> Helper loaded: language_helper
INFO - 2016-06-04 03:02:11 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:02:12 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:02:12 --> Final output sent to browser
DEBUG - 2016-06-04 03:02:12 --> Total execution time: 0.1820
INFO - 2016-06-04 03:02:16 --> Config Class Initialized
INFO - 2016-06-04 03:02:16 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:02:16 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:02:16 --> Utf8 Class Initialized
INFO - 2016-06-04 03:02:16 --> URI Class Initialized
INFO - 2016-06-04 03:02:16 --> Router Class Initialized
INFO - 2016-06-04 03:02:16 --> Output Class Initialized
INFO - 2016-06-04 03:02:16 --> Security Class Initialized
DEBUG - 2016-06-04 03:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:02:16 --> Input Class Initialized
INFO - 2016-06-04 03:02:16 --> Language Class Initialized
INFO - 2016-06-04 03:02:16 --> Loader Class Initialized
INFO - 2016-06-04 03:02:16 --> Helper loaded: url_helper
INFO - 2016-06-04 03:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:02:16 --> Controller Class Initialized
INFO - 2016-06-04 03:02:16 --> Helper loaded: language_helper
INFO - 2016-06-04 03:02:16 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:02:16 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\contact.php
INFO - 2016-06-04 03:02:16 --> Final output sent to browser
DEBUG - 2016-06-04 03:02:16 --> Total execution time: 0.1730
INFO - 2016-06-04 03:02:22 --> Config Class Initialized
INFO - 2016-06-04 03:02:22 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:02:22 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:02:22 --> Utf8 Class Initialized
INFO - 2016-06-04 03:02:22 --> URI Class Initialized
INFO - 2016-06-04 03:02:22 --> Router Class Initialized
INFO - 2016-06-04 03:02:22 --> Output Class Initialized
INFO - 2016-06-04 03:02:22 --> Security Class Initialized
DEBUG - 2016-06-04 03:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:02:22 --> Input Class Initialized
INFO - 2016-06-04 03:02:22 --> Language Class Initialized
INFO - 2016-06-04 03:02:22 --> Loader Class Initialized
INFO - 2016-06-04 03:02:22 --> Helper loaded: url_helper
INFO - 2016-06-04 03:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:02:22 --> Controller Class Initialized
INFO - 2016-06-04 03:02:22 --> Helper loaded: language_helper
INFO - 2016-06-04 03:02:22 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:02:22 --> Config Class Initialized
INFO - 2016-06-04 03:02:22 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:02:22 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:02:22 --> Utf8 Class Initialized
INFO - 2016-06-04 03:02:22 --> URI Class Initialized
INFO - 2016-06-04 03:02:22 --> Router Class Initialized
INFO - 2016-06-04 03:02:22 --> Output Class Initialized
INFO - 2016-06-04 03:02:22 --> Security Class Initialized
DEBUG - 2016-06-04 03:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:02:22 --> Input Class Initialized
INFO - 2016-06-04 03:02:22 --> Language Class Initialized
INFO - 2016-06-04 03:02:22 --> Loader Class Initialized
INFO - 2016-06-04 03:02:22 --> Helper loaded: url_helper
INFO - 2016-06-04 03:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:02:22 --> Controller Class Initialized
INFO - 2016-06-04 03:02:22 --> Helper loaded: language_helper
INFO - 2016-06-04 03:02:22 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:02:22 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\contact.php
INFO - 2016-06-04 03:02:22 --> Final output sent to browser
DEBUG - 2016-06-04 03:02:22 --> Total execution time: 0.1610
INFO - 2016-06-04 03:02:27 --> Config Class Initialized
INFO - 2016-06-04 03:02:27 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:02:27 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:02:27 --> Utf8 Class Initialized
INFO - 2016-06-04 03:02:27 --> URI Class Initialized
INFO - 2016-06-04 03:02:27 --> Router Class Initialized
INFO - 2016-06-04 03:02:27 --> Output Class Initialized
INFO - 2016-06-04 03:02:27 --> Security Class Initialized
DEBUG - 2016-06-04 03:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:02:27 --> Input Class Initialized
INFO - 2016-06-04 03:02:27 --> Language Class Initialized
INFO - 2016-06-04 03:02:27 --> Loader Class Initialized
INFO - 2016-06-04 03:02:27 --> Helper loaded: url_helper
INFO - 2016-06-04 03:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:02:27 --> Controller Class Initialized
INFO - 2016-06-04 03:02:27 --> Helper loaded: language_helper
INFO - 2016-06-04 03:02:27 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:02:27 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:02:27 --> Final output sent to browser
DEBUG - 2016-06-04 03:02:27 --> Total execution time: 0.1850
INFO - 2016-06-04 03:13:20 --> Config Class Initialized
INFO - 2016-06-04 03:13:20 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:13:20 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:13:20 --> Utf8 Class Initialized
INFO - 2016-06-04 03:13:20 --> URI Class Initialized
INFO - 2016-06-04 03:13:20 --> Router Class Initialized
INFO - 2016-06-04 03:13:20 --> Output Class Initialized
INFO - 2016-06-04 03:13:20 --> Security Class Initialized
DEBUG - 2016-06-04 03:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:13:20 --> Input Class Initialized
INFO - 2016-06-04 03:13:20 --> Language Class Initialized
INFO - 2016-06-04 03:13:20 --> Loader Class Initialized
INFO - 2016-06-04 03:13:20 --> Helper loaded: url_helper
INFO - 2016-06-04 03:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:13:20 --> Controller Class Initialized
INFO - 2016-06-04 03:13:20 --> Helper loaded: language_helper
INFO - 2016-06-04 03:13:20 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:13:20 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:13:20 --> Final output sent to browser
DEBUG - 2016-06-04 03:13:20 --> Total execution time: 0.2120
INFO - 2016-06-04 03:13:50 --> Config Class Initialized
INFO - 2016-06-04 03:13:50 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:13:50 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:13:50 --> Utf8 Class Initialized
INFO - 2016-06-04 03:13:50 --> URI Class Initialized
INFO - 2016-06-04 03:13:50 --> Router Class Initialized
INFO - 2016-06-04 03:13:50 --> Output Class Initialized
INFO - 2016-06-04 03:13:50 --> Security Class Initialized
DEBUG - 2016-06-04 03:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:13:50 --> Input Class Initialized
INFO - 2016-06-04 03:13:50 --> Language Class Initialized
INFO - 2016-06-04 03:13:50 --> Loader Class Initialized
INFO - 2016-06-04 03:13:50 --> Helper loaded: url_helper
INFO - 2016-06-04 03:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:13:50 --> Controller Class Initialized
INFO - 2016-06-04 03:13:50 --> Helper loaded: language_helper
INFO - 2016-06-04 03:13:50 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:13:50 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:13:50 --> Final output sent to browser
DEBUG - 2016-06-04 03:13:50 --> Total execution time: 0.2000
INFO - 2016-06-04 03:13:56 --> Config Class Initialized
INFO - 2016-06-04 03:13:56 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:13:56 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:13:56 --> Utf8 Class Initialized
INFO - 2016-06-04 03:13:56 --> URI Class Initialized
INFO - 2016-06-04 03:13:56 --> Router Class Initialized
INFO - 2016-06-04 03:13:56 --> Output Class Initialized
INFO - 2016-06-04 03:13:56 --> Security Class Initialized
DEBUG - 2016-06-04 03:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:13:56 --> Input Class Initialized
INFO - 2016-06-04 03:13:56 --> Language Class Initialized
INFO - 2016-06-04 03:13:56 --> Loader Class Initialized
INFO - 2016-06-04 03:13:56 --> Helper loaded: url_helper
INFO - 2016-06-04 03:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:13:56 --> Controller Class Initialized
INFO - 2016-06-04 03:13:56 --> Helper loaded: language_helper
INFO - 2016-06-04 03:13:56 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:13:56 --> Config Class Initialized
INFO - 2016-06-04 03:13:56 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:13:56 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:13:56 --> Utf8 Class Initialized
INFO - 2016-06-04 03:13:56 --> URI Class Initialized
INFO - 2016-06-04 03:13:56 --> Router Class Initialized
INFO - 2016-06-04 03:13:56 --> Output Class Initialized
INFO - 2016-06-04 03:13:56 --> Security Class Initialized
DEBUG - 2016-06-04 03:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:13:56 --> Input Class Initialized
INFO - 2016-06-04 03:13:56 --> Language Class Initialized
INFO - 2016-06-04 03:13:56 --> Loader Class Initialized
INFO - 2016-06-04 03:13:56 --> Helper loaded: url_helper
INFO - 2016-06-04 03:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:13:56 --> Controller Class Initialized
INFO - 2016-06-04 03:13:56 --> Helper loaded: language_helper
INFO - 2016-06-04 03:13:57 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:13:57 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:13:57 --> Final output sent to browser
DEBUG - 2016-06-04 03:13:57 --> Total execution time: 0.1890
INFO - 2016-06-04 03:13:59 --> Config Class Initialized
INFO - 2016-06-04 03:13:59 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:13:59 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:13:59 --> Utf8 Class Initialized
INFO - 2016-06-04 03:13:59 --> URI Class Initialized
INFO - 2016-06-04 03:13:59 --> Router Class Initialized
INFO - 2016-06-04 03:13:59 --> Output Class Initialized
INFO - 2016-06-04 03:13:59 --> Security Class Initialized
DEBUG - 2016-06-04 03:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:13:59 --> Input Class Initialized
INFO - 2016-06-04 03:13:59 --> Language Class Initialized
INFO - 2016-06-04 03:13:59 --> Loader Class Initialized
INFO - 2016-06-04 03:13:59 --> Helper loaded: url_helper
INFO - 2016-06-04 03:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:13:59 --> Controller Class Initialized
INFO - 2016-06-04 03:13:59 --> Helper loaded: language_helper
INFO - 2016-06-04 03:13:59 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:13:59 --> Config Class Initialized
INFO - 2016-06-04 03:13:59 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:13:59 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:13:59 --> Utf8 Class Initialized
INFO - 2016-06-04 03:13:59 --> URI Class Initialized
INFO - 2016-06-04 03:13:59 --> Router Class Initialized
INFO - 2016-06-04 03:13:59 --> Output Class Initialized
INFO - 2016-06-04 03:13:59 --> Security Class Initialized
DEBUG - 2016-06-04 03:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:13:59 --> Input Class Initialized
INFO - 2016-06-04 03:13:59 --> Language Class Initialized
INFO - 2016-06-04 03:13:59 --> Loader Class Initialized
INFO - 2016-06-04 03:13:59 --> Helper loaded: url_helper
INFO - 2016-06-04 03:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:13:59 --> Controller Class Initialized
INFO - 2016-06-04 03:13:59 --> Helper loaded: language_helper
INFO - 2016-06-04 03:13:59 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:13:59 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:13:59 --> Final output sent to browser
DEBUG - 2016-06-04 03:13:59 --> Total execution time: 0.1830
INFO - 2016-06-04 03:14:01 --> Config Class Initialized
INFO - 2016-06-04 03:14:01 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:14:01 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:14:01 --> Utf8 Class Initialized
INFO - 2016-06-04 03:14:01 --> URI Class Initialized
INFO - 2016-06-04 03:14:01 --> Router Class Initialized
INFO - 2016-06-04 03:14:01 --> Output Class Initialized
INFO - 2016-06-04 03:14:01 --> Security Class Initialized
DEBUG - 2016-06-04 03:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:14:01 --> Input Class Initialized
INFO - 2016-06-04 03:14:01 --> Language Class Initialized
INFO - 2016-06-04 03:14:01 --> Loader Class Initialized
INFO - 2016-06-04 03:14:01 --> Helper loaded: url_helper
INFO - 2016-06-04 03:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:14:01 --> Controller Class Initialized
INFO - 2016-06-04 03:14:01 --> Helper loaded: language_helper
INFO - 2016-06-04 03:14:01 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:14:01 --> Config Class Initialized
INFO - 2016-06-04 03:14:01 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:14:01 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:14:01 --> Utf8 Class Initialized
INFO - 2016-06-04 03:14:01 --> URI Class Initialized
INFO - 2016-06-04 03:14:01 --> Router Class Initialized
INFO - 2016-06-04 03:14:01 --> Output Class Initialized
INFO - 2016-06-04 03:14:01 --> Security Class Initialized
DEBUG - 2016-06-04 03:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:14:01 --> Input Class Initialized
INFO - 2016-06-04 03:14:01 --> Language Class Initialized
INFO - 2016-06-04 03:14:01 --> Loader Class Initialized
INFO - 2016-06-04 03:14:01 --> Helper loaded: url_helper
INFO - 2016-06-04 03:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:14:01 --> Controller Class Initialized
INFO - 2016-06-04 03:14:01 --> Helper loaded: language_helper
INFO - 2016-06-04 03:14:01 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:14:01 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:14:01 --> Final output sent to browser
DEBUG - 2016-06-04 03:14:01 --> Total execution time: 0.1970
INFO - 2016-06-04 03:14:24 --> Config Class Initialized
INFO - 2016-06-04 03:14:24 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:14:24 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:14:24 --> Utf8 Class Initialized
INFO - 2016-06-04 03:14:24 --> URI Class Initialized
INFO - 2016-06-04 03:14:24 --> Router Class Initialized
INFO - 2016-06-04 03:14:24 --> Output Class Initialized
INFO - 2016-06-04 03:14:24 --> Security Class Initialized
DEBUG - 2016-06-04 03:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:14:24 --> Input Class Initialized
INFO - 2016-06-04 03:14:24 --> Language Class Initialized
INFO - 2016-06-04 03:14:24 --> Loader Class Initialized
INFO - 2016-06-04 03:14:24 --> Helper loaded: url_helper
INFO - 2016-06-04 03:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:14:24 --> Controller Class Initialized
INFO - 2016-06-04 03:14:24 --> Helper loaded: language_helper
INFO - 2016-06-04 03:14:24 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:14:24 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:14:24 --> Final output sent to browser
DEBUG - 2016-06-04 03:14:24 --> Total execution time: 0.1920
INFO - 2016-06-04 03:16:07 --> Config Class Initialized
INFO - 2016-06-04 03:16:07 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:16:07 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:16:07 --> Utf8 Class Initialized
INFO - 2016-06-04 03:16:07 --> URI Class Initialized
INFO - 2016-06-04 03:16:07 --> Router Class Initialized
INFO - 2016-06-04 03:16:07 --> Output Class Initialized
INFO - 2016-06-04 03:16:07 --> Security Class Initialized
DEBUG - 2016-06-04 03:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:16:07 --> Input Class Initialized
INFO - 2016-06-04 03:16:07 --> Language Class Initialized
INFO - 2016-06-04 03:16:07 --> Loader Class Initialized
INFO - 2016-06-04 03:16:07 --> Helper loaded: url_helper
INFO - 2016-06-04 03:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:16:07 --> Controller Class Initialized
INFO - 2016-06-04 03:16:07 --> Helper loaded: language_helper
INFO - 2016-06-04 03:16:07 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:16:07 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:16:07 --> Final output sent to browser
DEBUG - 2016-06-04 03:16:07 --> Total execution time: 0.2220
INFO - 2016-06-04 03:16:37 --> Config Class Initialized
INFO - 2016-06-04 03:16:37 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:16:37 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:16:37 --> Utf8 Class Initialized
INFO - 2016-06-04 03:16:37 --> URI Class Initialized
INFO - 2016-06-04 03:16:37 --> Router Class Initialized
INFO - 2016-06-04 03:16:37 --> Output Class Initialized
INFO - 2016-06-04 03:16:37 --> Security Class Initialized
DEBUG - 2016-06-04 03:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:16:37 --> Input Class Initialized
INFO - 2016-06-04 03:16:37 --> Language Class Initialized
INFO - 2016-06-04 03:16:37 --> Loader Class Initialized
INFO - 2016-06-04 03:16:37 --> Helper loaded: url_helper
INFO - 2016-06-04 03:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:16:37 --> Controller Class Initialized
INFO - 2016-06-04 03:16:37 --> Helper loaded: language_helper
INFO - 2016-06-04 03:16:37 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:16:37 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:16:37 --> Final output sent to browser
DEBUG - 2016-06-04 03:16:37 --> Total execution time: 0.1960
INFO - 2016-06-04 03:17:47 --> Config Class Initialized
INFO - 2016-06-04 03:17:47 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:17:47 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:17:47 --> Utf8 Class Initialized
INFO - 2016-06-04 03:17:47 --> URI Class Initialized
INFO - 2016-06-04 03:17:47 --> Router Class Initialized
INFO - 2016-06-04 03:17:47 --> Output Class Initialized
INFO - 2016-06-04 03:17:47 --> Security Class Initialized
DEBUG - 2016-06-04 03:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:17:47 --> Input Class Initialized
INFO - 2016-06-04 03:17:47 --> Language Class Initialized
INFO - 2016-06-04 03:17:47 --> Loader Class Initialized
INFO - 2016-06-04 03:17:47 --> Helper loaded: url_helper
INFO - 2016-06-04 03:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:17:47 --> Controller Class Initialized
INFO - 2016-06-04 03:17:47 --> Helper loaded: language_helper
INFO - 2016-06-04 03:17:47 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:17:47 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:17:47 --> Final output sent to browser
DEBUG - 2016-06-04 03:17:47 --> Total execution time: 0.1800
INFO - 2016-06-04 03:17:50 --> Config Class Initialized
INFO - 2016-06-04 03:17:50 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:17:50 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:17:50 --> Utf8 Class Initialized
INFO - 2016-06-04 03:17:50 --> URI Class Initialized
INFO - 2016-06-04 03:17:50 --> Router Class Initialized
INFO - 2016-06-04 03:17:50 --> Output Class Initialized
INFO - 2016-06-04 03:17:50 --> Security Class Initialized
DEBUG - 2016-06-04 03:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:17:50 --> Input Class Initialized
INFO - 2016-06-04 03:17:50 --> Language Class Initialized
INFO - 2016-06-04 03:17:50 --> Loader Class Initialized
INFO - 2016-06-04 03:17:50 --> Helper loaded: url_helper
INFO - 2016-06-04 03:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:17:50 --> Controller Class Initialized
INFO - 2016-06-04 03:17:50 --> Helper loaded: language_helper
INFO - 2016-06-04 03:17:50 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:17:50 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:17:50 --> Final output sent to browser
DEBUG - 2016-06-04 03:17:50 --> Total execution time: 0.2100
INFO - 2016-06-04 03:17:52 --> Config Class Initialized
INFO - 2016-06-04 03:17:52 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:17:52 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:17:52 --> Utf8 Class Initialized
INFO - 2016-06-04 03:17:52 --> URI Class Initialized
INFO - 2016-06-04 03:17:52 --> Router Class Initialized
INFO - 2016-06-04 03:17:52 --> Output Class Initialized
INFO - 2016-06-04 03:17:52 --> Security Class Initialized
DEBUG - 2016-06-04 03:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:17:52 --> Input Class Initialized
INFO - 2016-06-04 03:17:52 --> Language Class Initialized
INFO - 2016-06-04 03:17:52 --> Loader Class Initialized
INFO - 2016-06-04 03:17:52 --> Helper loaded: url_helper
INFO - 2016-06-04 03:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:17:52 --> Controller Class Initialized
INFO - 2016-06-04 03:17:52 --> Helper loaded: language_helper
INFO - 2016-06-04 03:17:52 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:17:52 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 03:17:52 --> Final output sent to browser
DEBUG - 2016-06-04 03:17:52 --> Total execution time: 0.2000
INFO - 2016-06-04 03:17:53 --> Config Class Initialized
INFO - 2016-06-04 03:17:53 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:17:53 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:17:53 --> Utf8 Class Initialized
INFO - 2016-06-04 03:17:53 --> URI Class Initialized
INFO - 2016-06-04 03:17:53 --> Router Class Initialized
INFO - 2016-06-04 03:17:53 --> Output Class Initialized
INFO - 2016-06-04 03:17:53 --> Security Class Initialized
DEBUG - 2016-06-04 03:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:17:53 --> Input Class Initialized
INFO - 2016-06-04 03:17:53 --> Language Class Initialized
INFO - 2016-06-04 03:17:53 --> Loader Class Initialized
INFO - 2016-06-04 03:17:53 --> Helper loaded: url_helper
INFO - 2016-06-04 03:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:17:53 --> Controller Class Initialized
INFO - 2016-06-04 03:17:53 --> Helper loaded: language_helper
INFO - 2016-06-04 03:17:53 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:17:53 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:17:53 --> Final output sent to browser
DEBUG - 2016-06-04 03:17:53 --> Total execution time: 0.1980
INFO - 2016-06-04 03:17:54 --> Config Class Initialized
INFO - 2016-06-04 03:17:54 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:17:54 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:17:54 --> Utf8 Class Initialized
INFO - 2016-06-04 03:17:54 --> URI Class Initialized
INFO - 2016-06-04 03:17:54 --> Router Class Initialized
INFO - 2016-06-04 03:17:54 --> Output Class Initialized
INFO - 2016-06-04 03:17:54 --> Security Class Initialized
DEBUG - 2016-06-04 03:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:17:54 --> Input Class Initialized
INFO - 2016-06-04 03:17:54 --> Language Class Initialized
INFO - 2016-06-04 03:17:54 --> Loader Class Initialized
INFO - 2016-06-04 03:17:54 --> Helper loaded: url_helper
INFO - 2016-06-04 03:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:17:54 --> Controller Class Initialized
INFO - 2016-06-04 03:17:54 --> Helper loaded: language_helper
INFO - 2016-06-04 03:17:54 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:17:54 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 03:17:54 --> Final output sent to browser
DEBUG - 2016-06-04 03:17:54 --> Total execution time: 0.2010
INFO - 2016-06-04 03:17:55 --> Config Class Initialized
INFO - 2016-06-04 03:17:55 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:17:55 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:17:55 --> Utf8 Class Initialized
INFO - 2016-06-04 03:17:55 --> URI Class Initialized
INFO - 2016-06-04 03:17:55 --> Router Class Initialized
INFO - 2016-06-04 03:17:55 --> Output Class Initialized
INFO - 2016-06-04 03:17:55 --> Security Class Initialized
DEBUG - 2016-06-04 03:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:17:55 --> Input Class Initialized
INFO - 2016-06-04 03:17:55 --> Language Class Initialized
INFO - 2016-06-04 03:17:55 --> Loader Class Initialized
INFO - 2016-06-04 03:17:55 --> Helper loaded: url_helper
INFO - 2016-06-04 03:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:17:55 --> Controller Class Initialized
INFO - 2016-06-04 03:17:55 --> Helper loaded: language_helper
INFO - 2016-06-04 03:17:55 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:17:55 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\contact.php
INFO - 2016-06-04 03:17:55 --> Final output sent to browser
DEBUG - 2016-06-04 03:17:55 --> Total execution time: 0.1960
INFO - 2016-06-04 03:17:56 --> Config Class Initialized
INFO - 2016-06-04 03:17:56 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:17:56 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:17:56 --> Utf8 Class Initialized
INFO - 2016-06-04 03:17:56 --> URI Class Initialized
INFO - 2016-06-04 03:17:56 --> Router Class Initialized
INFO - 2016-06-04 03:17:56 --> Output Class Initialized
INFO - 2016-06-04 03:17:56 --> Security Class Initialized
DEBUG - 2016-06-04 03:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:17:56 --> Input Class Initialized
INFO - 2016-06-04 03:17:56 --> Language Class Initialized
INFO - 2016-06-04 03:17:56 --> Loader Class Initialized
INFO - 2016-06-04 03:17:56 --> Helper loaded: url_helper
INFO - 2016-06-04 03:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:17:56 --> Controller Class Initialized
INFO - 2016-06-04 03:17:56 --> Helper loaded: language_helper
INFO - 2016-06-04 03:17:56 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:17:56 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:17:56 --> Final output sent to browser
DEBUG - 2016-06-04 03:17:56 --> Total execution time: 0.1930
INFO - 2016-06-04 03:18:07 --> Config Class Initialized
INFO - 2016-06-04 03:18:07 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:18:07 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:18:07 --> Utf8 Class Initialized
INFO - 2016-06-04 03:18:07 --> URI Class Initialized
INFO - 2016-06-04 03:18:07 --> Router Class Initialized
INFO - 2016-06-04 03:18:08 --> Output Class Initialized
INFO - 2016-06-04 03:18:08 --> Security Class Initialized
DEBUG - 2016-06-04 03:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:18:08 --> Input Class Initialized
INFO - 2016-06-04 03:18:08 --> Language Class Initialized
INFO - 2016-06-04 03:18:08 --> Loader Class Initialized
INFO - 2016-06-04 03:18:08 --> Helper loaded: url_helper
INFO - 2016-06-04 03:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:18:08 --> Controller Class Initialized
INFO - 2016-06-04 03:18:08 --> Helper loaded: language_helper
INFO - 2016-06-04 03:18:08 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:18:08 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:18:08 --> Final output sent to browser
DEBUG - 2016-06-04 03:18:08 --> Total execution time: 0.1950
INFO - 2016-06-04 03:18:09 --> Config Class Initialized
INFO - 2016-06-04 03:18:09 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:18:09 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:18:09 --> Utf8 Class Initialized
INFO - 2016-06-04 03:18:09 --> URI Class Initialized
DEBUG - 2016-06-04 03:18:09 --> No URI present. Default controller set.
INFO - 2016-06-04 03:18:09 --> Router Class Initialized
INFO - 2016-06-04 03:18:09 --> Output Class Initialized
INFO - 2016-06-04 03:18:09 --> Security Class Initialized
DEBUG - 2016-06-04 03:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:18:09 --> Input Class Initialized
INFO - 2016-06-04 03:18:09 --> Language Class Initialized
INFO - 2016-06-04 03:18:09 --> Loader Class Initialized
INFO - 2016-06-04 03:18:09 --> Helper loaded: url_helper
INFO - 2016-06-04 03:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:18:09 --> Controller Class Initialized
INFO - 2016-06-04 03:18:09 --> Helper loaded: language_helper
INFO - 2016-06-04 03:18:09 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:18:09 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:18:09 --> Final output sent to browser
DEBUG - 2016-06-04 03:18:09 --> Total execution time: 0.2100
INFO - 2016-06-04 03:18:11 --> Config Class Initialized
INFO - 2016-06-04 03:18:11 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:18:11 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:18:11 --> Utf8 Class Initialized
INFO - 2016-06-04 03:18:11 --> URI Class Initialized
INFO - 2016-06-04 03:18:11 --> Router Class Initialized
INFO - 2016-06-04 03:18:11 --> Output Class Initialized
INFO - 2016-06-04 03:18:11 --> Security Class Initialized
DEBUG - 2016-06-04 03:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:18:12 --> Input Class Initialized
INFO - 2016-06-04 03:18:12 --> Language Class Initialized
INFO - 2016-06-04 03:18:12 --> Loader Class Initialized
INFO - 2016-06-04 03:18:12 --> Helper loaded: url_helper
INFO - 2016-06-04 03:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:18:12 --> Controller Class Initialized
INFO - 2016-06-04 03:18:12 --> Helper loaded: language_helper
INFO - 2016-06-04 03:18:12 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:18:12 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:18:12 --> Final output sent to browser
DEBUG - 2016-06-04 03:18:12 --> Total execution time: 0.2130
INFO - 2016-06-04 03:18:12 --> Config Class Initialized
INFO - 2016-06-04 03:18:12 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:18:12 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:18:12 --> Utf8 Class Initialized
INFO - 2016-06-04 03:18:12 --> URI Class Initialized
INFO - 2016-06-04 03:18:12 --> Router Class Initialized
INFO - 2016-06-04 03:18:12 --> Output Class Initialized
INFO - 2016-06-04 03:18:12 --> Security Class Initialized
DEBUG - 2016-06-04 03:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:18:12 --> Input Class Initialized
INFO - 2016-06-04 03:18:12 --> Language Class Initialized
INFO - 2016-06-04 03:18:12 --> Loader Class Initialized
INFO - 2016-06-04 03:18:12 --> Helper loaded: url_helper
INFO - 2016-06-04 03:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:18:12 --> Controller Class Initialized
INFO - 2016-06-04 03:18:12 --> Helper loaded: language_helper
INFO - 2016-06-04 03:18:12 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:18:12 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 03:18:12 --> Final output sent to browser
DEBUG - 2016-06-04 03:18:12 --> Total execution time: 0.2010
INFO - 2016-06-04 03:18:13 --> Config Class Initialized
INFO - 2016-06-04 03:18:13 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:18:13 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:18:13 --> Utf8 Class Initialized
INFO - 2016-06-04 03:18:13 --> URI Class Initialized
INFO - 2016-06-04 03:18:13 --> Router Class Initialized
INFO - 2016-06-04 03:18:13 --> Output Class Initialized
INFO - 2016-06-04 03:18:13 --> Security Class Initialized
DEBUG - 2016-06-04 03:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:18:13 --> Input Class Initialized
INFO - 2016-06-04 03:18:13 --> Language Class Initialized
INFO - 2016-06-04 03:18:13 --> Loader Class Initialized
INFO - 2016-06-04 03:18:13 --> Helper loaded: url_helper
INFO - 2016-06-04 03:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:18:13 --> Controller Class Initialized
INFO - 2016-06-04 03:18:13 --> Helper loaded: language_helper
INFO - 2016-06-04 03:18:13 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:18:13 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\contact.php
INFO - 2016-06-04 03:18:13 --> Final output sent to browser
DEBUG - 2016-06-04 03:18:13 --> Total execution time: 0.2130
INFO - 2016-06-04 03:18:16 --> Config Class Initialized
INFO - 2016-06-04 03:18:16 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:18:16 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:18:16 --> Utf8 Class Initialized
INFO - 2016-06-04 03:18:16 --> URI Class Initialized
INFO - 2016-06-04 03:18:16 --> Router Class Initialized
INFO - 2016-06-04 03:18:16 --> Output Class Initialized
INFO - 2016-06-04 03:18:16 --> Security Class Initialized
DEBUG - 2016-06-04 03:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:18:16 --> Input Class Initialized
INFO - 2016-06-04 03:18:16 --> Language Class Initialized
INFO - 2016-06-04 03:18:16 --> Loader Class Initialized
INFO - 2016-06-04 03:18:16 --> Helper loaded: url_helper
INFO - 2016-06-04 03:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:18:16 --> Controller Class Initialized
INFO - 2016-06-04 03:18:16 --> Helper loaded: language_helper
INFO - 2016-06-04 03:18:16 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:18:16 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 03:18:16 --> Final output sent to browser
DEBUG - 2016-06-04 03:18:16 --> Total execution time: 0.2170
INFO - 2016-06-04 03:18:17 --> Config Class Initialized
INFO - 2016-06-04 03:18:17 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:18:17 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:18:17 --> Utf8 Class Initialized
INFO - 2016-06-04 03:18:17 --> URI Class Initialized
INFO - 2016-06-04 03:18:17 --> Router Class Initialized
INFO - 2016-06-04 03:18:17 --> Output Class Initialized
INFO - 2016-06-04 03:18:17 --> Security Class Initialized
DEBUG - 2016-06-04 03:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:18:17 --> Input Class Initialized
INFO - 2016-06-04 03:18:17 --> Language Class Initialized
INFO - 2016-06-04 03:18:17 --> Loader Class Initialized
INFO - 2016-06-04 03:18:17 --> Helper loaded: url_helper
INFO - 2016-06-04 03:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:18:17 --> Controller Class Initialized
INFO - 2016-06-04 03:18:17 --> Helper loaded: language_helper
INFO - 2016-06-04 03:18:17 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:18:17 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:18:17 --> Final output sent to browser
DEBUG - 2016-06-04 03:18:17 --> Total execution time: 0.2000
INFO - 2016-06-04 03:18:18 --> Config Class Initialized
INFO - 2016-06-04 03:18:18 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:18:18 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:18:18 --> Utf8 Class Initialized
INFO - 2016-06-04 03:18:18 --> URI Class Initialized
DEBUG - 2016-06-04 03:18:18 --> No URI present. Default controller set.
INFO - 2016-06-04 03:18:18 --> Router Class Initialized
INFO - 2016-06-04 03:18:18 --> Output Class Initialized
INFO - 2016-06-04 03:18:18 --> Security Class Initialized
DEBUG - 2016-06-04 03:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:18:18 --> Input Class Initialized
INFO - 2016-06-04 03:18:18 --> Language Class Initialized
INFO - 2016-06-04 03:18:18 --> Loader Class Initialized
INFO - 2016-06-04 03:18:18 --> Helper loaded: url_helper
INFO - 2016-06-04 03:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:18:18 --> Controller Class Initialized
INFO - 2016-06-04 03:18:18 --> Helper loaded: language_helper
INFO - 2016-06-04 03:18:18 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:18:18 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:18:18 --> Final output sent to browser
DEBUG - 2016-06-04 03:18:18 --> Total execution time: 0.2180
INFO - 2016-06-04 03:18:20 --> Config Class Initialized
INFO - 2016-06-04 03:18:20 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:18:20 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:18:20 --> Utf8 Class Initialized
INFO - 2016-06-04 03:18:20 --> URI Class Initialized
INFO - 2016-06-04 03:18:20 --> Router Class Initialized
INFO - 2016-06-04 03:18:20 --> Output Class Initialized
INFO - 2016-06-04 03:18:20 --> Security Class Initialized
DEBUG - 2016-06-04 03:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:18:20 --> Input Class Initialized
INFO - 2016-06-04 03:18:20 --> Language Class Initialized
INFO - 2016-06-04 03:18:20 --> Loader Class Initialized
INFO - 2016-06-04 03:18:20 --> Helper loaded: url_helper
INFO - 2016-06-04 03:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:18:20 --> Controller Class Initialized
INFO - 2016-06-04 03:18:20 --> Helper loaded: language_helper
INFO - 2016-06-04 03:18:20 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:18:20 --> Config Class Initialized
INFO - 2016-06-04 03:18:20 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:18:20 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:18:20 --> Utf8 Class Initialized
INFO - 2016-06-04 03:18:20 --> URI Class Initialized
DEBUG - 2016-06-04 03:18:20 --> No URI present. Default controller set.
INFO - 2016-06-04 03:18:20 --> Router Class Initialized
INFO - 2016-06-04 03:18:20 --> Output Class Initialized
INFO - 2016-06-04 03:18:20 --> Security Class Initialized
DEBUG - 2016-06-04 03:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:18:20 --> Input Class Initialized
INFO - 2016-06-04 03:18:20 --> Language Class Initialized
INFO - 2016-06-04 03:18:20 --> Loader Class Initialized
INFO - 2016-06-04 03:18:20 --> Helper loaded: url_helper
INFO - 2016-06-04 03:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:18:20 --> Controller Class Initialized
INFO - 2016-06-04 03:18:20 --> Helper loaded: language_helper
INFO - 2016-06-04 03:18:20 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:18:20 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:18:20 --> Final output sent to browser
DEBUG - 2016-06-04 03:18:20 --> Total execution time: 0.2090
INFO - 2016-06-04 03:18:22 --> Config Class Initialized
INFO - 2016-06-04 03:18:22 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:18:22 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:18:22 --> Utf8 Class Initialized
INFO - 2016-06-04 03:18:22 --> URI Class Initialized
INFO - 2016-06-04 03:18:22 --> Router Class Initialized
INFO - 2016-06-04 03:18:22 --> Output Class Initialized
INFO - 2016-06-04 03:18:22 --> Security Class Initialized
DEBUG - 2016-06-04 03:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:18:22 --> Input Class Initialized
INFO - 2016-06-04 03:18:22 --> Language Class Initialized
INFO - 2016-06-04 03:18:22 --> Loader Class Initialized
INFO - 2016-06-04 03:18:22 --> Helper loaded: url_helper
INFO - 2016-06-04 03:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:18:22 --> Controller Class Initialized
INFO - 2016-06-04 03:18:22 --> Helper loaded: language_helper
INFO - 2016-06-04 03:18:22 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:18:22 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 03:18:22 --> Final output sent to browser
DEBUG - 2016-06-04 03:18:22 --> Total execution time: 0.2020
INFO - 2016-06-04 03:18:23 --> Config Class Initialized
INFO - 2016-06-04 03:18:23 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:18:23 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:18:23 --> Utf8 Class Initialized
INFO - 2016-06-04 03:18:23 --> URI Class Initialized
INFO - 2016-06-04 03:18:23 --> Router Class Initialized
INFO - 2016-06-04 03:18:23 --> Output Class Initialized
INFO - 2016-06-04 03:18:23 --> Security Class Initialized
DEBUG - 2016-06-04 03:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:18:23 --> Input Class Initialized
INFO - 2016-06-04 03:18:23 --> Language Class Initialized
INFO - 2016-06-04 03:18:23 --> Loader Class Initialized
INFO - 2016-06-04 03:18:23 --> Helper loaded: url_helper
INFO - 2016-06-04 03:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:18:23 --> Controller Class Initialized
INFO - 2016-06-04 03:18:23 --> Helper loaded: language_helper
INFO - 2016-06-04 03:18:23 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:18:23 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:18:23 --> Final output sent to browser
DEBUG - 2016-06-04 03:18:23 --> Total execution time: 0.2300
INFO - 2016-06-04 03:18:23 --> Config Class Initialized
INFO - 2016-06-04 03:18:23 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:18:23 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:18:23 --> Utf8 Class Initialized
INFO - 2016-06-04 03:18:23 --> URI Class Initialized
INFO - 2016-06-04 03:18:23 --> Router Class Initialized
INFO - 2016-06-04 03:18:23 --> Output Class Initialized
INFO - 2016-06-04 03:18:23 --> Security Class Initialized
DEBUG - 2016-06-04 03:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:18:23 --> Input Class Initialized
INFO - 2016-06-04 03:18:24 --> Language Class Initialized
INFO - 2016-06-04 03:18:24 --> Loader Class Initialized
INFO - 2016-06-04 03:18:24 --> Helper loaded: url_helper
INFO - 2016-06-04 03:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:18:24 --> Controller Class Initialized
INFO - 2016-06-04 03:18:24 --> Helper loaded: language_helper
INFO - 2016-06-04 03:18:24 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:18:24 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 03:18:24 --> Final output sent to browser
DEBUG - 2016-06-04 03:18:24 --> Total execution time: 0.2120
INFO - 2016-06-04 03:18:24 --> Config Class Initialized
INFO - 2016-06-04 03:18:24 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:18:24 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:18:24 --> Utf8 Class Initialized
INFO - 2016-06-04 03:18:24 --> URI Class Initialized
INFO - 2016-06-04 03:18:24 --> Router Class Initialized
INFO - 2016-06-04 03:18:24 --> Output Class Initialized
INFO - 2016-06-04 03:18:24 --> Security Class Initialized
DEBUG - 2016-06-04 03:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:18:24 --> Input Class Initialized
INFO - 2016-06-04 03:18:24 --> Language Class Initialized
INFO - 2016-06-04 03:18:24 --> Loader Class Initialized
INFO - 2016-06-04 03:18:24 --> Helper loaded: url_helper
INFO - 2016-06-04 03:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:18:24 --> Controller Class Initialized
INFO - 2016-06-04 03:18:24 --> Helper loaded: language_helper
INFO - 2016-06-04 03:18:24 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:18:24 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\contact.php
INFO - 2016-06-04 03:18:24 --> Final output sent to browser
DEBUG - 2016-06-04 03:18:24 --> Total execution time: 0.2070
INFO - 2016-06-04 03:18:27 --> Config Class Initialized
INFO - 2016-06-04 03:18:27 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:18:27 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:18:27 --> Utf8 Class Initialized
INFO - 2016-06-04 03:18:27 --> URI Class Initialized
INFO - 2016-06-04 03:18:27 --> Router Class Initialized
INFO - 2016-06-04 03:18:27 --> Output Class Initialized
INFO - 2016-06-04 03:18:27 --> Security Class Initialized
DEBUG - 2016-06-04 03:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:18:27 --> Input Class Initialized
INFO - 2016-06-04 03:18:27 --> Language Class Initialized
INFO - 2016-06-04 03:18:27 --> Loader Class Initialized
INFO - 2016-06-04 03:18:27 --> Helper loaded: url_helper
INFO - 2016-06-04 03:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:18:27 --> Controller Class Initialized
INFO - 2016-06-04 03:18:27 --> Helper loaded: language_helper
INFO - 2016-06-04 03:18:27 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:18:27 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:18:27 --> Final output sent to browser
DEBUG - 2016-06-04 03:18:27 --> Total execution time: 0.2160
INFO - 2016-06-04 03:18:28 --> Config Class Initialized
INFO - 2016-06-04 03:18:28 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:18:28 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:18:28 --> Utf8 Class Initialized
INFO - 2016-06-04 03:18:28 --> URI Class Initialized
DEBUG - 2016-06-04 03:18:28 --> No URI present. Default controller set.
INFO - 2016-06-04 03:18:28 --> Router Class Initialized
INFO - 2016-06-04 03:18:28 --> Output Class Initialized
INFO - 2016-06-04 03:18:28 --> Security Class Initialized
DEBUG - 2016-06-04 03:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:18:28 --> Input Class Initialized
INFO - 2016-06-04 03:18:28 --> Language Class Initialized
INFO - 2016-06-04 03:18:28 --> Loader Class Initialized
INFO - 2016-06-04 03:18:28 --> Helper loaded: url_helper
INFO - 2016-06-04 03:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:18:28 --> Controller Class Initialized
INFO - 2016-06-04 03:18:28 --> Helper loaded: language_helper
INFO - 2016-06-04 03:18:28 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:18:28 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:18:28 --> Final output sent to browser
DEBUG - 2016-06-04 03:18:28 --> Total execution time: 0.2260
INFO - 2016-06-04 03:18:30 --> Config Class Initialized
INFO - 2016-06-04 03:18:30 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:18:30 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:18:30 --> Utf8 Class Initialized
INFO - 2016-06-04 03:18:30 --> URI Class Initialized
INFO - 2016-06-04 03:18:30 --> Router Class Initialized
INFO - 2016-06-04 03:18:30 --> Output Class Initialized
INFO - 2016-06-04 03:18:30 --> Security Class Initialized
DEBUG - 2016-06-04 03:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:18:30 --> Input Class Initialized
INFO - 2016-06-04 03:18:30 --> Language Class Initialized
INFO - 2016-06-04 03:18:30 --> Loader Class Initialized
INFO - 2016-06-04 03:18:30 --> Helper loaded: url_helper
INFO - 2016-06-04 03:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:18:30 --> Controller Class Initialized
INFO - 2016-06-04 03:18:30 --> Helper loaded: language_helper
INFO - 2016-06-04 03:18:30 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:18:30 --> Config Class Initialized
INFO - 2016-06-04 03:18:30 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:18:30 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:18:30 --> Utf8 Class Initialized
INFO - 2016-06-04 03:18:30 --> URI Class Initialized
DEBUG - 2016-06-04 03:18:30 --> No URI present. Default controller set.
INFO - 2016-06-04 03:18:30 --> Router Class Initialized
INFO - 2016-06-04 03:18:30 --> Output Class Initialized
INFO - 2016-06-04 03:18:30 --> Security Class Initialized
DEBUG - 2016-06-04 03:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:18:30 --> Input Class Initialized
INFO - 2016-06-04 03:18:30 --> Language Class Initialized
INFO - 2016-06-04 03:18:30 --> Loader Class Initialized
INFO - 2016-06-04 03:18:30 --> Helper loaded: url_helper
INFO - 2016-06-04 03:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:18:30 --> Controller Class Initialized
INFO - 2016-06-04 03:18:30 --> Helper loaded: language_helper
INFO - 2016-06-04 03:18:30 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:18:30 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:18:30 --> Final output sent to browser
DEBUG - 2016-06-04 03:18:30 --> Total execution time: 0.2200
INFO - 2016-06-04 03:18:31 --> Config Class Initialized
INFO - 2016-06-04 03:18:31 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:18:31 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:18:32 --> Utf8 Class Initialized
INFO - 2016-06-04 03:18:32 --> URI Class Initialized
INFO - 2016-06-04 03:18:32 --> Router Class Initialized
INFO - 2016-06-04 03:18:32 --> Output Class Initialized
INFO - 2016-06-04 03:18:32 --> Security Class Initialized
DEBUG - 2016-06-04 03:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:18:32 --> Input Class Initialized
INFO - 2016-06-04 03:18:32 --> Language Class Initialized
INFO - 2016-06-04 03:18:32 --> Loader Class Initialized
INFO - 2016-06-04 03:18:32 --> Helper loaded: url_helper
INFO - 2016-06-04 03:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:18:32 --> Controller Class Initialized
INFO - 2016-06-04 03:18:32 --> Helper loaded: language_helper
INFO - 2016-06-04 03:18:32 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:18:32 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\contact.php
INFO - 2016-06-04 03:18:32 --> Final output sent to browser
DEBUG - 2016-06-04 03:18:32 --> Total execution time: 0.2300
INFO - 2016-06-04 03:18:32 --> Config Class Initialized
INFO - 2016-06-04 03:18:32 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:18:32 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:18:32 --> Utf8 Class Initialized
INFO - 2016-06-04 03:18:32 --> URI Class Initialized
INFO - 2016-06-04 03:18:32 --> Router Class Initialized
INFO - 2016-06-04 03:18:32 --> Output Class Initialized
INFO - 2016-06-04 03:18:32 --> Security Class Initialized
DEBUG - 2016-06-04 03:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:18:32 --> Input Class Initialized
INFO - 2016-06-04 03:18:32 --> Language Class Initialized
INFO - 2016-06-04 03:18:32 --> Loader Class Initialized
INFO - 2016-06-04 03:18:32 --> Helper loaded: url_helper
INFO - 2016-06-04 03:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:18:32 --> Controller Class Initialized
INFO - 2016-06-04 03:18:32 --> Helper loaded: language_helper
INFO - 2016-06-04 03:18:32 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:18:32 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 03:18:32 --> Final output sent to browser
DEBUG - 2016-06-04 03:18:32 --> Total execution time: 0.2160
INFO - 2016-06-04 03:18:33 --> Config Class Initialized
INFO - 2016-06-04 03:18:33 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:18:33 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:18:33 --> Utf8 Class Initialized
INFO - 2016-06-04 03:18:33 --> URI Class Initialized
INFO - 2016-06-04 03:18:33 --> Router Class Initialized
INFO - 2016-06-04 03:18:33 --> Output Class Initialized
INFO - 2016-06-04 03:18:33 --> Security Class Initialized
DEBUG - 2016-06-04 03:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:18:33 --> Input Class Initialized
INFO - 2016-06-04 03:18:33 --> Language Class Initialized
INFO - 2016-06-04 03:18:33 --> Loader Class Initialized
INFO - 2016-06-04 03:18:33 --> Helper loaded: url_helper
INFO - 2016-06-04 03:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:18:33 --> Controller Class Initialized
INFO - 2016-06-04 03:18:33 --> Helper loaded: language_helper
INFO - 2016-06-04 03:18:33 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:18:33 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:18:33 --> Final output sent to browser
DEBUG - 2016-06-04 03:18:33 --> Total execution time: 0.1970
INFO - 2016-06-04 03:18:34 --> Config Class Initialized
INFO - 2016-06-04 03:18:34 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:18:34 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:18:34 --> Utf8 Class Initialized
INFO - 2016-06-04 03:18:34 --> URI Class Initialized
DEBUG - 2016-06-04 03:18:34 --> No URI present. Default controller set.
INFO - 2016-06-04 03:18:34 --> Router Class Initialized
INFO - 2016-06-04 03:18:34 --> Output Class Initialized
INFO - 2016-06-04 03:18:34 --> Security Class Initialized
DEBUG - 2016-06-04 03:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:18:34 --> Input Class Initialized
INFO - 2016-06-04 03:18:34 --> Language Class Initialized
INFO - 2016-06-04 03:18:34 --> Loader Class Initialized
INFO - 2016-06-04 03:18:34 --> Helper loaded: url_helper
INFO - 2016-06-04 03:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:18:34 --> Controller Class Initialized
INFO - 2016-06-04 03:18:34 --> Helper loaded: language_helper
INFO - 2016-06-04 03:18:34 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:18:34 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:18:34 --> Final output sent to browser
DEBUG - 2016-06-04 03:18:34 --> Total execution time: 0.2100
INFO - 2016-06-04 03:18:39 --> Config Class Initialized
INFO - 2016-06-04 03:18:39 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:18:39 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:18:40 --> Utf8 Class Initialized
INFO - 2016-06-04 03:18:40 --> URI Class Initialized
INFO - 2016-06-04 03:18:40 --> Router Class Initialized
INFO - 2016-06-04 03:18:40 --> Output Class Initialized
INFO - 2016-06-04 03:18:40 --> Security Class Initialized
DEBUG - 2016-06-04 03:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:18:40 --> Input Class Initialized
INFO - 2016-06-04 03:18:40 --> Language Class Initialized
INFO - 2016-06-04 03:18:40 --> Loader Class Initialized
INFO - 2016-06-04 03:18:40 --> Helper loaded: url_helper
INFO - 2016-06-04 03:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:18:40 --> Controller Class Initialized
INFO - 2016-06-04 03:18:40 --> Helper loaded: language_helper
INFO - 2016-06-04 03:18:40 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:18:40 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 03:18:40 --> Final output sent to browser
DEBUG - 2016-06-04 03:18:40 --> Total execution time: 0.2200
INFO - 2016-06-04 03:18:40 --> Config Class Initialized
INFO - 2016-06-04 03:18:40 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:18:40 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:18:40 --> Utf8 Class Initialized
INFO - 2016-06-04 03:18:40 --> URI Class Initialized
INFO - 2016-06-04 03:18:40 --> Router Class Initialized
INFO - 2016-06-04 03:18:40 --> Output Class Initialized
INFO - 2016-06-04 03:18:40 --> Security Class Initialized
DEBUG - 2016-06-04 03:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:18:40 --> Input Class Initialized
INFO - 2016-06-04 03:18:40 --> Language Class Initialized
INFO - 2016-06-04 03:18:40 --> Loader Class Initialized
INFO - 2016-06-04 03:18:40 --> Helper loaded: url_helper
INFO - 2016-06-04 03:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:18:40 --> Controller Class Initialized
INFO - 2016-06-04 03:18:40 --> Helper loaded: language_helper
INFO - 2016-06-04 03:18:40 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:18:40 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:18:40 --> Final output sent to browser
DEBUG - 2016-06-04 03:18:40 --> Total execution time: 0.2070
INFO - 2016-06-04 03:23:00 --> Config Class Initialized
INFO - 2016-06-04 03:23:00 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:23:00 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:23:00 --> Utf8 Class Initialized
INFO - 2016-06-04 03:23:00 --> URI Class Initialized
INFO - 2016-06-04 03:23:00 --> Router Class Initialized
INFO - 2016-06-04 03:23:00 --> Output Class Initialized
INFO - 2016-06-04 03:23:00 --> Security Class Initialized
DEBUG - 2016-06-04 03:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:23:00 --> Input Class Initialized
INFO - 2016-06-04 03:23:00 --> Language Class Initialized
INFO - 2016-06-04 03:23:00 --> Loader Class Initialized
INFO - 2016-06-04 03:23:00 --> Helper loaded: url_helper
INFO - 2016-06-04 03:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:23:00 --> Controller Class Initialized
INFO - 2016-06-04 03:23:00 --> Helper loaded: language_helper
INFO - 2016-06-04 03:23:00 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:23:00 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:23:00 --> Final output sent to browser
DEBUG - 2016-06-04 03:23:00 --> Total execution time: 0.2040
INFO - 2016-06-04 03:23:29 --> Config Class Initialized
INFO - 2016-06-04 03:23:29 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:23:29 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:23:29 --> Utf8 Class Initialized
INFO - 2016-06-04 03:23:29 --> URI Class Initialized
INFO - 2016-06-04 03:23:29 --> Router Class Initialized
INFO - 2016-06-04 03:23:29 --> Output Class Initialized
INFO - 2016-06-04 03:23:29 --> Security Class Initialized
DEBUG - 2016-06-04 03:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:23:29 --> Input Class Initialized
INFO - 2016-06-04 03:23:29 --> Language Class Initialized
INFO - 2016-06-04 03:23:29 --> Loader Class Initialized
INFO - 2016-06-04 03:23:29 --> Helper loaded: url_helper
INFO - 2016-06-04 03:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:23:29 --> Controller Class Initialized
INFO - 2016-06-04 03:23:29 --> Helper loaded: language_helper
INFO - 2016-06-04 03:23:29 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:23:29 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:23:29 --> Final output sent to browser
DEBUG - 2016-06-04 03:23:29 --> Total execution time: 0.2080
INFO - 2016-06-04 03:23:31 --> Config Class Initialized
INFO - 2016-06-04 03:23:31 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:23:31 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:23:31 --> Utf8 Class Initialized
INFO - 2016-06-04 03:23:31 --> URI Class Initialized
INFO - 2016-06-04 03:23:31 --> Router Class Initialized
INFO - 2016-06-04 03:23:31 --> Output Class Initialized
INFO - 2016-06-04 03:23:31 --> Security Class Initialized
DEBUG - 2016-06-04 03:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:23:31 --> Input Class Initialized
INFO - 2016-06-04 03:23:31 --> Language Class Initialized
INFO - 2016-06-04 03:23:31 --> Loader Class Initialized
INFO - 2016-06-04 03:23:31 --> Helper loaded: url_helper
INFO - 2016-06-04 03:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:23:31 --> Controller Class Initialized
INFO - 2016-06-04 03:23:31 --> Helper loaded: language_helper
INFO - 2016-06-04 03:23:31 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:23:31 --> Config Class Initialized
INFO - 2016-06-04 03:23:31 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:23:31 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:23:31 --> Utf8 Class Initialized
INFO - 2016-06-04 03:23:31 --> URI Class Initialized
INFO - 2016-06-04 03:23:31 --> Router Class Initialized
INFO - 2016-06-04 03:23:31 --> Output Class Initialized
INFO - 2016-06-04 03:23:31 --> Security Class Initialized
DEBUG - 2016-06-04 03:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:23:31 --> Input Class Initialized
INFO - 2016-06-04 03:23:31 --> Language Class Initialized
INFO - 2016-06-04 03:23:31 --> Loader Class Initialized
INFO - 2016-06-04 03:23:31 --> Helper loaded: url_helper
INFO - 2016-06-04 03:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:23:31 --> Controller Class Initialized
INFO - 2016-06-04 03:23:31 --> Helper loaded: language_helper
INFO - 2016-06-04 03:23:31 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:23:31 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:23:31 --> Final output sent to browser
DEBUG - 2016-06-04 03:23:31 --> Total execution time: 0.2080
INFO - 2016-06-04 03:23:33 --> Config Class Initialized
INFO - 2016-06-04 03:23:33 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:23:33 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:23:33 --> Utf8 Class Initialized
INFO - 2016-06-04 03:23:33 --> URI Class Initialized
INFO - 2016-06-04 03:23:33 --> Router Class Initialized
INFO - 2016-06-04 03:23:33 --> Output Class Initialized
INFO - 2016-06-04 03:23:33 --> Security Class Initialized
DEBUG - 2016-06-04 03:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:23:34 --> Input Class Initialized
INFO - 2016-06-04 03:23:34 --> Language Class Initialized
INFO - 2016-06-04 03:23:34 --> Loader Class Initialized
INFO - 2016-06-04 03:23:34 --> Helper loaded: url_helper
INFO - 2016-06-04 03:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:23:34 --> Controller Class Initialized
INFO - 2016-06-04 03:23:34 --> Helper loaded: language_helper
INFO - 2016-06-04 03:23:34 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:23:34 --> Config Class Initialized
INFO - 2016-06-04 03:23:34 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:23:34 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:23:34 --> Utf8 Class Initialized
INFO - 2016-06-04 03:23:34 --> URI Class Initialized
INFO - 2016-06-04 03:23:34 --> Router Class Initialized
INFO - 2016-06-04 03:23:34 --> Output Class Initialized
INFO - 2016-06-04 03:23:34 --> Security Class Initialized
DEBUG - 2016-06-04 03:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:23:34 --> Input Class Initialized
INFO - 2016-06-04 03:23:34 --> Language Class Initialized
INFO - 2016-06-04 03:23:34 --> Loader Class Initialized
INFO - 2016-06-04 03:23:34 --> Helper loaded: url_helper
INFO - 2016-06-04 03:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:23:34 --> Controller Class Initialized
INFO - 2016-06-04 03:23:34 --> Helper loaded: language_helper
INFO - 2016-06-04 03:23:34 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:23:34 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:23:34 --> Final output sent to browser
DEBUG - 2016-06-04 03:23:34 --> Total execution time: 0.2000
INFO - 2016-06-04 03:23:35 --> Config Class Initialized
INFO - 2016-06-04 03:23:35 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:23:35 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:23:35 --> Utf8 Class Initialized
INFO - 2016-06-04 03:23:35 --> URI Class Initialized
INFO - 2016-06-04 03:23:35 --> Router Class Initialized
INFO - 2016-06-04 03:23:35 --> Output Class Initialized
INFO - 2016-06-04 03:23:35 --> Security Class Initialized
DEBUG - 2016-06-04 03:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:23:35 --> Input Class Initialized
INFO - 2016-06-04 03:23:35 --> Language Class Initialized
INFO - 2016-06-04 03:23:35 --> Loader Class Initialized
INFO - 2016-06-04 03:23:35 --> Helper loaded: url_helper
INFO - 2016-06-04 03:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:23:35 --> Controller Class Initialized
INFO - 2016-06-04 03:23:35 --> Helper loaded: language_helper
INFO - 2016-06-04 03:23:35 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:23:35 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 03:23:35 --> Final output sent to browser
DEBUG - 2016-06-04 03:23:35 --> Total execution time: 0.2020
INFO - 2016-06-04 03:23:36 --> Config Class Initialized
INFO - 2016-06-04 03:23:36 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:23:36 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:23:36 --> Utf8 Class Initialized
INFO - 2016-06-04 03:23:36 --> URI Class Initialized
INFO - 2016-06-04 03:23:36 --> Router Class Initialized
INFO - 2016-06-04 03:23:36 --> Output Class Initialized
INFO - 2016-06-04 03:23:36 --> Security Class Initialized
DEBUG - 2016-06-04 03:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:23:36 --> Input Class Initialized
INFO - 2016-06-04 03:23:36 --> Language Class Initialized
INFO - 2016-06-04 03:23:36 --> Loader Class Initialized
INFO - 2016-06-04 03:23:36 --> Helper loaded: url_helper
INFO - 2016-06-04 03:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:23:36 --> Controller Class Initialized
INFO - 2016-06-04 03:23:36 --> Helper loaded: language_helper
INFO - 2016-06-04 03:23:36 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:23:36 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\contact.php
INFO - 2016-06-04 03:23:36 --> Final output sent to browser
DEBUG - 2016-06-04 03:23:36 --> Total execution time: 0.2090
INFO - 2016-06-04 03:23:37 --> Config Class Initialized
INFO - 2016-06-04 03:23:37 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:23:37 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:23:37 --> Utf8 Class Initialized
INFO - 2016-06-04 03:23:37 --> URI Class Initialized
INFO - 2016-06-04 03:23:37 --> Router Class Initialized
INFO - 2016-06-04 03:23:37 --> Output Class Initialized
INFO - 2016-06-04 03:23:37 --> Security Class Initialized
DEBUG - 2016-06-04 03:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:23:37 --> Input Class Initialized
INFO - 2016-06-04 03:23:37 --> Language Class Initialized
INFO - 2016-06-04 03:23:37 --> Loader Class Initialized
INFO - 2016-06-04 03:23:37 --> Helper loaded: url_helper
INFO - 2016-06-04 03:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:23:37 --> Controller Class Initialized
INFO - 2016-06-04 03:23:37 --> Helper loaded: language_helper
INFO - 2016-06-04 03:23:37 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:23:37 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:23:37 --> Final output sent to browser
DEBUG - 2016-06-04 03:23:37 --> Total execution time: 0.2200
INFO - 2016-06-04 03:23:37 --> Config Class Initialized
INFO - 2016-06-04 03:23:37 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:23:37 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:23:38 --> Utf8 Class Initialized
INFO - 2016-06-04 03:23:38 --> URI Class Initialized
DEBUG - 2016-06-04 03:23:38 --> No URI present. Default controller set.
INFO - 2016-06-04 03:23:38 --> Router Class Initialized
INFO - 2016-06-04 03:23:38 --> Output Class Initialized
INFO - 2016-06-04 03:23:38 --> Security Class Initialized
DEBUG - 2016-06-04 03:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:23:38 --> Input Class Initialized
INFO - 2016-06-04 03:23:38 --> Language Class Initialized
INFO - 2016-06-04 03:23:38 --> Loader Class Initialized
INFO - 2016-06-04 03:23:38 --> Helper loaded: url_helper
INFO - 2016-06-04 03:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:23:38 --> Controller Class Initialized
INFO - 2016-06-04 03:23:38 --> Helper loaded: language_helper
INFO - 2016-06-04 03:23:38 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:23:38 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:23:38 --> Final output sent to browser
DEBUG - 2016-06-04 03:23:38 --> Total execution time: 0.2300
INFO - 2016-06-04 03:23:42 --> Config Class Initialized
INFO - 2016-06-04 03:23:42 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:23:42 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:23:42 --> Utf8 Class Initialized
INFO - 2016-06-04 03:23:42 --> URI Class Initialized
INFO - 2016-06-04 03:23:42 --> Router Class Initialized
INFO - 2016-06-04 03:23:42 --> Output Class Initialized
INFO - 2016-06-04 03:23:42 --> Security Class Initialized
DEBUG - 2016-06-04 03:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:23:42 --> Input Class Initialized
INFO - 2016-06-04 03:23:42 --> Language Class Initialized
INFO - 2016-06-04 03:23:42 --> Loader Class Initialized
INFO - 2016-06-04 03:23:42 --> Helper loaded: url_helper
INFO - 2016-06-04 03:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:23:42 --> Controller Class Initialized
INFO - 2016-06-04 03:23:42 --> Helper loaded: language_helper
INFO - 2016-06-04 03:23:42 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:23:42 --> Config Class Initialized
INFO - 2016-06-04 03:23:42 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:23:42 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:23:42 --> Utf8 Class Initialized
INFO - 2016-06-04 03:23:42 --> URI Class Initialized
DEBUG - 2016-06-04 03:23:42 --> No URI present. Default controller set.
INFO - 2016-06-04 03:23:42 --> Router Class Initialized
INFO - 2016-06-04 03:23:42 --> Output Class Initialized
INFO - 2016-06-04 03:23:42 --> Security Class Initialized
DEBUG - 2016-06-04 03:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:23:42 --> Input Class Initialized
INFO - 2016-06-04 03:23:42 --> Language Class Initialized
INFO - 2016-06-04 03:23:42 --> Loader Class Initialized
INFO - 2016-06-04 03:23:42 --> Helper loaded: url_helper
INFO - 2016-06-04 03:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:23:42 --> Controller Class Initialized
INFO - 2016-06-04 03:23:42 --> Helper loaded: language_helper
INFO - 2016-06-04 03:23:42 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:23:42 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:23:42 --> Final output sent to browser
DEBUG - 2016-06-04 03:23:43 --> Total execution time: 0.2100
INFO - 2016-06-04 03:23:48 --> Config Class Initialized
INFO - 2016-06-04 03:23:48 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:23:48 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:23:48 --> Utf8 Class Initialized
INFO - 2016-06-04 03:23:49 --> URI Class Initialized
INFO - 2016-06-04 03:23:49 --> Router Class Initialized
INFO - 2016-06-04 03:23:49 --> Output Class Initialized
INFO - 2016-06-04 03:23:49 --> Security Class Initialized
DEBUG - 2016-06-04 03:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:23:49 --> Input Class Initialized
INFO - 2016-06-04 03:23:49 --> Language Class Initialized
INFO - 2016-06-04 03:23:49 --> Loader Class Initialized
INFO - 2016-06-04 03:23:49 --> Helper loaded: url_helper
INFO - 2016-06-04 03:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:23:49 --> Controller Class Initialized
INFO - 2016-06-04 03:23:49 --> Helper loaded: language_helper
INFO - 2016-06-04 03:23:49 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:23:49 --> Config Class Initialized
INFO - 2016-06-04 03:23:49 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:23:49 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:23:49 --> Utf8 Class Initialized
INFO - 2016-06-04 03:23:49 --> URI Class Initialized
DEBUG - 2016-06-04 03:23:49 --> No URI present. Default controller set.
INFO - 2016-06-04 03:23:49 --> Router Class Initialized
INFO - 2016-06-04 03:23:49 --> Output Class Initialized
INFO - 2016-06-04 03:23:49 --> Security Class Initialized
DEBUG - 2016-06-04 03:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:23:49 --> Input Class Initialized
INFO - 2016-06-04 03:23:49 --> Language Class Initialized
INFO - 2016-06-04 03:23:49 --> Loader Class Initialized
INFO - 2016-06-04 03:23:49 --> Helper loaded: url_helper
INFO - 2016-06-04 03:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:23:49 --> Controller Class Initialized
INFO - 2016-06-04 03:23:49 --> Helper loaded: language_helper
INFO - 2016-06-04 03:23:49 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:23:49 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:23:49 --> Final output sent to browser
DEBUG - 2016-06-04 03:23:49 --> Total execution time: 0.2100
INFO - 2016-06-04 03:23:51 --> Config Class Initialized
INFO - 2016-06-04 03:23:51 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:23:51 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:23:51 --> Utf8 Class Initialized
INFO - 2016-06-04 03:23:51 --> URI Class Initialized
INFO - 2016-06-04 03:23:51 --> Router Class Initialized
INFO - 2016-06-04 03:23:51 --> Output Class Initialized
INFO - 2016-06-04 03:23:51 --> Security Class Initialized
DEBUG - 2016-06-04 03:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:23:51 --> Input Class Initialized
INFO - 2016-06-04 03:23:51 --> Language Class Initialized
INFO - 2016-06-04 03:23:51 --> Loader Class Initialized
INFO - 2016-06-04 03:23:51 --> Helper loaded: url_helper
INFO - 2016-06-04 03:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:23:51 --> Controller Class Initialized
INFO - 2016-06-04 03:23:51 --> Helper loaded: language_helper
INFO - 2016-06-04 03:23:51 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:23:51 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 03:23:51 --> Final output sent to browser
DEBUG - 2016-06-04 03:23:51 --> Total execution time: 0.2300
INFO - 2016-06-04 03:23:52 --> Config Class Initialized
INFO - 2016-06-04 03:23:52 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:23:52 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:23:52 --> Utf8 Class Initialized
INFO - 2016-06-04 03:23:52 --> URI Class Initialized
INFO - 2016-06-04 03:23:52 --> Router Class Initialized
INFO - 2016-06-04 03:23:52 --> Output Class Initialized
INFO - 2016-06-04 03:23:52 --> Security Class Initialized
DEBUG - 2016-06-04 03:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:23:52 --> Input Class Initialized
INFO - 2016-06-04 03:23:52 --> Language Class Initialized
INFO - 2016-06-04 03:23:52 --> Loader Class Initialized
INFO - 2016-06-04 03:23:52 --> Helper loaded: url_helper
INFO - 2016-06-04 03:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:23:52 --> Controller Class Initialized
INFO - 2016-06-04 03:23:52 --> Helper loaded: language_helper
INFO - 2016-06-04 03:23:52 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:23:52 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\contact.php
INFO - 2016-06-04 03:23:52 --> Final output sent to browser
DEBUG - 2016-06-04 03:23:52 --> Total execution time: 0.2200
INFO - 2016-06-04 03:23:53 --> Config Class Initialized
INFO - 2016-06-04 03:23:53 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:23:53 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:23:53 --> Utf8 Class Initialized
INFO - 2016-06-04 03:23:53 --> URI Class Initialized
INFO - 2016-06-04 03:23:53 --> Router Class Initialized
INFO - 2016-06-04 03:23:53 --> Output Class Initialized
INFO - 2016-06-04 03:23:53 --> Security Class Initialized
DEBUG - 2016-06-04 03:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:23:53 --> Input Class Initialized
INFO - 2016-06-04 03:23:53 --> Language Class Initialized
INFO - 2016-06-04 03:23:53 --> Loader Class Initialized
INFO - 2016-06-04 03:23:53 --> Helper loaded: url_helper
INFO - 2016-06-04 03:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:23:53 --> Controller Class Initialized
INFO - 2016-06-04 03:23:53 --> Helper loaded: language_helper
INFO - 2016-06-04 03:23:53 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:23:53 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 03:23:53 --> Final output sent to browser
DEBUG - 2016-06-04 03:23:53 --> Total execution time: 0.2100
INFO - 2016-06-04 03:23:54 --> Config Class Initialized
INFO - 2016-06-04 03:23:54 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:23:54 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:23:54 --> Utf8 Class Initialized
INFO - 2016-06-04 03:23:54 --> URI Class Initialized
INFO - 2016-06-04 03:23:54 --> Router Class Initialized
INFO - 2016-06-04 03:23:54 --> Output Class Initialized
INFO - 2016-06-04 03:23:54 --> Security Class Initialized
DEBUG - 2016-06-04 03:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:23:54 --> Input Class Initialized
INFO - 2016-06-04 03:23:54 --> Language Class Initialized
INFO - 2016-06-04 03:23:54 --> Loader Class Initialized
INFO - 2016-06-04 03:23:54 --> Helper loaded: url_helper
INFO - 2016-06-04 03:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:23:54 --> Controller Class Initialized
INFO - 2016-06-04 03:23:54 --> Helper loaded: language_helper
INFO - 2016-06-04 03:23:54 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:23:54 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:23:54 --> Final output sent to browser
DEBUG - 2016-06-04 03:23:54 --> Total execution time: 0.2100
INFO - 2016-06-04 03:24:26 --> Config Class Initialized
INFO - 2016-06-04 03:24:26 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:24:26 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:24:26 --> Utf8 Class Initialized
INFO - 2016-06-04 03:24:26 --> URI Class Initialized
DEBUG - 2016-06-04 03:24:26 --> No URI present. Default controller set.
INFO - 2016-06-04 03:24:26 --> Router Class Initialized
INFO - 2016-06-04 03:24:26 --> Output Class Initialized
INFO - 2016-06-04 03:24:26 --> Security Class Initialized
DEBUG - 2016-06-04 03:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:24:26 --> Input Class Initialized
INFO - 2016-06-04 03:24:26 --> Language Class Initialized
INFO - 2016-06-04 03:24:26 --> Loader Class Initialized
INFO - 2016-06-04 03:24:26 --> Helper loaded: url_helper
INFO - 2016-06-04 03:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:24:26 --> Controller Class Initialized
INFO - 2016-06-04 03:24:26 --> Helper loaded: language_helper
INFO - 2016-06-04 03:24:26 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:24:26 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:24:26 --> Final output sent to browser
DEBUG - 2016-06-04 03:24:26 --> Total execution time: 0.2420
INFO - 2016-06-04 03:24:28 --> Config Class Initialized
INFO - 2016-06-04 03:24:28 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:24:28 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:24:28 --> Utf8 Class Initialized
INFO - 2016-06-04 03:24:28 --> URI Class Initialized
DEBUG - 2016-06-04 03:24:28 --> No URI present. Default controller set.
INFO - 2016-06-04 03:24:28 --> Router Class Initialized
INFO - 2016-06-04 03:24:28 --> Output Class Initialized
INFO - 2016-06-04 03:24:28 --> Security Class Initialized
DEBUG - 2016-06-04 03:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:24:28 --> Input Class Initialized
INFO - 2016-06-04 03:24:28 --> Language Class Initialized
INFO - 2016-06-04 03:24:28 --> Loader Class Initialized
INFO - 2016-06-04 03:24:28 --> Helper loaded: url_helper
INFO - 2016-06-04 03:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:24:28 --> Controller Class Initialized
INFO - 2016-06-04 03:24:28 --> Helper loaded: language_helper
INFO - 2016-06-04 03:24:28 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:24:28 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:24:28 --> Final output sent to browser
DEBUG - 2016-06-04 03:24:28 --> Total execution time: 0.2210
INFO - 2016-06-04 03:25:06 --> Config Class Initialized
INFO - 2016-06-04 03:25:06 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:25:06 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:25:06 --> Utf8 Class Initialized
INFO - 2016-06-04 03:25:06 --> URI Class Initialized
DEBUG - 2016-06-04 03:25:06 --> No URI present. Default controller set.
INFO - 2016-06-04 03:25:06 --> Router Class Initialized
INFO - 2016-06-04 03:25:07 --> Output Class Initialized
INFO - 2016-06-04 03:25:07 --> Security Class Initialized
DEBUG - 2016-06-04 03:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:25:07 --> Input Class Initialized
INFO - 2016-06-04 03:25:07 --> Language Class Initialized
INFO - 2016-06-04 03:25:07 --> Loader Class Initialized
INFO - 2016-06-04 03:25:07 --> Helper loaded: url_helper
INFO - 2016-06-04 03:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:25:07 --> Controller Class Initialized
INFO - 2016-06-04 03:25:07 --> Helper loaded: language_helper
INFO - 2016-06-04 03:25:07 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:25:07 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:25:07 --> Final output sent to browser
DEBUG - 2016-06-04 03:25:07 --> Total execution time: 0.2300
INFO - 2016-06-04 03:25:08 --> Config Class Initialized
INFO - 2016-06-04 03:25:08 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:25:08 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:25:08 --> Utf8 Class Initialized
INFO - 2016-06-04 03:25:08 --> URI Class Initialized
INFO - 2016-06-04 03:25:08 --> Router Class Initialized
INFO - 2016-06-04 03:25:08 --> Output Class Initialized
INFO - 2016-06-04 03:25:08 --> Security Class Initialized
DEBUG - 2016-06-04 03:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:25:08 --> Input Class Initialized
INFO - 2016-06-04 03:25:08 --> Language Class Initialized
INFO - 2016-06-04 03:25:08 --> Loader Class Initialized
INFO - 2016-06-04 03:25:08 --> Helper loaded: url_helper
INFO - 2016-06-04 03:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:25:08 --> Controller Class Initialized
INFO - 2016-06-04 03:25:08 --> Helper loaded: language_helper
INFO - 2016-06-04 03:25:08 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:25:09 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:25:09 --> Final output sent to browser
DEBUG - 2016-06-04 03:25:09 --> Total execution time: 0.2400
INFO - 2016-06-04 03:25:09 --> Config Class Initialized
INFO - 2016-06-04 03:25:09 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:25:09 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:25:09 --> Utf8 Class Initialized
INFO - 2016-06-04 03:25:09 --> URI Class Initialized
INFO - 2016-06-04 03:25:09 --> Router Class Initialized
INFO - 2016-06-04 03:25:09 --> Output Class Initialized
INFO - 2016-06-04 03:25:09 --> Security Class Initialized
DEBUG - 2016-06-04 03:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:25:09 --> Input Class Initialized
INFO - 2016-06-04 03:25:09 --> Language Class Initialized
INFO - 2016-06-04 03:25:09 --> Loader Class Initialized
INFO - 2016-06-04 03:25:09 --> Helper loaded: url_helper
INFO - 2016-06-04 03:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:25:09 --> Controller Class Initialized
INFO - 2016-06-04 03:25:09 --> Helper loaded: language_helper
INFO - 2016-06-04 03:25:09 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:25:09 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 03:25:09 --> Final output sent to browser
DEBUG - 2016-06-04 03:25:09 --> Total execution time: 0.2200
INFO - 2016-06-04 03:25:11 --> Config Class Initialized
INFO - 2016-06-04 03:25:11 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:25:11 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:25:11 --> Utf8 Class Initialized
INFO - 2016-06-04 03:25:11 --> URI Class Initialized
INFO - 2016-06-04 03:25:11 --> Router Class Initialized
INFO - 2016-06-04 03:25:11 --> Output Class Initialized
INFO - 2016-06-04 03:25:11 --> Security Class Initialized
DEBUG - 2016-06-04 03:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:25:11 --> Input Class Initialized
INFO - 2016-06-04 03:25:11 --> Language Class Initialized
INFO - 2016-06-04 03:25:11 --> Loader Class Initialized
INFO - 2016-06-04 03:25:11 --> Helper loaded: url_helper
INFO - 2016-06-04 03:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:25:11 --> Controller Class Initialized
INFO - 2016-06-04 03:25:11 --> Helper loaded: language_helper
INFO - 2016-06-04 03:25:11 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:25:11 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\contact.php
INFO - 2016-06-04 03:25:11 --> Final output sent to browser
DEBUG - 2016-06-04 03:25:11 --> Total execution time: 0.2200
INFO - 2016-06-04 03:25:13 --> Config Class Initialized
INFO - 2016-06-04 03:25:13 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:25:13 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:25:13 --> Utf8 Class Initialized
INFO - 2016-06-04 03:25:13 --> URI Class Initialized
INFO - 2016-06-04 03:25:13 --> Router Class Initialized
INFO - 2016-06-04 03:25:13 --> Output Class Initialized
INFO - 2016-06-04 03:25:13 --> Security Class Initialized
DEBUG - 2016-06-04 03:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:25:13 --> Input Class Initialized
INFO - 2016-06-04 03:25:13 --> Language Class Initialized
INFO - 2016-06-04 03:25:13 --> Loader Class Initialized
INFO - 2016-06-04 03:25:13 --> Helper loaded: url_helper
INFO - 2016-06-04 03:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:25:13 --> Controller Class Initialized
INFO - 2016-06-04 03:25:13 --> Helper loaded: language_helper
INFO - 2016-06-04 03:25:13 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:25:13 --> Config Class Initialized
INFO - 2016-06-04 03:25:13 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:25:13 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:25:13 --> Utf8 Class Initialized
INFO - 2016-06-04 03:25:13 --> URI Class Initialized
INFO - 2016-06-04 03:25:13 --> Router Class Initialized
INFO - 2016-06-04 03:25:13 --> Output Class Initialized
INFO - 2016-06-04 03:25:13 --> Security Class Initialized
DEBUG - 2016-06-04 03:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:25:13 --> Input Class Initialized
INFO - 2016-06-04 03:25:13 --> Language Class Initialized
INFO - 2016-06-04 03:25:13 --> Loader Class Initialized
INFO - 2016-06-04 03:25:13 --> Helper loaded: url_helper
INFO - 2016-06-04 03:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:25:13 --> Controller Class Initialized
INFO - 2016-06-04 03:25:13 --> Helper loaded: language_helper
INFO - 2016-06-04 03:25:13 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:25:13 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\contact.php
INFO - 2016-06-04 03:25:13 --> Final output sent to browser
DEBUG - 2016-06-04 03:25:13 --> Total execution time: 0.2000
INFO - 2016-06-04 03:25:15 --> Config Class Initialized
INFO - 2016-06-04 03:25:15 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:25:15 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:25:15 --> Utf8 Class Initialized
INFO - 2016-06-04 03:25:15 --> URI Class Initialized
INFO - 2016-06-04 03:25:15 --> Router Class Initialized
INFO - 2016-06-04 03:25:15 --> Output Class Initialized
INFO - 2016-06-04 03:25:15 --> Security Class Initialized
DEBUG - 2016-06-04 03:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:25:15 --> Input Class Initialized
INFO - 2016-06-04 03:25:15 --> Language Class Initialized
INFO - 2016-06-04 03:25:15 --> Loader Class Initialized
INFO - 2016-06-04 03:25:15 --> Helper loaded: url_helper
INFO - 2016-06-04 03:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:25:15 --> Controller Class Initialized
INFO - 2016-06-04 03:25:15 --> Helper loaded: language_helper
INFO - 2016-06-04 03:25:15 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:25:15 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:25:15 --> Final output sent to browser
DEBUG - 2016-06-04 03:25:15 --> Total execution time: 0.2100
INFO - 2016-06-04 03:25:16 --> Config Class Initialized
INFO - 2016-06-04 03:25:16 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:25:16 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:25:16 --> Utf8 Class Initialized
INFO - 2016-06-04 03:25:16 --> URI Class Initialized
INFO - 2016-06-04 03:25:16 --> Router Class Initialized
INFO - 2016-06-04 03:25:16 --> Output Class Initialized
INFO - 2016-06-04 03:25:16 --> Security Class Initialized
DEBUG - 2016-06-04 03:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:25:16 --> Input Class Initialized
INFO - 2016-06-04 03:25:16 --> Language Class Initialized
INFO - 2016-06-04 03:25:16 --> Loader Class Initialized
INFO - 2016-06-04 03:25:16 --> Helper loaded: url_helper
INFO - 2016-06-04 03:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:25:16 --> Controller Class Initialized
INFO - 2016-06-04 03:25:16 --> Helper loaded: language_helper
INFO - 2016-06-04 03:25:16 --> Language file loaded: language/english/message_lang.php
ERROR - 2016-06-04 03:25:16 --> Could not find the language line "title_service"
ERROR - 2016-06-04 03:25:16 --> Could not find the language line "title_service"
INFO - 2016-06-04 03:25:16 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 03:25:16 --> Final output sent to browser
DEBUG - 2016-06-04 03:25:16 --> Total execution time: 0.2400
INFO - 2016-06-04 03:25:16 --> Config Class Initialized
INFO - 2016-06-04 03:25:16 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:25:16 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:25:16 --> Utf8 Class Initialized
INFO - 2016-06-04 03:25:16 --> URI Class Initialized
INFO - 2016-06-04 03:25:16 --> Router Class Initialized
INFO - 2016-06-04 03:25:16 --> Output Class Initialized
INFO - 2016-06-04 03:25:16 --> Security Class Initialized
DEBUG - 2016-06-04 03:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:25:16 --> Input Class Initialized
INFO - 2016-06-04 03:25:16 --> Language Class Initialized
INFO - 2016-06-04 03:25:16 --> Loader Class Initialized
INFO - 2016-06-04 03:25:16 --> Helper loaded: url_helper
INFO - 2016-06-04 03:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:25:16 --> Controller Class Initialized
INFO - 2016-06-04 03:25:16 --> Helper loaded: language_helper
INFO - 2016-06-04 03:25:16 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:25:16 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\contact.php
INFO - 2016-06-04 03:25:16 --> Final output sent to browser
DEBUG - 2016-06-04 03:25:16 --> Total execution time: 0.2200
INFO - 2016-06-04 03:25:29 --> Config Class Initialized
INFO - 2016-06-04 03:25:29 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:25:29 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:25:29 --> Utf8 Class Initialized
INFO - 2016-06-04 03:25:29 --> URI Class Initialized
INFO - 2016-06-04 03:25:29 --> Router Class Initialized
INFO - 2016-06-04 03:25:29 --> Output Class Initialized
INFO - 2016-06-04 03:25:29 --> Security Class Initialized
DEBUG - 2016-06-04 03:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:25:30 --> Input Class Initialized
INFO - 2016-06-04 03:25:30 --> Language Class Initialized
INFO - 2016-06-04 03:25:30 --> Loader Class Initialized
INFO - 2016-06-04 03:25:30 --> Helper loaded: url_helper
INFO - 2016-06-04 03:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:25:30 --> Controller Class Initialized
INFO - 2016-06-04 03:25:30 --> Helper loaded: language_helper
INFO - 2016-06-04 03:25:30 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:25:30 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\contact.php
INFO - 2016-06-04 03:25:30 --> Final output sent to browser
DEBUG - 2016-06-04 03:25:30 --> Total execution time: 0.2250
INFO - 2016-06-04 03:25:36 --> Config Class Initialized
INFO - 2016-06-04 03:25:36 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:25:36 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:25:36 --> Utf8 Class Initialized
INFO - 2016-06-04 03:25:36 --> URI Class Initialized
INFO - 2016-06-04 03:25:36 --> Router Class Initialized
INFO - 2016-06-04 03:25:36 --> Output Class Initialized
INFO - 2016-06-04 03:25:36 --> Security Class Initialized
DEBUG - 2016-06-04 03:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:25:36 --> Input Class Initialized
INFO - 2016-06-04 03:25:36 --> Language Class Initialized
INFO - 2016-06-04 03:25:36 --> Loader Class Initialized
INFO - 2016-06-04 03:25:36 --> Helper loaded: url_helper
INFO - 2016-06-04 03:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:25:37 --> Controller Class Initialized
INFO - 2016-06-04 03:25:37 --> Helper loaded: language_helper
INFO - 2016-06-04 03:25:37 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:25:37 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\contact.php
INFO - 2016-06-04 03:25:37 --> Final output sent to browser
DEBUG - 2016-06-04 03:25:37 --> Total execution time: 0.2600
INFO - 2016-06-04 03:25:47 --> Config Class Initialized
INFO - 2016-06-04 03:25:47 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:25:47 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:25:47 --> Utf8 Class Initialized
INFO - 2016-06-04 03:25:47 --> URI Class Initialized
INFO - 2016-06-04 03:25:47 --> Router Class Initialized
INFO - 2016-06-04 03:25:47 --> Output Class Initialized
INFO - 2016-06-04 03:25:47 --> Security Class Initialized
DEBUG - 2016-06-04 03:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:25:47 --> Input Class Initialized
INFO - 2016-06-04 03:25:47 --> Language Class Initialized
INFO - 2016-06-04 03:25:47 --> Loader Class Initialized
INFO - 2016-06-04 03:25:47 --> Helper loaded: url_helper
INFO - 2016-06-04 03:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:25:47 --> Controller Class Initialized
INFO - 2016-06-04 03:25:47 --> Helper loaded: language_helper
INFO - 2016-06-04 03:25:47 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:25:47 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\contact.php
INFO - 2016-06-04 03:25:47 --> Final output sent to browser
DEBUG - 2016-06-04 03:25:47 --> Total execution time: 0.2420
INFO - 2016-06-04 03:25:50 --> Config Class Initialized
INFO - 2016-06-04 03:25:50 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:25:50 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:25:50 --> Utf8 Class Initialized
INFO - 2016-06-04 03:25:50 --> URI Class Initialized
INFO - 2016-06-04 03:25:50 --> Router Class Initialized
INFO - 2016-06-04 03:25:50 --> Output Class Initialized
INFO - 2016-06-04 03:25:50 --> Security Class Initialized
DEBUG - 2016-06-04 03:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:25:50 --> Input Class Initialized
INFO - 2016-06-04 03:25:50 --> Language Class Initialized
INFO - 2016-06-04 03:25:50 --> Loader Class Initialized
INFO - 2016-06-04 03:25:50 --> Helper loaded: url_helper
INFO - 2016-06-04 03:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:25:50 --> Controller Class Initialized
INFO - 2016-06-04 03:25:50 --> Helper loaded: language_helper
INFO - 2016-06-04 03:25:50 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:25:50 --> Config Class Initialized
INFO - 2016-06-04 03:25:50 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:25:50 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:25:50 --> Utf8 Class Initialized
INFO - 2016-06-04 03:25:50 --> URI Class Initialized
INFO - 2016-06-04 03:25:50 --> Router Class Initialized
INFO - 2016-06-04 03:25:50 --> Output Class Initialized
INFO - 2016-06-04 03:25:50 --> Security Class Initialized
DEBUG - 2016-06-04 03:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:25:50 --> Input Class Initialized
INFO - 2016-06-04 03:25:50 --> Language Class Initialized
INFO - 2016-06-04 03:25:50 --> Loader Class Initialized
INFO - 2016-06-04 03:25:50 --> Helper loaded: url_helper
INFO - 2016-06-04 03:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:25:50 --> Controller Class Initialized
INFO - 2016-06-04 03:25:50 --> Helper loaded: language_helper
INFO - 2016-06-04 03:25:50 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:25:50 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\contact.php
INFO - 2016-06-04 03:25:50 --> Final output sent to browser
DEBUG - 2016-06-04 03:25:50 --> Total execution time: 0.2220
INFO - 2016-06-04 03:25:53 --> Config Class Initialized
INFO - 2016-06-04 03:25:53 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:25:53 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:25:53 --> Utf8 Class Initialized
INFO - 2016-06-04 03:25:53 --> URI Class Initialized
INFO - 2016-06-04 03:25:53 --> Router Class Initialized
INFO - 2016-06-04 03:25:53 --> Output Class Initialized
INFO - 2016-06-04 03:25:53 --> Security Class Initialized
DEBUG - 2016-06-04 03:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:25:53 --> Input Class Initialized
INFO - 2016-06-04 03:25:53 --> Language Class Initialized
INFO - 2016-06-04 03:25:53 --> Loader Class Initialized
INFO - 2016-06-04 03:25:53 --> Helper loaded: url_helper
INFO - 2016-06-04 03:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:25:53 --> Controller Class Initialized
INFO - 2016-06-04 03:25:53 --> Helper loaded: language_helper
INFO - 2016-06-04 03:25:53 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:25:53 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 03:25:53 --> Final output sent to browser
DEBUG - 2016-06-04 03:25:53 --> Total execution time: 0.2210
INFO - 2016-06-04 03:25:54 --> Config Class Initialized
INFO - 2016-06-04 03:25:54 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:25:54 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:25:54 --> Utf8 Class Initialized
INFO - 2016-06-04 03:25:54 --> URI Class Initialized
INFO - 2016-06-04 03:25:54 --> Router Class Initialized
INFO - 2016-06-04 03:25:54 --> Output Class Initialized
INFO - 2016-06-04 03:25:54 --> Security Class Initialized
DEBUG - 2016-06-04 03:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:25:54 --> Input Class Initialized
INFO - 2016-06-04 03:25:54 --> Language Class Initialized
INFO - 2016-06-04 03:25:54 --> Loader Class Initialized
INFO - 2016-06-04 03:25:54 --> Helper loaded: url_helper
INFO - 2016-06-04 03:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:25:54 --> Controller Class Initialized
INFO - 2016-06-04 03:25:54 --> Helper loaded: language_helper
INFO - 2016-06-04 03:25:54 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:25:54 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:25:54 --> Final output sent to browser
DEBUG - 2016-06-04 03:25:54 --> Total execution time: 0.2380
INFO - 2016-06-04 03:25:55 --> Config Class Initialized
INFO - 2016-06-04 03:25:55 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:25:56 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:25:56 --> Utf8 Class Initialized
INFO - 2016-06-04 03:25:56 --> URI Class Initialized
INFO - 2016-06-04 03:25:56 --> Router Class Initialized
INFO - 2016-06-04 03:25:56 --> Output Class Initialized
INFO - 2016-06-04 03:25:56 --> Security Class Initialized
DEBUG - 2016-06-04 03:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:25:56 --> Input Class Initialized
INFO - 2016-06-04 03:25:56 --> Language Class Initialized
INFO - 2016-06-04 03:25:56 --> Loader Class Initialized
INFO - 2016-06-04 03:25:56 --> Helper loaded: url_helper
INFO - 2016-06-04 03:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:25:56 --> Controller Class Initialized
INFO - 2016-06-04 03:25:56 --> Helper loaded: language_helper
INFO - 2016-06-04 03:25:56 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:25:56 --> Config Class Initialized
INFO - 2016-06-04 03:25:56 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:25:56 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:25:56 --> Utf8 Class Initialized
INFO - 2016-06-04 03:25:56 --> URI Class Initialized
INFO - 2016-06-04 03:25:56 --> Router Class Initialized
INFO - 2016-06-04 03:25:56 --> Output Class Initialized
INFO - 2016-06-04 03:25:56 --> Security Class Initialized
DEBUG - 2016-06-04 03:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:25:56 --> Input Class Initialized
INFO - 2016-06-04 03:25:56 --> Language Class Initialized
INFO - 2016-06-04 03:25:56 --> Loader Class Initialized
INFO - 2016-06-04 03:25:56 --> Helper loaded: url_helper
INFO - 2016-06-04 03:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:25:56 --> Controller Class Initialized
INFO - 2016-06-04 03:25:56 --> Helper loaded: language_helper
INFO - 2016-06-04 03:25:56 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:25:56 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:25:56 --> Final output sent to browser
DEBUG - 2016-06-04 03:25:56 --> Total execution time: 0.2430
INFO - 2016-06-04 03:25:58 --> Config Class Initialized
INFO - 2016-06-04 03:25:58 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:25:58 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:25:58 --> Utf8 Class Initialized
INFO - 2016-06-04 03:25:58 --> URI Class Initialized
INFO - 2016-06-04 03:25:58 --> Router Class Initialized
INFO - 2016-06-04 03:25:58 --> Output Class Initialized
INFO - 2016-06-04 03:25:58 --> Security Class Initialized
DEBUG - 2016-06-04 03:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:25:58 --> Input Class Initialized
INFO - 2016-06-04 03:25:58 --> Language Class Initialized
INFO - 2016-06-04 03:25:58 --> Loader Class Initialized
INFO - 2016-06-04 03:25:58 --> Helper loaded: url_helper
INFO - 2016-06-04 03:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:25:58 --> Controller Class Initialized
INFO - 2016-06-04 03:25:58 --> Helper loaded: language_helper
INFO - 2016-06-04 03:25:58 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:25:58 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:25:58 --> Final output sent to browser
DEBUG - 2016-06-04 03:25:58 --> Total execution time: 0.2280
INFO - 2016-06-04 03:25:59 --> Config Class Initialized
INFO - 2016-06-04 03:25:59 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:25:59 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:25:59 --> Utf8 Class Initialized
INFO - 2016-06-04 03:25:59 --> URI Class Initialized
INFO - 2016-06-04 03:25:59 --> Router Class Initialized
INFO - 2016-06-04 03:25:59 --> Output Class Initialized
INFO - 2016-06-04 03:25:59 --> Security Class Initialized
DEBUG - 2016-06-04 03:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:25:59 --> Input Class Initialized
INFO - 2016-06-04 03:25:59 --> Language Class Initialized
INFO - 2016-06-04 03:25:59 --> Loader Class Initialized
INFO - 2016-06-04 03:25:59 --> Helper loaded: url_helper
INFO - 2016-06-04 03:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:25:59 --> Controller Class Initialized
INFO - 2016-06-04 03:25:59 --> Helper loaded: language_helper
INFO - 2016-06-04 03:25:59 --> Language file loaded: language/english/message_lang.php
ERROR - 2016-06-04 03:25:59 --> Could not find the language line "title_service"
ERROR - 2016-06-04 03:25:59 --> Could not find the language line "title_service"
INFO - 2016-06-04 03:25:59 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 03:25:59 --> Final output sent to browser
DEBUG - 2016-06-04 03:25:59 --> Total execution time: 0.2580
INFO - 2016-06-04 03:27:45 --> Config Class Initialized
INFO - 2016-06-04 03:27:45 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:27:45 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:27:45 --> Utf8 Class Initialized
INFO - 2016-06-04 03:27:45 --> URI Class Initialized
INFO - 2016-06-04 03:27:45 --> Router Class Initialized
INFO - 2016-06-04 03:27:45 --> Output Class Initialized
INFO - 2016-06-04 03:27:45 --> Security Class Initialized
DEBUG - 2016-06-04 03:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:27:45 --> Input Class Initialized
INFO - 2016-06-04 03:27:45 --> Language Class Initialized
INFO - 2016-06-04 03:27:45 --> Loader Class Initialized
INFO - 2016-06-04 03:27:45 --> Helper loaded: url_helper
INFO - 2016-06-04 03:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:27:45 --> Controller Class Initialized
INFO - 2016-06-04 03:27:45 --> Helper loaded: language_helper
INFO - 2016-06-04 03:27:45 --> Language file loaded: language/english/message_lang.php
ERROR - 2016-06-04 03:27:45 --> Could not find the language line "title_service"
ERROR - 2016-06-04 03:27:45 --> Could not find the language line "title_service"
INFO - 2016-06-04 03:27:45 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 03:27:45 --> Final output sent to browser
DEBUG - 2016-06-04 03:27:45 --> Total execution time: 0.2500
INFO - 2016-06-04 03:27:47 --> Config Class Initialized
INFO - 2016-06-04 03:27:47 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:27:47 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:27:47 --> Utf8 Class Initialized
INFO - 2016-06-04 03:27:47 --> URI Class Initialized
DEBUG - 2016-06-04 03:27:47 --> No URI present. Default controller set.
INFO - 2016-06-04 03:27:47 --> Router Class Initialized
INFO - 2016-06-04 03:27:47 --> Output Class Initialized
INFO - 2016-06-04 03:27:47 --> Security Class Initialized
DEBUG - 2016-06-04 03:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:27:47 --> Input Class Initialized
INFO - 2016-06-04 03:27:47 --> Language Class Initialized
INFO - 2016-06-04 03:27:47 --> Loader Class Initialized
INFO - 2016-06-04 03:27:47 --> Helper loaded: url_helper
INFO - 2016-06-04 03:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:27:47 --> Controller Class Initialized
INFO - 2016-06-04 03:27:47 --> Helper loaded: language_helper
INFO - 2016-06-04 03:27:47 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:27:47 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:27:47 --> Final output sent to browser
DEBUG - 2016-06-04 03:27:47 --> Total execution time: 0.2220
INFO - 2016-06-04 03:27:50 --> Config Class Initialized
INFO - 2016-06-04 03:27:50 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:27:50 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:27:50 --> Utf8 Class Initialized
INFO - 2016-06-04 03:27:50 --> URI Class Initialized
INFO - 2016-06-04 03:27:50 --> Router Class Initialized
INFO - 2016-06-04 03:27:50 --> Output Class Initialized
INFO - 2016-06-04 03:27:50 --> Security Class Initialized
DEBUG - 2016-06-04 03:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:27:50 --> Input Class Initialized
INFO - 2016-06-04 03:27:50 --> Language Class Initialized
INFO - 2016-06-04 03:27:50 --> Loader Class Initialized
INFO - 2016-06-04 03:27:50 --> Helper loaded: url_helper
INFO - 2016-06-04 03:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:27:50 --> Controller Class Initialized
INFO - 2016-06-04 03:27:50 --> Helper loaded: language_helper
INFO - 2016-06-04 03:27:50 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:27:50 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:27:50 --> Final output sent to browser
DEBUG - 2016-06-04 03:27:50 --> Total execution time: 0.2330
INFO - 2016-06-04 03:27:55 --> Config Class Initialized
INFO - 2016-06-04 03:27:55 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:27:55 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:27:55 --> Utf8 Class Initialized
INFO - 2016-06-04 03:27:55 --> URI Class Initialized
INFO - 2016-06-04 03:27:55 --> Router Class Initialized
INFO - 2016-06-04 03:27:55 --> Output Class Initialized
INFO - 2016-06-04 03:27:55 --> Security Class Initialized
DEBUG - 2016-06-04 03:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:27:55 --> Input Class Initialized
INFO - 2016-06-04 03:27:55 --> Language Class Initialized
INFO - 2016-06-04 03:27:55 --> Loader Class Initialized
INFO - 2016-06-04 03:27:55 --> Helper loaded: url_helper
INFO - 2016-06-04 03:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:27:55 --> Controller Class Initialized
INFO - 2016-06-04 03:27:55 --> Helper loaded: language_helper
INFO - 2016-06-04 03:27:56 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:27:56 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:27:56 --> Final output sent to browser
DEBUG - 2016-06-04 03:27:56 --> Total execution time: 0.2200
INFO - 2016-06-04 03:32:32 --> Config Class Initialized
INFO - 2016-06-04 03:32:32 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:32:32 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:32:32 --> Utf8 Class Initialized
INFO - 2016-06-04 03:32:32 --> URI Class Initialized
INFO - 2016-06-04 03:32:32 --> Router Class Initialized
INFO - 2016-06-04 03:32:32 --> Output Class Initialized
INFO - 2016-06-04 03:32:32 --> Security Class Initialized
DEBUG - 2016-06-04 03:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:32:32 --> Input Class Initialized
INFO - 2016-06-04 03:32:32 --> Language Class Initialized
INFO - 2016-06-04 03:32:32 --> Loader Class Initialized
INFO - 2016-06-04 03:32:32 --> Helper loaded: url_helper
INFO - 2016-06-04 03:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:32:32 --> Controller Class Initialized
INFO - 2016-06-04 03:32:32 --> Helper loaded: language_helper
INFO - 2016-06-04 03:32:32 --> Language file loaded: language/english/message_lang.php
ERROR - 2016-06-04 03:32:32 --> Could not find the language line "title_service"
ERROR - 2016-06-04 03:32:32 --> Severity: Error --> Call to undefined function link_tag() D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php 8
INFO - 2016-06-04 03:33:13 --> Config Class Initialized
INFO - 2016-06-04 03:33:13 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:33:13 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:33:13 --> Utf8 Class Initialized
INFO - 2016-06-04 03:33:13 --> URI Class Initialized
INFO - 2016-06-04 03:33:13 --> Router Class Initialized
INFO - 2016-06-04 03:33:13 --> Output Class Initialized
INFO - 2016-06-04 03:33:13 --> Security Class Initialized
DEBUG - 2016-06-04 03:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:33:13 --> Input Class Initialized
INFO - 2016-06-04 03:33:13 --> Language Class Initialized
INFO - 2016-06-04 03:33:13 --> Loader Class Initialized
INFO - 2016-06-04 03:33:13 --> Helper loaded: url_helper
INFO - 2016-06-04 03:33:13 --> Helper loaded: html_helper
INFO - 2016-06-04 03:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:33:13 --> Controller Class Initialized
INFO - 2016-06-04 03:33:13 --> Helper loaded: language_helper
INFO - 2016-06-04 03:33:13 --> Language file loaded: language/english/message_lang.php
ERROR - 2016-06-04 03:33:13 --> Could not find the language line "title_service"
ERROR - 2016-06-04 03:33:13 --> Could not find the language line "title_service"
INFO - 2016-06-04 03:33:13 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 03:33:13 --> Final output sent to browser
DEBUG - 2016-06-04 03:33:13 --> Total execution time: 0.2690
INFO - 2016-06-04 03:33:44 --> Config Class Initialized
INFO - 2016-06-04 03:33:44 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:33:44 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:33:44 --> Utf8 Class Initialized
INFO - 2016-06-04 03:33:44 --> URI Class Initialized
INFO - 2016-06-04 03:33:44 --> Router Class Initialized
INFO - 2016-06-04 03:33:44 --> Output Class Initialized
INFO - 2016-06-04 03:33:44 --> Security Class Initialized
DEBUG - 2016-06-04 03:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:33:44 --> Input Class Initialized
INFO - 2016-06-04 03:33:44 --> Language Class Initialized
INFO - 2016-06-04 03:33:44 --> Loader Class Initialized
INFO - 2016-06-04 03:33:44 --> Helper loaded: url_helper
INFO - 2016-06-04 03:33:44 --> Helper loaded: html_helper
INFO - 2016-06-04 03:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:33:44 --> Controller Class Initialized
INFO - 2016-06-04 03:33:44 --> Helper loaded: language_helper
INFO - 2016-06-04 03:33:44 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:33:44 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:33:44 --> Final output sent to browser
DEBUG - 2016-06-04 03:33:44 --> Total execution time: 0.2400
INFO - 2016-06-04 03:33:45 --> Config Class Initialized
INFO - 2016-06-04 03:33:45 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:33:45 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:33:45 --> Utf8 Class Initialized
INFO - 2016-06-04 03:33:45 --> URI Class Initialized
INFO - 2016-06-04 03:33:45 --> Router Class Initialized
INFO - 2016-06-04 03:33:45 --> Output Class Initialized
INFO - 2016-06-04 03:33:45 --> Security Class Initialized
DEBUG - 2016-06-04 03:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:33:45 --> Input Class Initialized
INFO - 2016-06-04 03:33:45 --> Language Class Initialized
INFO - 2016-06-04 03:33:45 --> Loader Class Initialized
INFO - 2016-06-04 03:33:45 --> Helper loaded: url_helper
INFO - 2016-06-04 03:33:45 --> Helper loaded: html_helper
INFO - 2016-06-04 03:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:33:45 --> Controller Class Initialized
INFO - 2016-06-04 03:33:45 --> Helper loaded: language_helper
INFO - 2016-06-04 03:33:45 --> Language file loaded: language/english/message_lang.php
ERROR - 2016-06-04 03:33:45 --> Could not find the language line "title_service"
ERROR - 2016-06-04 03:33:45 --> Could not find the language line "title_service"
INFO - 2016-06-04 03:33:45 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 03:33:45 --> Final output sent to browser
DEBUG - 2016-06-04 03:33:45 --> Total execution time: 0.2900
INFO - 2016-06-04 03:33:45 --> Config Class Initialized
INFO - 2016-06-04 03:33:45 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:33:45 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:33:45 --> Utf8 Class Initialized
INFO - 2016-06-04 03:33:45 --> URI Class Initialized
INFO - 2016-06-04 03:33:45 --> Router Class Initialized
INFO - 2016-06-04 03:33:45 --> Output Class Initialized
INFO - 2016-06-04 03:33:45 --> Security Class Initialized
DEBUG - 2016-06-04 03:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:33:45 --> Input Class Initialized
INFO - 2016-06-04 03:33:45 --> Language Class Initialized
INFO - 2016-06-04 03:33:45 --> Loader Class Initialized
INFO - 2016-06-04 03:33:45 --> Helper loaded: url_helper
INFO - 2016-06-04 03:33:45 --> Helper loaded: html_helper
INFO - 2016-06-04 03:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:33:45 --> Controller Class Initialized
INFO - 2016-06-04 03:33:45 --> Helper loaded: language_helper
INFO - 2016-06-04 03:33:45 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:33:45 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\contact.php
INFO - 2016-06-04 03:33:45 --> Final output sent to browser
DEBUG - 2016-06-04 03:33:45 --> Total execution time: 0.2540
INFO - 2016-06-04 03:33:46 --> Config Class Initialized
INFO - 2016-06-04 03:33:46 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:33:46 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:33:46 --> Utf8 Class Initialized
INFO - 2016-06-04 03:33:46 --> URI Class Initialized
DEBUG - 2016-06-04 03:33:46 --> No URI present. Default controller set.
INFO - 2016-06-04 03:33:46 --> Router Class Initialized
INFO - 2016-06-04 03:33:46 --> Output Class Initialized
INFO - 2016-06-04 03:33:46 --> Security Class Initialized
DEBUG - 2016-06-04 03:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:33:46 --> Input Class Initialized
INFO - 2016-06-04 03:33:46 --> Language Class Initialized
INFO - 2016-06-04 03:33:46 --> Loader Class Initialized
INFO - 2016-06-04 03:33:46 --> Helper loaded: url_helper
INFO - 2016-06-04 03:33:46 --> Helper loaded: html_helper
INFO - 2016-06-04 03:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:33:46 --> Controller Class Initialized
INFO - 2016-06-04 03:33:46 --> Helper loaded: language_helper
INFO - 2016-06-04 03:33:46 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:33:46 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:33:46 --> Final output sent to browser
DEBUG - 2016-06-04 03:33:46 --> Total execution time: 0.2600
INFO - 2016-06-04 03:35:10 --> Config Class Initialized
INFO - 2016-06-04 03:35:10 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:35:10 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:35:10 --> Utf8 Class Initialized
INFO - 2016-06-04 03:35:10 --> URI Class Initialized
DEBUG - 2016-06-04 03:35:10 --> No URI present. Default controller set.
INFO - 2016-06-04 03:35:10 --> Router Class Initialized
INFO - 2016-06-04 03:35:10 --> Output Class Initialized
INFO - 2016-06-04 03:35:10 --> Security Class Initialized
DEBUG - 2016-06-04 03:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:35:10 --> Input Class Initialized
INFO - 2016-06-04 03:35:10 --> Language Class Initialized
INFO - 2016-06-04 03:35:10 --> Loader Class Initialized
INFO - 2016-06-04 03:35:10 --> Helper loaded: url_helper
INFO - 2016-06-04 03:35:10 --> Helper loaded: html_helper
INFO - 2016-06-04 03:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:35:10 --> Controller Class Initialized
INFO - 2016-06-04 03:35:10 --> Helper loaded: language_helper
INFO - 2016-06-04 03:35:10 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:35:10 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:35:10 --> Final output sent to browser
DEBUG - 2016-06-04 03:35:10 --> Total execution time: 0.2550
INFO - 2016-06-04 03:35:12 --> Config Class Initialized
INFO - 2016-06-04 03:35:12 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:35:12 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:35:12 --> Utf8 Class Initialized
INFO - 2016-06-04 03:35:12 --> URI Class Initialized
INFO - 2016-06-04 03:35:12 --> Router Class Initialized
INFO - 2016-06-04 03:35:12 --> Output Class Initialized
INFO - 2016-06-04 03:35:12 --> Security Class Initialized
DEBUG - 2016-06-04 03:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:35:12 --> Input Class Initialized
INFO - 2016-06-04 03:35:12 --> Language Class Initialized
INFO - 2016-06-04 03:35:12 --> Loader Class Initialized
INFO - 2016-06-04 03:35:12 --> Helper loaded: url_helper
INFO - 2016-06-04 03:35:12 --> Helper loaded: html_helper
INFO - 2016-06-04 03:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:35:12 --> Controller Class Initialized
INFO - 2016-06-04 03:35:12 --> Helper loaded: language_helper
INFO - 2016-06-04 03:35:12 --> Language file loaded: language/english/message_lang.php
ERROR - 2016-06-04 03:35:12 --> Could not find the language line "title_service"
ERROR - 2016-06-04 03:35:12 --> Could not find the language line "title_service"
INFO - 2016-06-04 03:35:13 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 03:35:13 --> Final output sent to browser
DEBUG - 2016-06-04 03:35:13 --> Total execution time: 0.2800
INFO - 2016-06-04 03:35:13 --> Config Class Initialized
INFO - 2016-06-04 03:35:13 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:35:13 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:35:13 --> Utf8 Class Initialized
INFO - 2016-06-04 03:35:13 --> URI Class Initialized
INFO - 2016-06-04 03:35:13 --> Router Class Initialized
INFO - 2016-06-04 03:35:13 --> Output Class Initialized
INFO - 2016-06-04 03:35:13 --> Security Class Initialized
DEBUG - 2016-06-04 03:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:35:13 --> Input Class Initialized
INFO - 2016-06-04 03:35:13 --> Language Class Initialized
INFO - 2016-06-04 03:35:13 --> Loader Class Initialized
INFO - 2016-06-04 03:35:13 --> Helper loaded: url_helper
INFO - 2016-06-04 03:35:13 --> Helper loaded: html_helper
INFO - 2016-06-04 03:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:35:13 --> Controller Class Initialized
INFO - 2016-06-04 03:35:13 --> Helper loaded: language_helper
INFO - 2016-06-04 03:35:13 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:35:13 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:35:13 --> Final output sent to browser
DEBUG - 2016-06-04 03:35:13 --> Total execution time: 0.2640
INFO - 2016-06-04 03:35:14 --> Config Class Initialized
INFO - 2016-06-04 03:35:14 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:35:14 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:35:14 --> Utf8 Class Initialized
INFO - 2016-06-04 03:35:14 --> URI Class Initialized
DEBUG - 2016-06-04 03:35:14 --> No URI present. Default controller set.
INFO - 2016-06-04 03:35:15 --> Router Class Initialized
INFO - 2016-06-04 03:35:15 --> Output Class Initialized
INFO - 2016-06-04 03:35:15 --> Security Class Initialized
DEBUG - 2016-06-04 03:35:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:35:15 --> Input Class Initialized
INFO - 2016-06-04 03:35:15 --> Language Class Initialized
INFO - 2016-06-04 03:35:15 --> Loader Class Initialized
INFO - 2016-06-04 03:35:15 --> Helper loaded: url_helper
INFO - 2016-06-04 03:35:15 --> Helper loaded: html_helper
INFO - 2016-06-04 03:35:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:35:15 --> Controller Class Initialized
INFO - 2016-06-04 03:35:15 --> Helper loaded: language_helper
INFO - 2016-06-04 03:35:15 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:35:15 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:35:15 --> Final output sent to browser
DEBUG - 2016-06-04 03:35:15 --> Total execution time: 0.3120
INFO - 2016-06-04 03:35:15 --> Config Class Initialized
INFO - 2016-06-04 03:35:15 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:35:15 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:35:15 --> Utf8 Class Initialized
INFO - 2016-06-04 03:35:15 --> URI Class Initialized
INFO - 2016-06-04 03:35:16 --> Router Class Initialized
INFO - 2016-06-04 03:35:16 --> Output Class Initialized
INFO - 2016-06-04 03:35:16 --> Security Class Initialized
DEBUG - 2016-06-04 03:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:35:16 --> Input Class Initialized
INFO - 2016-06-04 03:35:16 --> Language Class Initialized
INFO - 2016-06-04 03:35:16 --> Loader Class Initialized
INFO - 2016-06-04 03:35:16 --> Helper loaded: url_helper
INFO - 2016-06-04 03:35:16 --> Helper loaded: html_helper
INFO - 2016-06-04 03:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:35:16 --> Controller Class Initialized
INFO - 2016-06-04 03:35:16 --> Helper loaded: language_helper
INFO - 2016-06-04 03:35:16 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:35:16 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:35:16 --> Final output sent to browser
DEBUG - 2016-06-04 03:35:16 --> Total execution time: 0.2470
INFO - 2016-06-04 03:35:16 --> Config Class Initialized
INFO - 2016-06-04 03:35:16 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:35:16 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:35:16 --> Utf8 Class Initialized
INFO - 2016-06-04 03:35:16 --> URI Class Initialized
INFO - 2016-06-04 03:35:16 --> Router Class Initialized
INFO - 2016-06-04 03:35:16 --> Output Class Initialized
INFO - 2016-06-04 03:35:16 --> Security Class Initialized
DEBUG - 2016-06-04 03:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:35:16 --> Input Class Initialized
INFO - 2016-06-04 03:35:16 --> Language Class Initialized
INFO - 2016-06-04 03:35:16 --> Loader Class Initialized
INFO - 2016-06-04 03:35:16 --> Helper loaded: url_helper
INFO - 2016-06-04 03:35:16 --> Helper loaded: html_helper
INFO - 2016-06-04 03:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:35:16 --> Controller Class Initialized
INFO - 2016-06-04 03:35:16 --> Helper loaded: language_helper
INFO - 2016-06-04 03:35:16 --> Language file loaded: language/english/message_lang.php
ERROR - 2016-06-04 03:35:16 --> Could not find the language line "title_service"
ERROR - 2016-06-04 03:35:16 --> Could not find the language line "title_service"
INFO - 2016-06-04 03:35:16 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 03:35:16 --> Final output sent to browser
DEBUG - 2016-06-04 03:35:16 --> Total execution time: 0.2790
INFO - 2016-06-04 03:35:18 --> Config Class Initialized
INFO - 2016-06-04 03:35:18 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:35:18 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:35:18 --> Utf8 Class Initialized
INFO - 2016-06-04 03:35:18 --> URI Class Initialized
INFO - 2016-06-04 03:35:18 --> Router Class Initialized
INFO - 2016-06-04 03:35:18 --> Output Class Initialized
INFO - 2016-06-04 03:35:18 --> Security Class Initialized
DEBUG - 2016-06-04 03:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:35:18 --> Input Class Initialized
INFO - 2016-06-04 03:35:18 --> Language Class Initialized
INFO - 2016-06-04 03:35:18 --> Loader Class Initialized
INFO - 2016-06-04 03:35:18 --> Helper loaded: url_helper
INFO - 2016-06-04 03:35:18 --> Helper loaded: html_helper
INFO - 2016-06-04 03:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:35:18 --> Controller Class Initialized
INFO - 2016-06-04 03:35:18 --> Helper loaded: language_helper
INFO - 2016-06-04 03:35:18 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:35:18 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\contact.php
INFO - 2016-06-04 03:35:18 --> Final output sent to browser
DEBUG - 2016-06-04 03:35:18 --> Total execution time: 0.2400
INFO - 2016-06-04 03:35:34 --> Config Class Initialized
INFO - 2016-06-04 03:35:34 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:35:34 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:35:34 --> Utf8 Class Initialized
INFO - 2016-06-04 03:35:34 --> URI Class Initialized
INFO - 2016-06-04 03:35:34 --> Router Class Initialized
INFO - 2016-06-04 03:35:34 --> Output Class Initialized
INFO - 2016-06-04 03:35:34 --> Security Class Initialized
DEBUG - 2016-06-04 03:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:35:34 --> Input Class Initialized
INFO - 2016-06-04 03:35:34 --> Language Class Initialized
INFO - 2016-06-04 03:35:34 --> Loader Class Initialized
INFO - 2016-06-04 03:35:34 --> Helper loaded: url_helper
INFO - 2016-06-04 03:35:34 --> Helper loaded: html_helper
INFO - 2016-06-04 03:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:35:34 --> Controller Class Initialized
INFO - 2016-06-04 03:35:34 --> Helper loaded: language_helper
INFO - 2016-06-04 03:35:34 --> Language file loaded: language/english/message_lang.php
ERROR - 2016-06-04 03:35:34 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\inc_selectLang.php 14
INFO - 2016-06-04 03:35:42 --> Config Class Initialized
INFO - 2016-06-04 03:35:42 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:35:42 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:35:42 --> Utf8 Class Initialized
INFO - 2016-06-04 03:35:42 --> URI Class Initialized
DEBUG - 2016-06-04 03:35:42 --> No URI present. Default controller set.
INFO - 2016-06-04 03:35:42 --> Router Class Initialized
INFO - 2016-06-04 03:35:42 --> Output Class Initialized
INFO - 2016-06-04 03:35:42 --> Security Class Initialized
DEBUG - 2016-06-04 03:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:35:42 --> Input Class Initialized
INFO - 2016-06-04 03:35:42 --> Language Class Initialized
INFO - 2016-06-04 03:35:42 --> Loader Class Initialized
INFO - 2016-06-04 03:35:42 --> Helper loaded: url_helper
INFO - 2016-06-04 03:35:42 --> Helper loaded: html_helper
INFO - 2016-06-04 03:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:35:42 --> Controller Class Initialized
INFO - 2016-06-04 03:35:42 --> Helper loaded: language_helper
INFO - 2016-06-04 03:35:42 --> Language file loaded: language/english/message_lang.php
ERROR - 2016-06-04 03:35:42 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\inc_selectLang.php 14
INFO - 2016-06-04 03:35:51 --> Config Class Initialized
INFO - 2016-06-04 03:35:51 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:35:51 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:35:51 --> Utf8 Class Initialized
INFO - 2016-06-04 03:35:51 --> URI Class Initialized
DEBUG - 2016-06-04 03:35:51 --> No URI present. Default controller set.
INFO - 2016-06-04 03:35:51 --> Router Class Initialized
INFO - 2016-06-04 03:35:51 --> Output Class Initialized
INFO - 2016-06-04 03:35:51 --> Security Class Initialized
DEBUG - 2016-06-04 03:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:35:51 --> Input Class Initialized
INFO - 2016-06-04 03:35:51 --> Language Class Initialized
INFO - 2016-06-04 03:35:51 --> Loader Class Initialized
INFO - 2016-06-04 03:35:51 --> Helper loaded: url_helper
INFO - 2016-06-04 03:35:51 --> Helper loaded: html_helper
INFO - 2016-06-04 03:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:35:51 --> Controller Class Initialized
INFO - 2016-06-04 03:35:51 --> Helper loaded: language_helper
INFO - 2016-06-04 03:35:51 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:35:51 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:35:51 --> Final output sent to browser
DEBUG - 2016-06-04 03:35:51 --> Total execution time: 0.2530
INFO - 2016-06-04 03:35:54 --> Config Class Initialized
INFO - 2016-06-04 03:35:54 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:35:54 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:35:54 --> Utf8 Class Initialized
INFO - 2016-06-04 03:35:54 --> URI Class Initialized
INFO - 2016-06-04 03:35:54 --> Router Class Initialized
INFO - 2016-06-04 03:35:54 --> Output Class Initialized
INFO - 2016-06-04 03:35:54 --> Security Class Initialized
DEBUG - 2016-06-04 03:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:35:54 --> Input Class Initialized
INFO - 2016-06-04 03:35:54 --> Language Class Initialized
INFO - 2016-06-04 03:35:54 --> Loader Class Initialized
INFO - 2016-06-04 03:35:54 --> Helper loaded: url_helper
INFO - 2016-06-04 03:35:54 --> Helper loaded: html_helper
INFO - 2016-06-04 03:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:35:54 --> Controller Class Initialized
INFO - 2016-06-04 03:35:54 --> Helper loaded: language_helper
INFO - 2016-06-04 03:35:54 --> Language file loaded: language/english/message_lang.php
ERROR - 2016-06-04 03:35:54 --> Could not find the language line "title_service"
ERROR - 2016-06-04 03:35:54 --> Could not find the language line "title_service"
INFO - 2016-06-04 03:35:54 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 03:35:54 --> Final output sent to browser
DEBUG - 2016-06-04 03:35:54 --> Total execution time: 0.2760
INFO - 2016-06-04 03:35:55 --> Config Class Initialized
INFO - 2016-06-04 03:35:55 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:35:55 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:35:55 --> Utf8 Class Initialized
INFO - 2016-06-04 03:35:55 --> URI Class Initialized
INFO - 2016-06-04 03:35:55 --> Router Class Initialized
INFO - 2016-06-04 03:35:55 --> Output Class Initialized
INFO - 2016-06-04 03:35:55 --> Security Class Initialized
DEBUG - 2016-06-04 03:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:35:55 --> Input Class Initialized
INFO - 2016-06-04 03:35:55 --> Language Class Initialized
INFO - 2016-06-04 03:35:55 --> Loader Class Initialized
INFO - 2016-06-04 03:35:55 --> Helper loaded: url_helper
INFO - 2016-06-04 03:35:55 --> Helper loaded: html_helper
INFO - 2016-06-04 03:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:35:55 --> Controller Class Initialized
INFO - 2016-06-04 03:35:55 --> Helper loaded: language_helper
INFO - 2016-06-04 03:35:55 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:35:55 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:35:55 --> Final output sent to browser
DEBUG - 2016-06-04 03:35:55 --> Total execution time: 0.2680
INFO - 2016-06-04 03:35:55 --> Config Class Initialized
INFO - 2016-06-04 03:35:55 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:35:55 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:35:55 --> Utf8 Class Initialized
INFO - 2016-06-04 03:35:55 --> URI Class Initialized
DEBUG - 2016-06-04 03:35:55 --> No URI present. Default controller set.
INFO - 2016-06-04 03:35:55 --> Router Class Initialized
INFO - 2016-06-04 03:35:56 --> Output Class Initialized
INFO - 2016-06-04 03:35:56 --> Security Class Initialized
DEBUG - 2016-06-04 03:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:35:56 --> Input Class Initialized
INFO - 2016-06-04 03:35:56 --> Language Class Initialized
INFO - 2016-06-04 03:35:56 --> Loader Class Initialized
INFO - 2016-06-04 03:35:56 --> Helper loaded: url_helper
INFO - 2016-06-04 03:35:56 --> Helper loaded: html_helper
INFO - 2016-06-04 03:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:35:56 --> Controller Class Initialized
INFO - 2016-06-04 03:35:56 --> Helper loaded: language_helper
INFO - 2016-06-04 03:35:56 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:35:56 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:35:56 --> Final output sent to browser
DEBUG - 2016-06-04 03:35:56 --> Total execution time: 0.2640
INFO - 2016-06-04 03:35:56 --> Config Class Initialized
INFO - 2016-06-04 03:35:56 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:35:56 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:35:56 --> Utf8 Class Initialized
INFO - 2016-06-04 03:35:56 --> URI Class Initialized
INFO - 2016-06-04 03:35:56 --> Router Class Initialized
INFO - 2016-06-04 03:35:56 --> Output Class Initialized
INFO - 2016-06-04 03:35:56 --> Security Class Initialized
DEBUG - 2016-06-04 03:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:35:56 --> Input Class Initialized
INFO - 2016-06-04 03:35:56 --> Language Class Initialized
INFO - 2016-06-04 03:35:56 --> Loader Class Initialized
INFO - 2016-06-04 03:35:56 --> Helper loaded: url_helper
INFO - 2016-06-04 03:35:56 --> Helper loaded: html_helper
INFO - 2016-06-04 03:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:35:56 --> Controller Class Initialized
INFO - 2016-06-04 03:35:56 --> Helper loaded: language_helper
INFO - 2016-06-04 03:35:56 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:35:56 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:35:56 --> Final output sent to browser
DEBUG - 2016-06-04 03:35:56 --> Total execution time: 0.2580
INFO - 2016-06-04 03:36:01 --> Config Class Initialized
INFO - 2016-06-04 03:36:01 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:36:01 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:36:01 --> Utf8 Class Initialized
INFO - 2016-06-04 03:36:01 --> URI Class Initialized
INFO - 2016-06-04 03:36:01 --> Router Class Initialized
INFO - 2016-06-04 03:36:01 --> Output Class Initialized
INFO - 2016-06-04 03:36:01 --> Security Class Initialized
DEBUG - 2016-06-04 03:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:36:01 --> Input Class Initialized
INFO - 2016-06-04 03:36:01 --> Language Class Initialized
INFO - 2016-06-04 03:36:01 --> Loader Class Initialized
INFO - 2016-06-04 03:36:01 --> Helper loaded: url_helper
INFO - 2016-06-04 03:36:01 --> Helper loaded: html_helper
INFO - 2016-06-04 03:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:36:01 --> Controller Class Initialized
INFO - 2016-06-04 03:36:01 --> Helper loaded: language_helper
INFO - 2016-06-04 03:36:01 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:36:01 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:36:01 --> Final output sent to browser
DEBUG - 2016-06-04 03:36:02 --> Total execution time: 0.3100
INFO - 2016-06-04 03:36:08 --> Config Class Initialized
INFO - 2016-06-04 03:36:08 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:36:08 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:36:08 --> Utf8 Class Initialized
INFO - 2016-06-04 03:36:08 --> URI Class Initialized
INFO - 2016-06-04 03:36:08 --> Router Class Initialized
INFO - 2016-06-04 03:36:08 --> Output Class Initialized
INFO - 2016-06-04 03:36:08 --> Security Class Initialized
DEBUG - 2016-06-04 03:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:36:08 --> Input Class Initialized
INFO - 2016-06-04 03:36:08 --> Language Class Initialized
INFO - 2016-06-04 03:36:08 --> Loader Class Initialized
INFO - 2016-06-04 03:36:08 --> Helper loaded: url_helper
INFO - 2016-06-04 03:36:08 --> Helper loaded: html_helper
INFO - 2016-06-04 03:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:36:08 --> Controller Class Initialized
INFO - 2016-06-04 03:36:08 --> Helper loaded: language_helper
INFO - 2016-06-04 03:36:08 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:36:08 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:36:08 --> Final output sent to browser
DEBUG - 2016-06-04 03:36:08 --> Total execution time: 0.2940
INFO - 2016-06-04 03:36:18 --> Config Class Initialized
INFO - 2016-06-04 03:36:18 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:36:18 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:36:18 --> Utf8 Class Initialized
INFO - 2016-06-04 03:36:18 --> URI Class Initialized
INFO - 2016-06-04 03:36:18 --> Router Class Initialized
INFO - 2016-06-04 03:36:18 --> Output Class Initialized
INFO - 2016-06-04 03:36:18 --> Security Class Initialized
DEBUG - 2016-06-04 03:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:36:18 --> Input Class Initialized
INFO - 2016-06-04 03:36:18 --> Language Class Initialized
INFO - 2016-06-04 03:36:18 --> Loader Class Initialized
INFO - 2016-06-04 03:36:18 --> Helper loaded: url_helper
INFO - 2016-06-04 03:36:18 --> Helper loaded: html_helper
INFO - 2016-06-04 03:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:36:18 --> Controller Class Initialized
INFO - 2016-06-04 03:36:18 --> Helper loaded: language_helper
INFO - 2016-06-04 03:36:18 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:36:18 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:36:18 --> Final output sent to browser
DEBUG - 2016-06-04 03:36:18 --> Total execution time: 0.2500
INFO - 2016-06-04 03:50:39 --> Config Class Initialized
INFO - 2016-06-04 03:50:39 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:50:39 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:50:39 --> Utf8 Class Initialized
INFO - 2016-06-04 03:50:39 --> URI Class Initialized
DEBUG - 2016-06-04 03:50:39 --> No URI present. Default controller set.
INFO - 2016-06-04 03:50:39 --> Router Class Initialized
INFO - 2016-06-04 03:50:39 --> Output Class Initialized
INFO - 2016-06-04 03:50:39 --> Security Class Initialized
DEBUG - 2016-06-04 03:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:50:39 --> Input Class Initialized
INFO - 2016-06-04 03:50:39 --> Language Class Initialized
INFO - 2016-06-04 03:50:39 --> Loader Class Initialized
INFO - 2016-06-04 03:50:39 --> Helper loaded: url_helper
INFO - 2016-06-04 03:50:39 --> Helper loaded: html_helper
INFO - 2016-06-04 03:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:50:39 --> Controller Class Initialized
INFO - 2016-06-04 03:50:39 --> Helper loaded: language_helper
INFO - 2016-06-04 03:50:39 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:50:39 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:50:39 --> Final output sent to browser
DEBUG - 2016-06-04 03:50:39 --> Total execution time: 0.2690
INFO - 2016-06-04 03:50:41 --> Config Class Initialized
INFO - 2016-06-04 03:50:41 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:50:41 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:50:41 --> Utf8 Class Initialized
INFO - 2016-06-04 03:50:41 --> URI Class Initialized
INFO - 2016-06-04 03:50:41 --> Router Class Initialized
INFO - 2016-06-04 03:50:41 --> Output Class Initialized
INFO - 2016-06-04 03:50:41 --> Security Class Initialized
DEBUG - 2016-06-04 03:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:50:41 --> Input Class Initialized
INFO - 2016-06-04 03:50:41 --> Language Class Initialized
INFO - 2016-06-04 03:50:41 --> Loader Class Initialized
INFO - 2016-06-04 03:50:41 --> Helper loaded: url_helper
INFO - 2016-06-04 03:50:41 --> Helper loaded: html_helper
INFO - 2016-06-04 03:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:50:41 --> Controller Class Initialized
INFO - 2016-06-04 03:50:41 --> Helper loaded: language_helper
INFO - 2016-06-04 03:50:41 --> Language file loaded: language/english/message_lang.php
ERROR - 2016-06-04 03:50:41 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php 9
INFO - 2016-06-04 03:50:51 --> Config Class Initialized
INFO - 2016-06-04 03:50:51 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:50:51 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:50:51 --> Utf8 Class Initialized
INFO - 2016-06-04 03:50:51 --> URI Class Initialized
INFO - 2016-06-04 03:50:51 --> Router Class Initialized
INFO - 2016-06-04 03:50:51 --> Output Class Initialized
INFO - 2016-06-04 03:50:51 --> Security Class Initialized
DEBUG - 2016-06-04 03:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:50:51 --> Input Class Initialized
INFO - 2016-06-04 03:50:51 --> Language Class Initialized
INFO - 2016-06-04 03:50:51 --> Loader Class Initialized
INFO - 2016-06-04 03:50:51 --> Helper loaded: url_helper
INFO - 2016-06-04 03:50:51 --> Helper loaded: html_helper
INFO - 2016-06-04 03:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:50:51 --> Controller Class Initialized
INFO - 2016-06-04 03:50:51 --> Helper loaded: language_helper
INFO - 2016-06-04 03:50:51 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:50:51 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:50:51 --> Final output sent to browser
DEBUG - 2016-06-04 03:50:51 --> Total execution time: 0.2600
INFO - 2016-06-04 03:50:54 --> Config Class Initialized
INFO - 2016-06-04 03:50:54 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:50:54 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:50:54 --> Utf8 Class Initialized
INFO - 2016-06-04 03:50:54 --> URI Class Initialized
INFO - 2016-06-04 03:50:54 --> Router Class Initialized
INFO - 2016-06-04 03:50:54 --> Output Class Initialized
INFO - 2016-06-04 03:50:54 --> Security Class Initialized
DEBUG - 2016-06-04 03:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:50:54 --> Input Class Initialized
INFO - 2016-06-04 03:50:54 --> Language Class Initialized
INFO - 2016-06-04 03:50:54 --> Loader Class Initialized
INFO - 2016-06-04 03:50:54 --> Helper loaded: url_helper
INFO - 2016-06-04 03:50:54 --> Helper loaded: html_helper
INFO - 2016-06-04 03:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:50:54 --> Controller Class Initialized
INFO - 2016-06-04 03:50:54 --> Helper loaded: language_helper
INFO - 2016-06-04 03:50:54 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:50:54 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:50:54 --> Final output sent to browser
DEBUG - 2016-06-04 03:50:54 --> Total execution time: 0.2720
INFO - 2016-06-04 03:51:21 --> Config Class Initialized
INFO - 2016-06-04 03:51:21 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:51:21 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:51:21 --> Utf8 Class Initialized
INFO - 2016-06-04 03:51:21 --> URI Class Initialized
INFO - 2016-06-04 03:51:21 --> Router Class Initialized
INFO - 2016-06-04 03:51:21 --> Output Class Initialized
INFO - 2016-06-04 03:51:21 --> Security Class Initialized
DEBUG - 2016-06-04 03:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:51:21 --> Input Class Initialized
INFO - 2016-06-04 03:51:21 --> Language Class Initialized
INFO - 2016-06-04 03:51:21 --> Loader Class Initialized
INFO - 2016-06-04 03:51:21 --> Helper loaded: url_helper
INFO - 2016-06-04 03:51:21 --> Helper loaded: html_helper
INFO - 2016-06-04 03:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:51:21 --> Controller Class Initialized
INFO - 2016-06-04 03:51:21 --> Helper loaded: language_helper
INFO - 2016-06-04 03:51:21 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:51:21 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:51:21 --> Final output sent to browser
DEBUG - 2016-06-04 03:51:21 --> Total execution time: 0.2670
INFO - 2016-06-04 03:51:23 --> Config Class Initialized
INFO - 2016-06-04 03:51:23 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:51:23 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:51:23 --> Utf8 Class Initialized
INFO - 2016-06-04 03:51:23 --> URI Class Initialized
INFO - 2016-06-04 03:51:23 --> Router Class Initialized
INFO - 2016-06-04 03:51:23 --> Output Class Initialized
INFO - 2016-06-04 03:51:23 --> Security Class Initialized
DEBUG - 2016-06-04 03:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:51:23 --> Input Class Initialized
INFO - 2016-06-04 03:51:23 --> Language Class Initialized
INFO - 2016-06-04 03:51:23 --> Loader Class Initialized
INFO - 2016-06-04 03:51:23 --> Helper loaded: url_helper
INFO - 2016-06-04 03:51:23 --> Helper loaded: html_helper
INFO - 2016-06-04 03:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:51:23 --> Controller Class Initialized
INFO - 2016-06-04 03:51:23 --> Helper loaded: language_helper
INFO - 2016-06-04 03:51:23 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:51:23 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:51:23 --> Final output sent to browser
DEBUG - 2016-06-04 03:51:23 --> Total execution time: 0.2580
INFO - 2016-06-04 03:51:29 --> Config Class Initialized
INFO - 2016-06-04 03:51:29 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:51:29 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:51:29 --> Utf8 Class Initialized
INFO - 2016-06-04 03:51:29 --> URI Class Initialized
INFO - 2016-06-04 03:51:29 --> Router Class Initialized
INFO - 2016-06-04 03:51:29 --> Output Class Initialized
INFO - 2016-06-04 03:51:29 --> Security Class Initialized
DEBUG - 2016-06-04 03:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:51:29 --> Input Class Initialized
INFO - 2016-06-04 03:51:29 --> Language Class Initialized
INFO - 2016-06-04 03:51:29 --> Loader Class Initialized
INFO - 2016-06-04 03:51:29 --> Helper loaded: url_helper
INFO - 2016-06-04 03:51:29 --> Helper loaded: html_helper
INFO - 2016-06-04 03:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:51:29 --> Controller Class Initialized
INFO - 2016-06-04 03:51:29 --> Helper loaded: language_helper
INFO - 2016-06-04 03:51:29 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:51:29 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:51:29 --> Final output sent to browser
DEBUG - 2016-06-04 03:51:29 --> Total execution time: 0.2630
INFO - 2016-06-04 03:52:29 --> Config Class Initialized
INFO - 2016-06-04 03:52:29 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:52:29 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:52:29 --> Utf8 Class Initialized
INFO - 2016-06-04 03:52:29 --> URI Class Initialized
INFO - 2016-06-04 03:52:29 --> Router Class Initialized
INFO - 2016-06-04 03:52:29 --> Output Class Initialized
INFO - 2016-06-04 03:52:29 --> Security Class Initialized
DEBUG - 2016-06-04 03:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:52:29 --> Input Class Initialized
INFO - 2016-06-04 03:52:29 --> Language Class Initialized
INFO - 2016-06-04 03:52:29 --> Loader Class Initialized
INFO - 2016-06-04 03:52:29 --> Helper loaded: url_helper
INFO - 2016-06-04 03:52:29 --> Helper loaded: html_helper
INFO - 2016-06-04 03:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:52:29 --> Controller Class Initialized
INFO - 2016-06-04 03:52:29 --> Helper loaded: language_helper
INFO - 2016-06-04 03:52:29 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:52:29 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:52:29 --> Final output sent to browser
DEBUG - 2016-06-04 03:52:29 --> Total execution time: 0.2600
INFO - 2016-06-04 03:52:30 --> Config Class Initialized
INFO - 2016-06-04 03:52:30 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:52:30 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:52:30 --> Utf8 Class Initialized
INFO - 2016-06-04 03:52:30 --> URI Class Initialized
DEBUG - 2016-06-04 03:52:30 --> No URI present. Default controller set.
INFO - 2016-06-04 03:52:30 --> Router Class Initialized
INFO - 2016-06-04 03:52:30 --> Output Class Initialized
INFO - 2016-06-04 03:52:30 --> Security Class Initialized
DEBUG - 2016-06-04 03:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:52:30 --> Input Class Initialized
INFO - 2016-06-04 03:52:30 --> Language Class Initialized
INFO - 2016-06-04 03:52:30 --> Loader Class Initialized
INFO - 2016-06-04 03:52:30 --> Helper loaded: url_helper
INFO - 2016-06-04 03:52:30 --> Helper loaded: html_helper
INFO - 2016-06-04 03:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:52:30 --> Controller Class Initialized
INFO - 2016-06-04 03:52:30 --> Helper loaded: language_helper
INFO - 2016-06-04 03:52:31 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:52:31 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:52:31 --> Final output sent to browser
DEBUG - 2016-06-04 03:52:31 --> Total execution time: 0.2580
INFO - 2016-06-04 03:56:54 --> Config Class Initialized
INFO - 2016-06-04 03:56:54 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:56:54 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:56:54 --> Utf8 Class Initialized
INFO - 2016-06-04 03:56:54 --> URI Class Initialized
INFO - 2016-06-04 03:56:54 --> Router Class Initialized
INFO - 2016-06-04 03:56:54 --> Output Class Initialized
INFO - 2016-06-04 03:56:54 --> Security Class Initialized
DEBUG - 2016-06-04 03:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:56:54 --> Input Class Initialized
INFO - 2016-06-04 03:56:54 --> Language Class Initialized
INFO - 2016-06-04 03:56:54 --> Loader Class Initialized
INFO - 2016-06-04 03:56:54 --> Helper loaded: url_helper
INFO - 2016-06-04 03:56:54 --> Helper loaded: html_helper
INFO - 2016-06-04 03:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:56:54 --> Controller Class Initialized
INFO - 2016-06-04 03:56:54 --> Helper loaded: language_helper
INFO - 2016-06-04 03:56:54 --> Language file loaded: language/english/message_lang.php
ERROR - 2016-06-04 03:56:54 --> Could not find the language line "title_service"
ERROR - 2016-06-04 03:56:54 --> Could not find the language line "title_service"
INFO - 2016-06-04 03:56:54 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 03:56:54 --> Final output sent to browser
DEBUG - 2016-06-04 03:56:54 --> Total execution time: 0.3220
INFO - 2016-06-04 03:56:55 --> Config Class Initialized
INFO - 2016-06-04 03:56:55 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:56:55 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:56:55 --> Utf8 Class Initialized
INFO - 2016-06-04 03:56:55 --> URI Class Initialized
INFO - 2016-06-04 03:56:55 --> Router Class Initialized
INFO - 2016-06-04 03:56:55 --> Output Class Initialized
INFO - 2016-06-04 03:56:55 --> Security Class Initialized
DEBUG - 2016-06-04 03:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:56:55 --> Input Class Initialized
INFO - 2016-06-04 03:56:55 --> Language Class Initialized
INFO - 2016-06-04 03:56:55 --> Loader Class Initialized
INFO - 2016-06-04 03:56:55 --> Helper loaded: url_helper
INFO - 2016-06-04 03:56:55 --> Helper loaded: html_helper
INFO - 2016-06-04 03:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:56:55 --> Controller Class Initialized
INFO - 2016-06-04 03:56:55 --> Helper loaded: language_helper
INFO - 2016-06-04 03:56:55 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:56:55 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:56:55 --> Final output sent to browser
DEBUG - 2016-06-04 03:56:55 --> Total execution time: 0.2700
INFO - 2016-06-04 03:56:56 --> Config Class Initialized
INFO - 2016-06-04 03:56:56 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:56:57 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:56:57 --> Utf8 Class Initialized
INFO - 2016-06-04 03:56:57 --> URI Class Initialized
INFO - 2016-06-04 03:56:57 --> Router Class Initialized
INFO - 2016-06-04 03:56:57 --> Output Class Initialized
INFO - 2016-06-04 03:56:57 --> Security Class Initialized
DEBUG - 2016-06-04 03:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:56:57 --> Input Class Initialized
INFO - 2016-06-04 03:56:57 --> Language Class Initialized
INFO - 2016-06-04 03:56:57 --> Loader Class Initialized
INFO - 2016-06-04 03:56:57 --> Helper loaded: url_helper
INFO - 2016-06-04 03:56:57 --> Helper loaded: html_helper
INFO - 2016-06-04 03:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:56:57 --> Controller Class Initialized
INFO - 2016-06-04 03:56:57 --> Helper loaded: language_helper
INFO - 2016-06-04 03:56:57 --> Language file loaded: language/english/message_lang.php
INFO - 2016-06-04 03:56:57 --> Config Class Initialized
INFO - 2016-06-04 03:56:57 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:56:57 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:56:57 --> Utf8 Class Initialized
INFO - 2016-06-04 03:56:57 --> URI Class Initialized
INFO - 2016-06-04 03:56:57 --> Router Class Initialized
INFO - 2016-06-04 03:56:57 --> Output Class Initialized
INFO - 2016-06-04 03:56:57 --> Security Class Initialized
DEBUG - 2016-06-04 03:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:56:57 --> Input Class Initialized
INFO - 2016-06-04 03:56:57 --> Language Class Initialized
INFO - 2016-06-04 03:56:57 --> Loader Class Initialized
INFO - 2016-06-04 03:56:57 --> Helper loaded: url_helper
INFO - 2016-06-04 03:56:57 --> Helper loaded: html_helper
INFO - 2016-06-04 03:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:56:57 --> Controller Class Initialized
INFO - 2016-06-04 03:56:57 --> Helper loaded: language_helper
INFO - 2016-06-04 03:56:57 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:56:57 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:56:57 --> Final output sent to browser
DEBUG - 2016-06-04 03:56:57 --> Total execution time: 0.2500
INFO - 2016-06-04 03:56:58 --> Config Class Initialized
INFO - 2016-06-04 03:56:58 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:56:58 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:56:58 --> Utf8 Class Initialized
INFO - 2016-06-04 03:56:58 --> URI Class Initialized
INFO - 2016-06-04 03:56:58 --> Router Class Initialized
INFO - 2016-06-04 03:56:58 --> Output Class Initialized
INFO - 2016-06-04 03:56:58 --> Security Class Initialized
DEBUG - 2016-06-04 03:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:56:58 --> Input Class Initialized
INFO - 2016-06-04 03:56:58 --> Language Class Initialized
INFO - 2016-06-04 03:56:58 --> Loader Class Initialized
INFO - 2016-06-04 03:56:58 --> Helper loaded: url_helper
INFO - 2016-06-04 03:56:58 --> Helper loaded: html_helper
INFO - 2016-06-04 03:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:56:58 --> Controller Class Initialized
INFO - 2016-06-04 03:56:58 --> Helper loaded: language_helper
INFO - 2016-06-04 03:56:58 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:56:58 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\services.php
INFO - 2016-06-04 03:56:58 --> Final output sent to browser
DEBUG - 2016-06-04 03:56:58 --> Total execution time: 0.2600
INFO - 2016-06-04 03:56:58 --> Config Class Initialized
INFO - 2016-06-04 03:56:58 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:56:58 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:56:58 --> Utf8 Class Initialized
INFO - 2016-06-04 03:56:58 --> URI Class Initialized
INFO - 2016-06-04 03:56:58 --> Router Class Initialized
INFO - 2016-06-04 03:56:58 --> Output Class Initialized
INFO - 2016-06-04 03:56:58 --> Security Class Initialized
DEBUG - 2016-06-04 03:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:56:58 --> Input Class Initialized
INFO - 2016-06-04 03:56:59 --> Language Class Initialized
INFO - 2016-06-04 03:56:59 --> Loader Class Initialized
INFO - 2016-06-04 03:56:59 --> Helper loaded: url_helper
INFO - 2016-06-04 03:56:59 --> Helper loaded: html_helper
INFO - 2016-06-04 03:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:56:59 --> Controller Class Initialized
INFO - 2016-06-04 03:56:59 --> Helper loaded: language_helper
INFO - 2016-06-04 03:56:59 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:56:59 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\about.php
INFO - 2016-06-04 03:56:59 --> Final output sent to browser
DEBUG - 2016-06-04 03:56:59 --> Total execution time: 0.2720
INFO - 2016-06-04 03:56:59 --> Config Class Initialized
INFO - 2016-06-04 03:56:59 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:56:59 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:56:59 --> Utf8 Class Initialized
INFO - 2016-06-04 03:56:59 --> URI Class Initialized
DEBUG - 2016-06-04 03:56:59 --> No URI present. Default controller set.
INFO - 2016-06-04 03:56:59 --> Router Class Initialized
INFO - 2016-06-04 03:56:59 --> Output Class Initialized
INFO - 2016-06-04 03:56:59 --> Security Class Initialized
DEBUG - 2016-06-04 03:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:56:59 --> Input Class Initialized
INFO - 2016-06-04 03:56:59 --> Language Class Initialized
INFO - 2016-06-04 03:56:59 --> Loader Class Initialized
INFO - 2016-06-04 03:56:59 --> Helper loaded: url_helper
INFO - 2016-06-04 03:56:59 --> Helper loaded: html_helper
INFO - 2016-06-04 03:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:56:59 --> Controller Class Initialized
INFO - 2016-06-04 03:56:59 --> Helper loaded: language_helper
INFO - 2016-06-04 03:56:59 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:56:59 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\home.php
INFO - 2016-06-04 03:56:59 --> Final output sent to browser
DEBUG - 2016-06-04 03:56:59 --> Total execution time: 0.2700
INFO - 2016-06-04 03:57:00 --> Config Class Initialized
INFO - 2016-06-04 03:57:00 --> Hooks Class Initialized
DEBUG - 2016-06-04 03:57:00 --> UTF-8 Support Enabled
INFO - 2016-06-04 03:57:00 --> Utf8 Class Initialized
INFO - 2016-06-04 03:57:00 --> URI Class Initialized
INFO - 2016-06-04 03:57:00 --> Router Class Initialized
INFO - 2016-06-04 03:57:00 --> Output Class Initialized
INFO - 2016-06-04 03:57:00 --> Security Class Initialized
DEBUG - 2016-06-04 03:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-06-04 03:57:00 --> Input Class Initialized
INFO - 2016-06-04 03:57:00 --> Language Class Initialized
INFO - 2016-06-04 03:57:00 --> Loader Class Initialized
INFO - 2016-06-04 03:57:00 --> Helper loaded: url_helper
INFO - 2016-06-04 03:57:00 --> Helper loaded: html_helper
INFO - 2016-06-04 03:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-06-04 03:57:00 --> Controller Class Initialized
INFO - 2016-06-04 03:57:00 --> Helper loaded: language_helper
INFO - 2016-06-04 03:57:00 --> Language file loaded: language/hindi/message_lang.php
INFO - 2016-06-04 03:57:00 --> File loaded: D:\wamp\www\codeigniter.dev\CI_switch_language\application\views\contact.php
INFO - 2016-06-04 03:57:00 --> Final output sent to browser
DEBUG - 2016-06-04 03:57:00 --> Total execution time: 0.2750
