<?php
$lang['home'] 	= 'मुख पृष्ठ';
$lang['title_home']	 	= 'आप मुख पृष्ठ पेज पर हैं';
$lang['about'] 	= 'रूपरेखा';
$lang['title_about']	= 'आप रूपरेखा पृष्ठ पर हैं';
$lang['services'] 	= 'सेवा';
$lang['title_service'] 	= 'आप सेवा पेज पर हैं';
$lang['contact'] 	= 'संपर्क';
$lang['title_contact'] 	= 'आप संपर्क पृष्ठ पर हैं';