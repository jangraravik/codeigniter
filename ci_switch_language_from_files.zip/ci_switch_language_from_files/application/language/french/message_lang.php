<?php
$lang['welcome_message'] = 'Bienvenue à CodexWorld';