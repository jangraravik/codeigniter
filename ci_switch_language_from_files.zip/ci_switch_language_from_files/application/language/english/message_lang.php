<?php
$lang['home']	 	= 'Home';
$lang['title_home']	 	= 'You are at Home page';
$lang['about']	= 'About';
$lang['title_about']	= 'You are at About page';
$lang['services'] 	= 'Service';
$lang['title_services'] 	= 'You are at Services page';
$lang['contact'] 	= 'Contact';
$lang['title_contact'] 	= 'You are at Contact page';
