<?php
$lang['welcome_message'] = 'Willkommen in CodexWorld';