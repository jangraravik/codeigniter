<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['apikey'] = '';
$config['application'] = 'CI Prowl';