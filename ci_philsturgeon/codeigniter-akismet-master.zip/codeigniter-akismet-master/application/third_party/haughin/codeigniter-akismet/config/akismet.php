<?php

	$config['akismet_api_key'] = "blahblahblah";
	$config['akismet_blog_url'] = "http://example.com";