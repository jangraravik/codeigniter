# Build APIs You Wont Hate

This repository contains sample code that is supplied with the book.

["Build APIs You Won't Hate" on LeanPub](http://apisyouwonthate.com)

Some chapters are just theory, and some chapters will have sections that rely on sample code. 
I have tried to avoid making this a book of code, and it's intended to be language 
agnostic, but a book without any concrete examples would just be a hand-wavey joke. 

So, please find enclosed Laravel + PHP based example applications in many chapters, and in 
`chapter11` I have a simple little [API Blueprint] example that you can use with [Aglio].

[API Blueprint]: http://apiblueprint.org/
[Aglio]: https://github.com/danielgtaylor/aglio
