# CodeIgniter-Template

CodeIgniter-Template is a Template library that helps your build complex views with CodeIgniter.
It has logic to work with themes & modules and helps add your title, meta-data, breadcrumbs and partial views.


## Requirements

1. PHP 5.2+
2. CodeIgniter 2.0.3

## Documentation

Open `user_guide/index.html` in your browser for docs.
